<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1><?php echo e(trans('http.404.title')); ?></h1>
                <p><?php echo e(trans('http.404.description')); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<!-- IE needs 512+ bytes: http://blogs.msdn.com/b/ieinternals/archive/2010/08/19/http-error-pages-in-internet-explorer.aspx -->
<?php echo $__env->make('frontend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
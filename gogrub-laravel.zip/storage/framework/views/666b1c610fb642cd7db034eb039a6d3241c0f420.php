<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row">

        <div class="col-12">

            <div class="panel panel-default">
                <div class="panel-heading"><h2><?php echo e(trans('navs.frontend.user.account')); ?></h2></div>

                <div class="panel-body">

                    <nav role="tabpanel">

                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs my-account" role="tablist">
                            <li role="tab" class="nav-item nav-link active" data-toggle="tab" id="li-profile">
                                <a href="#profile" aria-controls="profile" role="tab" data-toggle="tab" class="tabs"><?php echo e(trans('navs.frontend.user.profile')); ?></a>
                            </li>

                            <li role="tab" class="nav-item nav-link" data-toggle="tab" id="li-edit">
                                <a href="#edit" aria-controls="edit" role="tab" data-toggle="tab" class="tabs"><?php echo e(trans('labels.frontend.user.profile.update_information')); ?></a>
                            </li>

                            <?php if($logged_in_user->canChangePassword()): ?>
                                <li role="tab" class="nav-item nav-link" data-toggle="tab" id="li-password">
                                    <a href="#password" aria-controls="password" role="tab" data-toggle="tab" class="tabs"><?php echo e(trans('navs.frontend.user.change_password')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>

                        <div class="tab-content">

                            <div role="tabpanel" class="tab-pane mt-30 active" id="profile">
                                <?php echo $__env->make('frontend.user.account.tabs.profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div><!--tab panel profile-->

                            <div role="tabpanel" class="tab-pane mt-30" id="edit">
                                <?php echo $__env->make('frontend.user.account.tabs.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div><!--tab panel profile-->

                            <?php if($logged_in_user->canChangePassword()): ?>
                                <div role="tabpanel" class="tab-pane mt-30" id="password">
                                    <?php echo $__env->make('frontend.user.account.tabs.change-password', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div><!--tab panel change password-->
                            <?php endif; ?>

                            <?php echo $__env->make('frontend.user.account.upload-photo-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        </div><!--tab content-->

                    </nav><!--tab panel-->

                </div><!--panel body-->

            </div><!-- panel -->

        </div><!-- col-xs-12 -->

    </div><!-- row -->
    </div><!-- row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-scripts'); ?>

<script type="text/javascript">
    $(document).ready(function() {

        // To Use Select2
        Backend.Select2.init();

        if($.session.get("tab") == "edit")
        {
            $("#li-password").removeClass("active");
            $("#li-profile").removeClass("active");
            $("#li-edit").addClass("active");

            $("#profile").removeClass("active");
            $("#password").removeClass("active");
            $("#edit").addClass("active");
        }
        else if($.session.get("tab") == "password")
        {
            $("#li-password").addClass("active");
            $("#li-profile").removeClass("active");
            $("#li-edit").removeClass("active");

            $("#profile").removeClass("active");
            $("#password").addClass("active");
            $("#edit").removeClass("active");
        }

        //Getting States of default contry
        ajaxCall("<?php echo e(route('frontend.get.states')); ?>");



        //Getting Cities of select State
        $("#state").on("change", function() {
            var stateId = $(this).val();
            var url = "<?php echo e(route('frontend.get.cities')); ?>";
            ajaxCall(url, stateId);
        });

        function ajaxCall(url, data = null)
        {
            $.ajax({
                url: url,
                type: "POST",
                data: {stateId: data},
                success: function(result) {
                    if(result != null)
                    {
                        if(result.status == "city")
                        {
                            var userCity = "<?php echo e($logged_in_user->city_id); ?>";
                            var options;
                            $.each(result.data, function(key, value) {
                                if(key == userCity)
                                    options += "<option value='" + key + "' selected>" + value + "</option>";
                                else
                                    options += "<option value='" + key + "'>" + value + "</option>";
                            });
                            $("#city").html('');
                            $("#city").append(options);
                        }
                        else
                        {
                            var userState = "<?php echo e($logged_in_user->state_id); ?>";
                            var options;
                            $.each(result.data, function(key, value) {
                                if(key == userState)
                                    options += "<option value='" + key + "' selected>" + value + "</option>";
                                else
                                    options += "<option value='" + key + "'>" + value + "</option>";
                            });
                            $("#state").append(options);
                            $("#state").trigger('change');
                        }
                    }
                }
            });
        }

        $(".tabs").click(function() {
            var tab = $(this).attr("aria-controls");
            $.session.set("tab", tab);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
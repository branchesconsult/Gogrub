<?php echo e(Form::model($logged_in_user, ['route' => 'frontend.user.profile.update', 'class' => 'form-horizontal', 'method' => 'PATCH'])); ?>


    <div class="form-group">
        <?php echo e(Form::label('first_name', trans('validation.attributes.frontend.register-user.firstName'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::input('text', 'first_name', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.frontend.register-user.firstName')])); ?>

        </div>
    </div>

    <div class="form-group">
        <?php echo e(Form::label('last_name', trans('validation.attributes.frontend.register-user.lastName'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::input('text', 'last_name', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.frontend.register-user.firstName')])); ?>

        </div>
    </div>

    <?php if($logged_in_user->canChangeEmail()): ?>
        <div class="form-group">
            <?php echo e(Form::label('email', trans('validation.attributes.frontend.register-user.email'), ['class' => 'col-md-4 control-label'])); ?>

            <div class="col-md-6">
                <div class="alert alert-info">
                    <i class="fa fa-info-circle"></i> <?php echo e(trans('strings.frontend.user.change_email_notice')); ?>

                </div>

                <?php echo e(Form::input('email', 'email', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.frontend.register-user.email')])); ?>

            </div>
        </div>
    <?php endif; ?>

    <div class="form-group">
        <?php echo e(Form::label('address', trans('validation.attributes.frontend.register-user.address'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::input('textarea', 'address', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.frontend.register-user.address')])); ?>

        </div>
    </div>

    
    <div class="form-group">
        <?php echo e(Form::label('state_id', trans('validation.attributes.frontend.register-user.state'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::select('state_id', [] , null, ['class' => 'form-control select2', 'placeholder' => trans('validation.attributes.frontend.register-user.state'), 'id' => 'state', 'style' => 'width : 539px !important;'])); ?>

        </div><!--col-md-6-->
    </div><!--form-group-->

    
    <div class="form-group">
        <?php echo e(Form::label('city_id', trans('validation.attributes.frontend.register-user.city'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::select('city_id', [], null, ['class' => 'form-control select2', 'placeholder' => trans('validation.attributes.frontend.register-user.city'), 'id' => 'city', 'style' => 'width : 539px !important;'])); ?>

        </div><!--col-md-6-->
    </div><!--form-group-->

    
    <div class="form-group">
        <?php echo e(Form::label('zip_code', trans('validation.attributes.frontend.register-user.zipcode'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::input('name', 'zip_code', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.frontend.register-user.zipcode')])); ?>

        </div><!--col-md-6-->
    </div><!--form-group-->

    
    <div class="form-group">
        <?php echo e(Form::label('ssn', trans('validation.attributes.frontend.register-user.ssn'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::input('name', 'ssn', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.frontend.register-user.ssn')])); ?>

        </div><!--col-md-6-->
    </div><!--form-group-->
                    
    <div class="form-group">
        <div class="col-md-6 col-md-offset-4">
            <?php echo e(Form::submit(trans('labels.general.buttons.update'), ['class' => 'btn btn-primary', 'id' => 'update-profile'])); ?>

        </div>
    </div>

<?php echo e(Form::close()); ?>
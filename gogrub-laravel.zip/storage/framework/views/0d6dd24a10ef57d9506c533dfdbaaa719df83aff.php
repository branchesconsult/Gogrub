<div class="form-group" id="server-ajax-messages">
    <div class="alert alert-danger error hide">

    </div>
    <div class="alert alert-success success hide">

    </div>
</div>
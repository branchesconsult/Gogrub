<!--Var = chefs-->
<?php $__currentLoopData = $chefs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-3">
        <div class="chef-block">
            <a href="<?php echo route('frontend.chef.detail', ['chefId' => $val['id']]); ?>">
                <div class="chef-image">
                    <img src="<?php echo getImgSrc($val['avatar'], 290, 290); ?>"
                         class="img-fluid"/>
                    
                    
                    
                </div>
            </a>
            <div class="chef-list-details">
                <div class="chef-name"><?php echo $val['full_name']; ?></div>
                <div class="star-rating">
                    <?php echo printRatingStars($val['avg_rating']); ?>

                </div>
                <div class="chef-review">
                    (<?php echo $val['rating_reviews_count']; ?>)
                    <?php echo ($val['rating_reviews_count'] > 1)?'Reviews':'Review'; ?></div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
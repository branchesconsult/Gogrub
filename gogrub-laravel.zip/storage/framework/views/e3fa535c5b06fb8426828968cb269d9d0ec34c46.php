<table class="table table-striped table-hover">
    
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.first_name')); ?></th>
        <td><?php echo e(!empty($logged_in_user->first_name) ? $logged_in_user->first_name : ''); ?></td>
    </tr>
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.last_name')); ?></th>
        <td><?php echo e(!empty($logged_in_user->last_name) ? $logged_in_user->last_name : ''); ?></td>
    </tr>
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.email')); ?></th>
        <td><?php echo e(!empty($logged_in_user->email) ? $logged_in_user->email : ''); ?></td>
    </tr>
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.address')); ?></th>
        <td><?php echo e(!empty($logged_in_user->address) ? $logged_in_user->address : ''); ?></td>
    </tr>
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.state')); ?></th>
        <td><?php echo e(!empty($logged_in_user->state->state) ? $logged_in_user->state->state : ''); ?></td>
    </tr>
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.city')); ?></th>
        <td><?php echo e(!empty($logged_in_user->city->city) ? $logged_in_user->city->city : ''); ?></td>
    </tr>
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.zipcode')); ?></th>
        <td><?php echo e(!empty($logged_in_user->zip_code) ? $logged_in_user->zip_code : ''); ?></td>
    </tr>
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.ssn')); ?></th>
        <td><?php echo e(!empty($logged_in_user->ssn) ? $logged_in_user->ssn : ''); ?></td>
    </tr>
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.created_at')); ?></th>
        <td><?php echo e($logged_in_user->created_at); ?> (<?php echo e($logged_in_user->created_at->diffForHumans()); ?>)</td>
    </tr>
    <tr>
        <th><?php echo e(trans('labels.frontend.user.profile.last_updated')); ?></th>
        <td><?php echo e($logged_in_user->updated_at); ?> (<?php echo e($logged_in_user->updated_at->diffForHumans()); ?>)</td>
    </tr>
</table>
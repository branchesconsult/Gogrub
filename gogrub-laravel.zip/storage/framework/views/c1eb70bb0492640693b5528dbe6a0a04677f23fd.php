<?php
    use Illuminate\Support\Facades\Route;
?>
        <!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', app_name()); ?></title>

    <!-- Meta -->
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'Laravel AdminPanel'); ?>">
    <meta name="author" content="<?php echo $__env->yieldContent('meta_author', 'Viral Solani'); ?>">
<?php echo $__env->yieldContent('meta'); ?>

<!-- Styles -->
    <!-- Bootstrap CSS -->
<?php echo Html::style(asset('frontend/css/bootstrap.min.css')); ?>

<?php echo Html::style(asset('frontend/css/font-awesome.min.css')); ?>

<?php echo Html::style(asset('frontend/css/star-rating.css')); ?>

<?php echo Html::style(asset('frontend/css/style.css')); ?>

<?php echo Html::style(mix('css/frontend.css')); ?>

<?php echo $__env->yieldContent('before-styles'); ?>
<?php echo $__env->yieldContent('after-styles'); ?>
<?php echo Html::style('//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css'); ?>


<!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
    <?php
    echo $google_analytics ?? null;
    ?>
    <style>

    </style>
</head>
<body id="app-layout">
<div id="wait-overley"></div>
<section id="pg-area-to-change"><!--Section Id Start-->
    <div id="app">
        <?php if(request()->has('error_message') && !empty(request()->get('error_message'))): ?>
            <div class="col-12">
                <div class="alert alert-danger">
                    <?php echo request()->get('error_message'); ?>

                </div>
            </div>
        <?php endif; ?>
        <?php echo $__env->make('frontend.includes.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('includes.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div><!--#app-->
</section><!----------- Section Id Closed -------------->
<footer>
    <div class="container">
        <div class="row">
            <div class="footer-logo">
                <div class="logo-footer"><img src="<?php echo asset('frontend/images/Group489@2x.png'); ?>"/></div>
                <div class="copyright">@ 2018 <strong>Go Grub</strong></div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-3 col-md-6 col-sm-12">
                <ul class="footer-nav">
                    <li><a href="">About Us</a></li>
                    <li><a href="">Contact</a></li>
                    <li><a href="">Terms and Condition</a></li>
                </ul>
            </div>
            <div class="col-xl-3 col-md-6 col-sm-12">
                <ul class="footer-nav">
                    <li><a href="">Facebook</a></li>
                    <li><a href="">Twitter</a></li>
                    <li><a href="">Instagram</a></li>
                </ul>
            </div>
            <div class="col-xl-3 col-md-6 col-sm-12">
                <p>Send Us Your Feedback</p>
                <form class="form-inline">
                    <input class="form-control mr-sm-2" type="email" placeholder="Email Address" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">OK</button>
                </form>
            </div>
            <div class="col-xl-3 col-md-6 col-sm-12">
                <div class="footer-info">
                    497 Evergreen Rd. Roseville, CA 95673<br/>
                    +44 345 678 903<br/>
                    adobexd@mail.com
                </div>
            </div>
        </div>
    </div>
</footer>
<div id="all-models">
    <?php echo $__env->make('frontend.includes.login-model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('frontend.includes.signup-model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php if(\Auth::check()): ?>
        <?php echo $__env->make('frontend.includes.verification-model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('frontend.includes.chef-verfication-uploads', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<?php echo Html::script(asset('frontend/js/jquery.min.js')); ?>

<?php echo Html::script('http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.5/jquery-ui.min.js'); ?>

<?php echo Html::script(asset('frontend/popperjs/popper.min.js')); ?>

<?php echo Html::script(asset('frontend/js/bootstrap.min.js')); ?>

<?php echo Html::script(asset('frontend/validation/jquery.validate.js')); ?>

<?php echo Html::script(asset('frontend/validation/additional-methods.js')); ?>

<?php echo Html::script('https://maps.googleapis.com/maps/api/js?key=AIzaSyC263na3AWmXdy9htO50E9kiq2-cgbBsMo&libraries=places,geometry,drawing,v=3.exp'); ?>

<?php echo Html::script(asset('/js/gmaps.js')); ?>

<?php echo Html::script(asset('/js/jquery.geocomplete.min.js')); ?>

<!-- Scripts -->
<?php echo $__env->yieldContent('before-scripts'); ?>
<?php echo $__env->yieldContent('after-scripts'); ?>
<?php echo $__env->yieldContent('login-model-scripts'); ?>
<?php echo $__env->yieldContent('verify-model-scripts'); ?>
<?php echo $__env->yieldContent('signup-modal-scripts'); ?>
<?php echo $__env->yieldContent('add-to-card-modal-scripts'); ?>
<?php echo $__env->yieldContent('cart-page-scripts'); ?>
<?php echo $__env->yieldContent('chef-verification-uploads-scripts'); ?>
<?php echo $__env->yieldContent('search-banner-js'); ?>
<?php echo $__env->yieldContent('google-map-modal-scripts'); ?>

<script>
    $(document).ready(function () {
        initMap();
        //Global ajax spinner
        $('.tooltip-input').tooltip();
        $(document)
            .ajaxStart(function () {
                $("#wait-overley").show();
            })
            .ajaxStop(function () {
                $("#wait-overley").hide();
            });
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Device-Type': 'browser'
            }
        });
        jQuery(".triggerbtn").click(function () {
            jQuery(this).closest('div').find('#files').click();
        });
        //Replace all broken images
        $("img").each(function () {
            $(this).attr("onerror", "this.src='http://gogrub.docs/frontend/images/images@2x.png'");
        });
    });
    // locate you.
    function initMap() {

    }
    function openBsModal(modelId) {
        $("#server-ajax-messages div").hide();
        $(".modal").modal('hide');
        setTimeout(function () {
            $("#" + modelId).modal('show');
        }, 700);
        return false;
    }

    function redirectTo(pgUrl) {
        return window.location.href = pgUrl;
    }
    function scrollToEle(eleId) {
        $('html, body').animate({
            scrollTop: $("#" + eleId).offset().top
        }, 200, 'linear', $('.tooltip-input').tooltip('show'));
    }
</script>
</body>
</html>
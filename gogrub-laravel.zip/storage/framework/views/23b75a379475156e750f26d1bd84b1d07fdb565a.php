<!--Always get $products variable-->
<?php
    $colSize = $colSize ?? 3;
?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 col-sm-6 col-md-4 col-lg-<?php echo $colSize; ?> col-xl-<?php echo $colSize; ?>">
        <div class="food-block">
            <a href="<?php echo route('frontend.product.detail', ['slug' => $val['slug']]); ?>">
                <div class="food-image">
                    <img
                            src="<?php echo (!empty($val['images'])) ? getImgSrc($val['images'][0]['image_large'], 290,290) : getImgSrc(null, 290,290); ?>"
                            class="img-fluid"/>
                    <div class="food-meal-left">
                        <strong><?php echo $val['remaining_servings']; ?></strong> Left
                    </div>
                    <?php if($val['remaining_servings'] <= 0): ?>
                        <div class="food-meal-btn red">
                            Sold out
                            <strong><?php echo $val['price_view']; ?></strong>
                        </div>
                    <?php else: ?>
                        <div class="food-meal-btn green">
                            Add to meal
                            <strong><?php echo $val['price_view']; ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
            </a>
            <div class="food-list-details">
                <div class="row">
                    <div class="col-7">
                        <div class="food-name">
                            <?php echo $val['name']; ?>

                        </div>
                        <?php if(!empty($val['chef'])): ?>
                            <div class="food-chef-name">
                                <strong>Chef:</strong>
                                <?php echo $val['chef']['full_name']; ?>

                            </div>
                        <?php endif; ?>
                        <div class="food-cuisine">
                            <strong>Cuisine:</strong> <?php echo $val['cuisine']['name']; ?>

                        </div>
                    </div>
                    <div class="col-5">
                        <div class="food-serving">
                            <strong>Serving Size:</strong>
                            <?php for($i = 1; $i<=$val['serving_size'];$i++): ?>
                                <i class="fa fa-user"></i>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
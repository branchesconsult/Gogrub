<?php $__env->startSection('before-styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="my-order">
        <?php echo Form::open(['route' => 'frontend.order.checkout']); ?>

        <div class="container">
            <div class="row justify-content-md-center">
                <div class="col-xl-10 col-md-12">
                    <div class="row">
                        <div class="col-xl-8 col-md-12">
                            <?php $__currentLoopData = $cart_contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="receipt" id="item-<?php echo $key; ?>">
                                    <h3><?php echo $val['qty']; ?> x <?php echo $val['name']; ?></h3>
                                    <span><?php echo formatPrice($val['price']); ?></span>
                                    <i onclick="removeItemFromCart('<?php echo $key; ?>')" class="fa fa-close"></i>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="receipt-form">
                                <h2>Delivery time</h2>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <select id="estimate_delivery_mins" name="estimate_delivery_mins"
                                                class="form-control">
                                            <?php $__currentLoopData = $delivery_slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo $val; ?>">
                                                    <?php echo $val; ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <h2>Delivery Address</h2>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="inputBuilding">Complete Address</label>
                                        <textarea class="form-control"
                                                  placeholder="Nearest Land mark, Floor, building, street, house number etc"
                                                  name="customer_address"
                                                  id="customer_address"></textarea>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="inputInformation">Additional Delivery Information</label>
                                        <textarea class="form-control" name="special_instructions"
                                                  id="special_instructions"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="receipt-form">
                                <h2>Personal details</h2>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="fullName">Full name</label>
                                        <input value="<?php echo \Auth::user()->full_name; ?>" type="text" class="form-control"
                                               id="fullName" name="">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="customerMobile">Mobile</label>
                                        <span>+92</span>
                                        <input type="text"
                                               value="<?php echo \Auth::user()->mobile; ?>"
                                               class="form-control"
                                               id="customer_phone"
                                               name="customer_phone"
                                        >
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-12">
                            <div class="cart-detail">
                                <?php $__currentLoopData = $cart_contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="cart-box">
                                        <h5><?php echo $val['qty']; ?> x <?php echo $val['name']; ?></h5>
                                        <span><?php echo formatPrice($val['price']); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <hr/>
                                <div class="cart-box">
                                    <h5><strong>Subtotal</strong></h5>
                                    <span><?php echo formatPrice($subtotal); ?></span>
                                </div>
                                <div class="cart-box">
                                    <h5><strong>Delivery Charges</strong></h5>
                                    <span><?php echo formatPrice($delivery_charges); ?></span>
                                </div>
                                <hr/>
                                <div class="cart-box">
                                    <h5><strong>Total</strong></h5>
                                    <span><?php echo formatPrice($total); ?></span>
                                </div>

                                <div class="cart-box">
                                    <h5><strong>Payment Method</strong></h5>
                                    <span>
                                         <label>
                                            <input type="radio" value="cod" required name="payment_method"/> Cash On
                                            Delivery
                                        </label>
                                    </span>
                                </div>
                                <button type="submit" class="btn btn-primary btn-lg btn-block">
                                    Checkout
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cart-page-scripts'); ?>
    <script>

        function removeItemFromCart(cartItemId) {
            var isConfirm = confirm('Are you sure?');
            if (isConfirm) {
                $.ajax({
                    url: '<?php echo route('frontend.cart.remove.item'); ?>',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        cartItemId: cartItemId
                    },
                    beforeSend: function () {

                    },
                    success: function (data) {
                        $("#item-" + cartItemId).remove();
                        $("#head-cart-count").html(data.cart_count);
                        return (data.cart_count == 0) ? window.location.reload(true) : false;
                    },
                    error: function (data) {

                    }
                });
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
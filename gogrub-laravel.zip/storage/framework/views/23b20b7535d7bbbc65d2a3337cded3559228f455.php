<?php echo e(Form::open(['route' => ['frontend.auth.password.change'], 'class' => 'form-horizontal', 'method' => 'patch'])); ?>


    <div class="form-group">
        <?php echo e(Form::label('old_password', trans('validation.attributes.frontend.register-user.old_password'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::input('password', 'old_password', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.frontend.register-user.old_password')])); ?>

        </div>
    </div>

    <div class="form-group">
        <?php echo e(Form::label('password', trans('validation.attributes.frontend.register-user.new_password'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::input('password', 'password', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.frontend.register-user.new_password')])); ?>

        </div>
    </div>

    <div class="form-group">
        <?php echo e(Form::label('password_confirmation', trans('validation.attributes.frontend.register-user.new_password_confirmation'), ['class' => 'col-md-4 control-label'])); ?>

        <div class="col-md-6">
            <?php echo e(Form::input('password', 'password_confirmation', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.frontend.register-user.new_password_confirmation')])); ?>

        </div>
    </div>

    <div class="form-group">
        <div class="col-md-6 col-md-offset-4">
            <?php echo e(Form::submit(trans('labels.general.buttons.update'), ['class' => 'btn btn-primary', 'id' => 'change-password'])); ?>

        </div>
    </div>

<?php echo e(Form::close()); ?>
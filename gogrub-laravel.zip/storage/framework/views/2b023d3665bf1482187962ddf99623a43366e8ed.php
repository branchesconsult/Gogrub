<?php $__env->startSection('before-styles'); ?>
    <?php echo Html::style(asset('frontend/lightgallery/css/lightgallery.css')); ?>

    <?php echo Html::style(asset('frontend/lightslider/css/lightslider.css')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="product-detail-page">
        <?php echo $__env->make('frontend.includes.search-fullwidth-banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(!userSetLocation()): ?>
            <div class="tooltip-msg">
                <div class="alert alert-info">
                    Chef do not deliver to your area
                </div>
            </div>
        <?php endif; ?>
    </div>
    <section class="food-detail">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-md-12">
                    <div class="row">
                        <div class="col-12 food-main">
                            <ul id="product-detail-banner">
                                <?php $__currentLoopData = $product['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li data-src="<?php echo getImgSrc($val['image_large']); ?>"
                                        data-thumb="<?php echo getImgSrc($val['small_thumb']); ?>">
                                        <img src="<?php echo getImgSrc($val['medium_thumb'], 480, 480); ?>"/>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-md-12">
                    <div class="row">

                        <div class="col-9 food-title">
                            <h2><?php echo $product['name']; ?></h2>
                            <p><?php echo $product['description']; ?>

                            </p>
                        </div>

                        <div class="col-3">
                            <h3 class="text-right">
                                <strong><?php echo $product['price_view']; ?></strong>
                            </h3>
                        </div>

                        <div class="col-12">
                            <div class="star-rating d-inline-block">
                                <?php echo printRatingStars($product['chef']['avg_rating']); ?>

                            </div>
                            <div class="chef-review d-inline-block">
                                (<?php echo count($product['chef']['rating_reviews']); ?>)
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="food-boxes d-flex">
                                <div class="food-box">
                                    <strong>Servings Left</strong>
                                    <span><?php echo $product['servings_left']; ?></span>
                                </div>
                                <div class="food-box">
                                    <strong>Serving Size</strong>
                                    <span>
                                        <?php for($i=1;$i<=$product['serving_size'];$i++): ?>
                                            <i class="fa fa-user"></i>
                                        <?php endfor; ?>
                                    </span>
                                </div>
                                <div class="food-box">
                                    <strong>Availability</strong>
                                    <span><?php echo $product['availability_time']; ?></span>
                                </div>
                                <div class="food-box">
                                    <strong>Posted</strong>
                                    <span><?php echo $product['posted_at']; ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 food-chef">
                            <img src="<?php echo getImgSrc($product['chef']['avatar'], 70, 70); ?>"/>
                            <h5>
                                <strong>
                                    <?php echo $product['chef']['full_name']; ?>

                                </strong>
                            </h5>
                            
                            <?php if(!userSetLocation()): ?>
                                <button
                                        onclick="scrollToEle('address-autocomplete')"
                                        class="btn btn-success">
                                    Add to meal
                                </button>
                            <?php elseif(userSetLocation() && $chefDistance <= getMinDeliveryDistance()): ?>
                                <button
                                        onclick="openBsModal('addToCartModel')"
                                        class="btn btn-success">
                                    Add to meal
                                </button>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    Chef do not deliver to your address
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <?php echo $__env->make('frontend.partials.rating-reviews',[
                'rating_reviews' => $product['chef']['rating_reviews'],
                'colSize' => 7
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="col-xl-5 col-md-12">
                    <?php if(!empty($product['chef']['products'])): ?>
                        <p class="text-center">Other Meals by <strong><?php echo $product['chef']['full_name']; ?></strong></p>
                        <div class="row">
                            <?php echo $__env->make('frontend.partials.product-grid', [
                            'products' => $product['chef']['products'],
                            'colSize' => 6
                            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </section>
    <?php echo $__env->make('frontend.includes.add-to-card-model', ['product_id' => $product['id']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('before-scripts'); ?>
    <?php echo Html::script(asset('frontend/lightslider/js/lightslider.min.js')); ?>

    <?php echo Html::script(asset('frontend/lightgallery/js/lightgallery.js')); ?>

    <script>
        $(document).ready(function () {
            $("#product-detail-banner").lightSlider({
                gallery: true,
                item: 1,
                vertical: true,
                verticalHeight: 480,
                vThumbWidth: 120,
                thumbItem: 8,
                thumbMargin: 10,
                slideMargin: 0,
                onSliderLoad: function (el) {
                    el.lightGallery({
                        selector: '#product-detail-banner .lslide'
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="col-xl-7 col-md-12">
    <?php if(count($rating_reviews) > 0): ?>
        <div class="order-comments">
            <h2>Reviews (<?php echo count($rating_reviews); ?>)</h2>
            <div class="order-scroll">
                <?php $__currentLoopData = $rating_reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cmnt-box">
                        <img src="<?php echo getImgSrc($val['user']['avatar'], 70, 70); ?>"/>
                        <h5><?php echo $val['user']['full_name']; ?></h5>
                        <p>“<?php echo $val['review']; ?>”</p>
                        <span>
                                        <?php echo $val['posted_at']; ?>

                            <br/><?php echo printRatingStars($val['rating']); ?>

                                    </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
</div>
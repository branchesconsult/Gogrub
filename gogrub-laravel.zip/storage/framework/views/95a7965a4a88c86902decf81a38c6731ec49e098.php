<?php $__env->startSection('before-styles'); ?>
    <?php echo Html::style(asset('frontend/lightgallery/css/lightgallery.css')); ?>

    <?php echo Html::style(asset('frontend/lightslider/css/lightslider.css')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('frontend.partials.product-grid', ['colSize' => 3], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-12">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
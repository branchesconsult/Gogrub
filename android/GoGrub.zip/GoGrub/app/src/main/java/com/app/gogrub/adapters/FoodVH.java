package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.gogrub.R;

/**
 * Created by farazqureshi on 29/07/2018.
 */

public class FoodVH extends RecyclerView.ViewHolder{

    ImageView iv_img;
    TextView tv_food, tv_chef, tv_price, tv_serving, tv_status, tv_serving_left;
    RatingBar ratingBar;
    LinearLayout ll_del;
    RelativeLayout parent;

    public FoodVH(View itemView) {
        super(itemView);
        tv_chef = itemView.findViewById(R.id.tv_chef);
        tv_food = itemView.findViewById(R.id.tv_food);
        iv_img = itemView.findViewById(R.id.iv_img);
        tv_price = itemView.findViewById(R.id.tv_price);
        tv_serving_left = itemView.findViewById(R.id.tv_serving_left);
        tv_serving = itemView.findViewById(R.id.tv_serving_size);
        tv_status = itemView.findViewById(R.id.tv_status);
        ratingBar = itemView.findViewById(R.id.ratingbar);
        ll_del = itemView.findViewById(R.id.ll_del);
        parent = itemView.findViewById(R.id.root);
    }
}

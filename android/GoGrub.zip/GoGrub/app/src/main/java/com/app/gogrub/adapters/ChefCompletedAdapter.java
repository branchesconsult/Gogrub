package com.app.gogrub.adapters;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.activities.ChefOrderDetail;
import com.app.gogrub.models.chefOrders.Order;

import java.util.ArrayList;

public class ChefCompletedAdapter extends RecyclerView.Adapter<ChefCompleteVH> {

    Activity activity;
    ArrayList<Order> list;

    public ChefCompletedAdapter(Activity activity, ArrayList<Order> list) {
        this.activity = activity;
        this.list = list;
    }

    @NonNull
    @Override
    public ChefCompleteVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ChefCompleteVH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_complete, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ChefCompleteVH holder, int position) {
        final Order item = list.get(position);
        if (item.getDetail().size() > 0) {
            ArrayList<String> listProducts = new ArrayList<>();
            for (int i = 0; i < item.getDetail().size(); i++) {
                if (item.getDetail().get(i).getProduct() != null)
                    listProducts.add(item.getDetail().get(i).getProduct().getName());
            }
            holder.tvOrderList.setText(listProducts.toString().substring(1, listProducts.toString().length() - 1));
        }
        holder.tvOrderid.setText("ID: " + item.getInvoiceNum());
        holder.tvTotalPrice.setText("Rs " + item.getTotal());
        holder.tvOrdertime.setText(item.getCreatedAt());
        holder.ratingbar.setRating((float) item.getAvgRating());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(new Intent(activity, ChefOrderDetail.class));
                i.putExtra("o_id", item.getId() + "");
                i.putExtra("completed", "completed");
                activity.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

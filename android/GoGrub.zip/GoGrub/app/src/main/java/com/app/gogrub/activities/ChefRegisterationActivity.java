package com.app.gogrub.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.app.gogrub.R;
import com.app.gogrub.adapters.ChefImageAdapter;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.ImageUtils;
import com.app.gogrub.utils.PermissionManager;
import com.app.gogrub.utils.SessionManager;

import java.io.File;
import java.util.ArrayList;

import okhttp3.MediaType;
import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ChefRegisterationActivity extends AppCompatActivity {

    private ImageView ivCancel;
    private ImageView ivCamera;
    private ImageView ivGallery;
    private RecyclerView imgRecycler;

    private Button btnNext;

    private static final int SELECT_FILE = 0;
    private static final int REQUEST_CAMERA = 1;
    private PermissionManager permissionsManager;
    ArrayList<String> files; //These are the uris for the files to be uploaded
    MediaType mediaType = MediaType.parse("");

    ArrayList<String> list = new ArrayList<>();
    private String img_path;
    private String userChoosenTask;
    private ChefImageAdapter adapter;
    SessionManager sessionManager;
    private String imageFilePath = "";
    private Uri photoURI;

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-10 14:37:45 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    private void findViews() {
        ivCancel = (ImageView) findViewById(R.id.iv_cancel);
        ivCamera = (ImageView) findViewById(R.id.iv_camera);
        ivGallery = (ImageView) findViewById(R.id.iv_gallery);
        imgRecycler = (RecyclerView) findViewById(R.id.img_recycler);
        btnNext = (Button) findViewById(R.id.btn_next);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cnic_layout);

        findViews();

        sessionManager = new SessionManager(this);
        files = new ArrayList<>();

        permissionsManager = PermissionManager.getInstance(this);
        permissionsManager.getPermissionifNotAvailble(new String[]{Manifest.permission.ACCESS_NETWORK_STATE
                , Manifest.permission.INTERNET
                , Manifest.permission.READ_EXTERNAL_STORAGE
                , Manifest.permission.WRITE_EXTERNAL_STORAGE
                , Manifest.permission.CAMERA
        }, 111);

        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        ivCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (files.size() < 2) {
                    cameraIntent();
                } else {
                    Toast.makeText(ChefRegisterationActivity.this, "Only 2 images can be uploaded", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ivGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (files.size() < 2) {
                    galleryIntent();
                } else {
                    Toast.makeText(ChefRegisterationActivity.this, "Only 2 images can be uploaded", Toast.LENGTH_SHORT).show();
                }
            }
        });

        adapter = new ChefImageAdapter(this, list, btnNext);

        imgRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        imgRecycler.setAdapter(adapter);

        btnNext.setEnabled(false);
        btnNext.setBackground(getResources().getDrawable(R.drawable.btn_gray));

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (files.size() > 0) {
                    if (files.size() == 2) {
                        Constants.CNIC_Images.addAll(files);
                        startActivity(new Intent(ChefRegisterationActivity.this, KitchenRegActivity.class));
                    } else {
                        Toast.makeText(ChefRegisterationActivity.this, "Please upload front and back both sides of CNIC", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ChefRegisterationActivity.this, "Please select images", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void filesRemove(int i) {
        files.remove(i);
        list.remove(i);
        if (files.size() < 2) {
            btnNext.setEnabled(false);
            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_gray));
        } else {
            btnNext.setEnabled(true);
            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_field));
        }
        adapter.notifyDataSetChanged();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Library",
                "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(ChefRegisterationActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask = "Choose from Library";
                    galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent() {
        EasyImage.openGallery(this, SELECT_FILE);
    }

    private void cameraIntent() {
        EasyImage.openCamera(this, REQUEST_CAMERA);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        EasyImage.handleActivityResult(requestCode, resultCode, data, this, new DefaultCallback() {
            @Override
            public void onImagePicked(File imageFile, EasyImage.ImageSource source, int type) {
                if (type == SELECT_FILE) {
                    img_path = new File(ImageUtils.compressImage(imageFile.getPath())).getPath();
                    Log.d("PATH", "" + img_path);

                    if (img_path != null) {
                        list.add(0, img_path);
                        files.add(img_path);
                        adapter.notifyDataSetChanged();

                        imgRecycler.smoothScrollToPosition(0);
                        if (files.size() == 2) {
                            btnNext.setEnabled(true);
                            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_field));
                        } else {
                            btnNext.setEnabled(false);
                            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_gray));

                        }
                    }
                } else if (type == REQUEST_CAMERA) {
                    img_path = new File(ImageUtils.compressImage(imageFile.getPath())).getPath();
                    Log.d("PATH", "" + img_path);

                    if (img_path != null) {
                        list.add(0, img_path);
                        files.add(img_path);
                        adapter.notifyDataSetChanged();

                        imgRecycler.smoothScrollToPosition(0);
                        if (files.size() == 2) {
                            btnNext.setEnabled(true);
                            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_field));
                        } else {
                            btnNext.setEnabled(false);
                            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_gray));

                        }
                    }
                }
            }
        });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //  Toast.makeText(ParentActivity.this, "Request Code => "+requestCode, Toast.LENGTH_SHORT).show();
        switch (requestCode) {
            case 111:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {


                } else {
                    Toast.makeText(this, "Please allow the location permission. Thanks", Toast.LENGTH_SHORT).show();
                    permissionsManager = PermissionManager.getInstance(ChefRegisterationActivity.this);
                    permissionsManager.getPermissionifNotAvailble(new String[]{Manifest.permission.ACCESS_NETWORK_STATE
                            , Manifest.permission.INTERNET
                            , Manifest.permission.READ_EXTERNAL_STORAGE
                            , Manifest.permission.WRITE_EXTERNAL_STORAGE
                            , Manifest.permission.CAMERA
                    }, 111);
                }
                break;
            default:
                break;
        }
    }


}

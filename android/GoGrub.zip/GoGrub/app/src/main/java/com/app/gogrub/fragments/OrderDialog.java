package com.app.gogrub.fragments;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.gogrub.R;
import com.app.gogrub.activities.CartActivity;
import com.app.gogrub.models.orderProduct.OrderProduct;
import com.app.gogrub.utils.AnimationUtility;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.CustomDialoge;


public class OrderDialog extends DialogFragment {

    View view;
    Activity activity;
    Handler handler;
    LinearLayout ll_view;
    ImageView iv_cancel, iv_add, iv_minus;
    EditText et_desc;
    TextView tv_food_name, tv_ok, tv_price, tv_count, tv_cancel;

    public OrderDialog() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        try {
            view = inflater.inflate(R.layout.order_layout, container, false);
            handler = new Handler();

            getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
            getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            setStyle(DialogFragment.STYLE_NO_FRAME, android.R.style.Theme);

            ll_view = view.findViewById(R.id.root);
            iv_cancel = view.findViewById(R.id.iv_cancel);
            iv_add = view.findViewById(R.id.iv_add);
            tv_price = view.findViewById(R.id.tv_price);
            iv_minus = view.findViewById(R.id.iv_minus);
            et_desc = view.findViewById(R.id.et_desc);
            tv_food_name = view.findViewById(R.id.tv_food_name);

            tv_ok = view.findViewById(R.id.tv_ok);
            tv_cancel = view.findViewById(R.id.tv_cancel);
            tv_count = view.findViewById(R.id.tv_count);

            tv_ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final OrderProduct product = new OrderProduct(Constants.product.getProduct().getId(), Constants.product.getProduct().getName(), tv_count.getText().toString(), et_desc.getText().toString(), Constants.product.getProduct().getPrice());
                    for (int i = 0; i < Constants.orderProducts.size(); i++) {
                        if (Constants.product.getProduct().getId() == Constants.orderProducts.get(i).getId()) {
                            Constants.orderProducts.remove(Constants.orderProducts.get(i));
                            break;
                        }
                    }
                    if (Constants.CHEF_ID == 0) {
                        Constants.CHEF_ID = Constants.product.getProduct().getChefId();
                        Constants.CHEFNAME = Constants.product.getProduct().getChef().getFullName();
                        Constants.CHEF_PHONE = Constants.product.getProduct().getChef().getMobile();
                        Constants.orderProducts.add(product);
                        startActivity(new Intent(activity, CartActivity.class));
                        activity.finish();
                    } else {
                        if (Constants.CHEF_ID != Constants.product.getProduct().getChefId()) {
                            String msg = "Product is not from the same chef, Your current product in cart will be lost";
                            String title = "Attention";
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
                            alertDialogBuilder.setTitle(title);
                            alertDialogBuilder.setMessage(msg);
                            alertDialogBuilder.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                    Constants.orderProducts.clear();
                                    Constants.orderProducts.add(product);
                                    startActivity(new Intent(activity, CartActivity.class));
                                    activity.finish();

                                }
                            });
                            alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();

                                }
                            });
                            alertDialogBuilder.create();
                            alertDialogBuilder.show();

                        } else {
                            Constants.orderProducts.add(product);
                            startActivity(new Intent(activity, CartActivity.class));
                            activity.finish();
                        }
                    }

                }
            });

            iv_cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dismissWithAnimation();
                }
            });

            tv_cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dismissWithAnimation();
                }
            });

            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    ll_view.setVisibility(View.VISIBLE);
                    AnimationUtility.slideInDown(ll_view);
                }
            }, 100);

            tv_food_name.setText(Constants.product.getProduct().getName().substring(0, 1).toUpperCase() + Constants.product.getProduct().getName().substring(1));
            tv_price.setText("Rs " + Constants.product.getProduct().getPrice());

            iv_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int i = Integer.parseInt(tv_count.getText().toString());
                    if ((i + 1) <= Constants.product.getProduct().getRemaining_servings()) {
                        tv_count.setText((i + 1) + "");
                        tv_price.setText("Rs " + (Constants.product.getProduct().getPrice() * Integer.parseInt(tv_count.getText().toString())));
                    } else {
                        CustomDialoge.show(getActivity(), "Attention", "Only " + Constants.product.getProduct().getRemaining_servings() + " servings left");
                    }
                }
            });

            iv_minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!tv_count.getText().toString().equalsIgnoreCase("1")) {
                        int i = Integer.parseInt(tv_count.getText().toString());
                        tv_count.setText((i - 1) + "");
                        tv_price.setText("Rs " + (Constants.product.getProduct().getPrice() * Integer.parseInt(tv_count.getText().toString())));
                    }
                }
            });

        } catch (Exception e) {
            Log.e("oncreate ", e.toString());
            e.printStackTrace();
        }

        return view;
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.activity = activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setLayout(width, height);
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new Dialog(getActivity(), getTheme()) {
            @Override
            public void onBackPressed() {
                dismissWithAnimation();
            }
        };
    }

    private void dismissWithAnimation() {
        try {
            AnimationUtility.slideOutUp(ll_view);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    getDialog().dismiss();
                }
            }, 500);
        } catch (Exception e) {
            Log.e("oncreate ", e.toString());
            e.printStackTrace();
        }
    }

}

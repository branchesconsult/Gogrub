
package com.app.gogrub.models.msgResponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Receiver {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("full_name")
    @Expose
    private String fullName;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("country_code")
    @Expose
    private Integer countryCode;
    @SerializedName("avatar")
    @Expose
    private String avatar;
    @SerializedName("dob")
    @Expose
    private Object dob;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("is_chef")
    @Expose
    private Boolean isChef;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("confirmation_code")
    @Expose
    private String confirmationCode;
    @SerializedName("confirmed")
    @Expose
    private Integer confirmed;
    @SerializedName("is_term_accept")
    @Expose
    private Integer isTermAccept;
    @SerializedName("created_by")
    @Expose
    private Integer createdBy;
    @SerializedName("updated_by")
    @Expose
    private Object updatedBy;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("updated_at")
    @Expose
    private String updatedAt;
    @SerializedName("deleted_at")
    @Expose
    private Object deletedAt;
    @SerializedName("avg_rating")
    @Expose
    private Integer avgRating;
    @SerializedName("applied_as_chef")
    @Expose
    private Boolean appliedAsChef;
    @SerializedName("avg_reply_time")
    @Expose
    private Integer avgReplyTime;
    @SerializedName("success_percentage")
    @Expose
    private String successPercentage;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(Integer countryCode) {
        this.countryCode = countryCode;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public Object getDob() {
        return dob;
    }

    public void setDob(Object dob) {
        this.dob = dob;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getIsChef() {
        return isChef;
    }

    public void setIsChef(Boolean isChef) {
        this.isChef = isChef;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getConfirmationCode() {
        return confirmationCode;
    }

    public void setConfirmationCode(String confirmationCode) {
        this.confirmationCode = confirmationCode;
    }

    public Integer getConfirmed() {
        return confirmed;
    }

    public void setConfirmed(Integer confirmed) {
        this.confirmed = confirmed;
    }

    public Integer getIsTermAccept() {
        return isTermAccept;
    }

    public void setIsTermAccept(Integer isTermAccept) {
        this.isTermAccept = isTermAccept;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    public Object getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Object updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Object getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Object deletedAt) {
        this.deletedAt = deletedAt;
    }

    public Integer getAvgRating() {
        return avgRating;
    }

    public void setAvgRating(Integer avgRating) {
        this.avgRating = avgRating;
    }

    public Boolean getAppliedAsChef() {
        return appliedAsChef;
    }

    public void setAppliedAsChef(Boolean appliedAsChef) {
        this.appliedAsChef = appliedAsChef;
    }

    public Integer getAvgReplyTime() {
        return avgReplyTime;
    }

    public void setAvgReplyTime(Integer avgReplyTime) {
        this.avgReplyTime = avgReplyTime;
    }

    public String getSuccessPercentage() {
        return successPercentage;
    }

    public void setSuccessPercentage(String successPercentage) {
        this.successPercentage = successPercentage;
    }

}

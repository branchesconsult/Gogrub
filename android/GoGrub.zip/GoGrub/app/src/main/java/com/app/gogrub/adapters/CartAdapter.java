package com.app.gogrub.adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.app.gogrub.R;
import com.app.gogrub.models.orderProduct.OrderProduct;
import com.app.gogrub.utils.Constants;

import java.util.ArrayList;

/**
 * Created by devicebee on 01/08/2018.
 */

public class CartAdapter extends RecyclerView.Adapter<CartItemVH> {

    Activity activity;
    ArrayList<OrderProduct> list;
    TextView tv_subtotal, tv_total;

    public CartAdapter(Activity activity, ArrayList<OrderProduct> list, TextView tv_subtotal, TextView tv_total) {
        this.activity = activity;
        this.list = list;
        this.tv_subtotal = tv_subtotal;
        this.tv_total = tv_total;

    }

    @Override
    public CartItemVH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_item, parent, false);
        return new CartItemVH(v);
    }

    @Override
    public void onBindViewHolder(final CartItemVH holder, final int position) {

        holder.tv_price.setText((list.get(position).getPrice() * Integer.parseInt(list.get(position).getQty())) + "");
        holder.tv_quantity.setText(list.get(position).getQty());
        holder.tv_name.setText(list.get(position).getName().substring(0, 1).toUpperCase() + list.get(position).getName().substring(1));

        holder.iv_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.tv_quantity.setText((Integer.parseInt(list.get(position).getQty()) + 1) + "");
                list.get(position).setQty(holder.tv_quantity.getText().toString());
                notifyDataSetChanged();

            }
        });

        holder.iv_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!holder.tv_quantity.getText().toString().equalsIgnoreCase("1")) {
                    holder.tv_quantity.setText((Integer.parseInt(list.get(position).getQty()) - 1) + "");
                    list.get(position).setQty(holder.tv_quantity.getText().toString());
                    notifyDataSetChanged();
                }
            }
        });

        holder.ll_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
                alertDialogBuilder.setTitle("Attention");
                alertDialogBuilder.setMessage("Are you sure you want to Delete this?");
                alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
//                    Toast.makeText(NewPlacesActivity.this, "Removed", Toast.LENGTH_SHORT).show();
                        list.remove(position);
                        notifyDataSetChanged();
                    }
                });
                alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        notifyDataSetChanged();

                    }
                });
                alertDialogBuilder.create();
                alertDialogBuilder.show();
            }
        });

        calculateTotal(list, tv_subtotal, tv_total);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void calculateTotal(ArrayList<OrderProduct> list, TextView tv_subtotal, TextView tv_total) {

        Constants.orderProducts = list;

        int sub_price = 0;
        for (int i = 0; i < list.size(); i++) {
            sub_price = sub_price + (Integer.parseInt(list.get(i).getQty()) * list.get(i).getPrice());
        }

        tv_subtotal.setText("Rs " + sub_price);
        tv_total.setText("Rs " + "" + (sub_price + 5));
    }

    public void removeItem(int position) {
        list.remove(position);
        // notify the item removed by position
        // to perform recycler view delete animations
        // NOTE: don't call notifyDataSetChanged()
        notifyItemRemoved(position);
    }

    public void restoreItem(OrderProduct item, int position) {
        list.add(position, item);
        // notify item added by position
        notifyItemInserted(position);
    }
}

package com.app.gogrub.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.PrepareResponse;
import com.app.gogrub.models.orderPlacement.OrderResponse;
import com.app.gogrub.models.orderProduct.Order;
import com.app.gogrub.models.orderProduct.OrderProduct;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;

import org.angmarch.views.NiceSpinner;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class NextStep extends AppCompatActivity implements ResponseHandler {

    TextView tv_ok, tv_phone, tv_address, tv_cancel, tv_del_charges, tv_subtotal, tv_total;
    NiceSpinner spn_time;

    ArrayList<String> times = new ArrayList<>();
    ArrayList<String> payments = new ArrayList<>();

    SessionManager sessionManager;
    private String est_time;

    String pid;
    private int del_charges;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_step);

        sessionManager = new SessionManager(this);

        tv_ok = findViewById(R.id.tv_ok);
        tv_cancel = findViewById(R.id.tv_cancel);
        tv_phone = findViewById(R.id.phone);
        tv_address = findViewById(R.id.address);
        spn_time = findViewById(R.id.spn_time);
        tv_subtotal = findViewById(R.id.tv_subtotal);
        tv_total = findViewById(R.id.tv_total);
        tv_del_charges = findViewById(R.id.del_charges);
//        spn_paymethod = findViewById(R.id.spn_payment_method);

        payments.add("Cash on Delivery");

        tv_phone.setText("+92" + sessionManager.get(Constants.PHONE));

//        ArrayAdapter<String> timeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, times);
//        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spn_time.setAdapter(timeAdapter);


        spn_time.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                String item = times.get(position);
                String[] splited = item.split("\\s+");
                if (splited[0].length() == 2) {
                    int val = Integer.parseInt(item.substring(0, 2));
                    est_time = val + "";
                } else {
                    int val = Integer.parseInt(item.substring(0, 3));
                    est_time = val + "";
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

//        ArrayAdapter<String> paymentAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, payments);
//        paymentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spn_paymethod.setAdapter(paymentAdapter);

        tv_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Internet.isAvailable(NextStep.this)) {
                    if (!Constants.ADDRESS_ONE.equalsIgnoreCase("address")) {
                        if (est_time != null) {
                            Order order = new Order();
                            order.setCustomer_phone("+92" + sessionManager.get(Constants.PHONE));
                            order.setCustomer_address(Constants.ADDRESS_ONE);
                            order.setCustomer_lat(Constants.LAT);
                            order.setCustomer_lng(Constants.LNG);
                            order.setEstimate_delivery_mins(est_time);
                            order.setList(Constants.orderProducts);
                            order.setPayment_method("cod");
                            Loading.show(NextStep.this, false, "Please wait...");
                            new RestCaller(NextStep.this, GoGrub.getRestClient().placeOrder(sessionManager.get(Constants.ACCESS_TOKEN), order), 1);
                        } else {
                            Toast.makeText(NextStep.this, "Please select the time", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(NextStep.this, "Please select the address", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(NextStep.this, "Please check your intenet connection", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        tv_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(NextStep.this, MapsActivity.class));
            }
        });


        if (Constants.orderProducts.size() > 0) {
            ArrayList<String> productIds = new ArrayList<>();
            for (int i = 0; i < Constants.orderProducts.size(); i++) {
                productIds.add(Constants.orderProducts.get(i).getId() + "");
            }
            pid = productIds.toString().substring(1, productIds.toString().length() - 1);
        } else {
            pid = Constants.orderProducts.get(0).getId() + "";
        }

        getEstimatedTimes(pid);
    }

    private void getEstimatedTimes(String pid) {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(NextStep.this, GoGrub.getRestClient().getPreprationTime(sessionManager.get(Constants.ACCESS_TOKEN), pid), 2);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.ADDRESS_ONE.equalsIgnoreCase("address")) {
            tv_address.setText("Please select address");
        } else {
            tv_address.setText(Constants.ADDRESS_ONE);
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }


    public void calculateTotal(ArrayList<OrderProduct> list, TextView tv_subtotal, TextView tv_total) {
        int sub_price = 0;
        for (int i = 0; i < list.size(); i++) {
            sub_price = sub_price + (Integer.parseInt(list.get(i).getQty()) * list.get(i).getPrice());
        }
        tv_del_charges.setText("Rs " + del_charges);
        tv_subtotal.setText("Rs " + sub_price);
        tv_total.setText("Rs " + (sub_price + del_charges));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        if (reqCode == 1) {
            Constants.orderProducts.clear();
            OrderResponse orderResponse = (OrderResponse) response.body();
            Intent i = new Intent(NextStep.this, OrderPlacedActivity.class);
            Constants.ORDERID = orderResponse.getOrder().getInvoiceNum() + "";
            Constants.CHEF_ID = orderResponse.getOrder().getChefId();
            Constants.ORDERTIME = orderResponse.getOrder().getEstimateDeliveryMins() + "";
            startActivity(i);
        } else {
            PrepareResponse prepareResponse = (PrepareResponse) response.body();

            est_time = prepareResponse.getDeliverySlots().get(0) + "";

            for (int i = 0; i < prepareResponse.getDeliverySlots().size(); i++) {
                times.add(prepareResponse.getDeliverySlots().get(i) + " mins");
            }
            spn_time.attachDataSource(times);

            del_charges = prepareResponse.getDelieveryCharges();

            calculateTotal(Constants.orderProducts, tv_subtotal, tv_total);

        }

    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();
        Toast.makeText(this, error.getMsg(), Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();
        Toast.makeText(this, error.getError().getMessage(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();
    }


}

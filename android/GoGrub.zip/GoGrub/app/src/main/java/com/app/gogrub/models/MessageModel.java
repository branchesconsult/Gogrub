package com.app.gogrub.models;

/**
 * Created by farazqureshi on 02/08/2018.
 */

public class MessageModel {

    public String msg;
    public  boolean isSender;

    public MessageModel(String msg, boolean isSender) {
        this.msg = msg;
        this.isSender = isSender;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isSender() {
        return isSender;
    }

    public void setSender(boolean sender) {
        isSender = sender;
    }
}

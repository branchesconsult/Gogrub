package com.app.gogrub.adapters;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.activities.ChatActivity;
import com.app.gogrub.models.chatMessages.ChatsSummery;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MessageAdapter extends RecyclerView.Adapter<MessageVH> {

    Activity activity;
    ArrayList<ChatsSummery> list;

    public MessageAdapter(Activity activity, ArrayList<ChatsSummery> list) {
        this.activity = activity;
        this.list = list;
    }

    @NonNull
    @Override
    public MessageVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MessageVH(LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_obj_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MessageVH holder, int position) {
        final ChatsSummery item = list.get(position);

        Picasso.with(activity).load(item.getSender().getAvatar()).fit().centerCrop().placeholder(R.drawable.img_placeholder).into(holder.ivDp);
        holder.tv_name.setText(item.getSender().getFullName());
        holder.tv_msg.setText("Order #: "+item.getOrderId());
        holder.tv_time.setText(item.getCreatedAt());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(activity, ChatActivity.class);
                i.putExtra("o_id", item.getOrderId() + "");
                i.putExtra("r_id", item.getSenderId() + "");
                i.putExtra("name", item.getSender().getFullName() + "");
                activity.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}


package com.app.gogrub.models.recMsg;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RecMessage {

    @SerializedName("nameValuePairs")
    @Expose
    private NameValuePairs nameValuePairs;

    public NameValuePairs getNameValuePairs() {
        return nameValuePairs;
    }

    public void setNameValuePairs(NameValuePairs nameValuePairs) {
        this.nameValuePairs = nameValuePairs;
    }

}

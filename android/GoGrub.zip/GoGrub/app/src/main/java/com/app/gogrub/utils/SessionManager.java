package com.app.gogrub.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by zeesh on 10/11/2016.
 */

public class SessionManager {
    public static final String WRONG_PAIR = "Key-Value pair cannot be blank or null";
    private static final String isLogin = "isLogin";
    private static final String keyName = "userName";
    private static final String keyEmail = "userEmail";
    private static final String key = "key";
    private static final String keyImageUrl = "img_url";
    private static final String PREF_NAME = "sessionPreference";
    private static SharedPreferences.Editor editor;
    private static SharedPreferences pref;
    private static Context context;
    private static int PRIVATE_MODE = 0;

    public SessionManager(Context _contxt) {
        context = _contxt;
        pref = _contxt.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public static boolean put(final String key, final String value) {
        if (key == null || key.equals("")) {
            throw new IllegalArgumentException(WRONG_PAIR);
        }
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor.putString(key, value);
        return editor.commit();
    }

    public static boolean put(final String key, final boolean value) {
        if (key == null || key.equals("")) {
            throw new IllegalArgumentException(WRONG_PAIR);
        }
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor.putBoolean(key, value);
        return editor.commit();
    }

    public static String get(String accessToken) {

        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        String number = pref.getString(accessToken, "");
        return number;
    }

    public static int getInt(final String key) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return pref.getInt(key, 0);
    }

    public static void remove(String key) {
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor.remove(key);
        editor.apply();
    }

    public static Boolean getBoolean(final String key) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return pref.getBoolean(key, false);
    }

    public void createLoginSession() {

        editor.putString(isLogin, "true");
        editor.commit();
    }

    public void saveUserName(String name) {
        editor.putString(keyName, name);
        editor.commit();
    }

    public void putAccessToken(String token) {
        editor.putString(Constants.ACCESS_TOKEN, token);
        editor.commit();
    }

    public boolean checkLogin() {
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        String login = pref.getString(isLogin, "");

        return login.equalsIgnoreCase("true");
    }

    public void clearSession() {
        editor.clear();
        editor.commit();
    }
}

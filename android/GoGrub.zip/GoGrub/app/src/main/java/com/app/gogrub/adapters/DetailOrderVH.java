package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.app.gogrub.R;

/**
 * Created by farazqureshi on 01/08/2018.
 */

public class DetailOrderVH extends RecyclerView.ViewHolder{

    TextView productName, tv_qty, tv_price;

    public DetailOrderVH(View itemView) {
        super(itemView);
        productName = itemView.findViewById(R.id.productName);
        tv_qty = itemView.findViewById(R.id.tv_quantity);
        tv_price = itemView.findViewById(R.id.tv_price);

    }
}

package com.app.gogrub;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.app.gogrub.activities.ChatActivity;
import com.app.gogrub.activities.ChefOrderDetail;
import com.app.gogrub.activities.OrderDetail;
import com.app.gogrub.models.NotificationModel;
import com.app.gogrub.models.NotificationModelMessage;
import com.app.gogrub.models.NotificationModelOrder;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;

/**
 * Created by zeeshan on 12/12/17.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";
    private boolean isInBackground;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        try {
            Log.e(TAG, "From: " + remoteMessage.getFrom());
            if (remoteMessage.getNotification() != null) {
                Log.e(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
            }
            if (remoteMessage.getData().size() > 0) {
                Log.e(TAG, "Message data payload: " + remoteMessage.getData());
            }

            ActivityManager.RunningAppProcessInfo myProcess = new ActivityManager.RunningAppProcessInfo();
            ActivityManager.getMyMemoryState(myProcess);
            isInBackground = myProcess.importance != ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND;

            String message = remoteMessage.getData().get("aps");


            Log.e(TAG, message);
//            Log.e(TAG, "Notification Message Body: " + remoteMessage.getNotification().getBody());
//            for (Map.Entry<String, String> entry : remoteMessage.getData().entrySet()) {
//                System.out.println(entry.getKey() + " : " + entry.getValue());
//            }
            sendNotification(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void sendMessageNotification(String message) {
        Gson gson = new Gson();
        NotificationModelMessage messageBody = gson.fromJson(message, NotificationModelMessage.class);
        Log.e("JSON", gson.toJson(messageBody));

        Intent i = new Intent(this, ChatActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.putExtra("o_id", messageBody.getData().getOrderId() + "");
        i.putExtra("r_id", messageBody.getData().getSenderId() + "");
        i.putExtra("name", messageBody.getData().getSender_obj().getFullName() + "");
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT);


        Bitmap rawBitmap = BitmapFactory.decodeResource(getResources(),
                R.drawable.app_icon_rounded);
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.ic_logo_svg)
                .setLargeIcon(rawBitmap)
                .setContentTitle(messageBody.getData().getSender_obj().getFullName())
                .setContentText(messageBody.getMessage())
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(messageBody.getData().getOrderId(), notificationBuilder.build());
    }

    private void sendNotificationScreen(String message, String type) {

        Gson gson = new Gson();
        NotificationModelOrder messageBody = gson.fromJson(message, NotificationModelOrder.class);
        Log.e("JSON", gson.toJson(messageBody));


        if (type.equalsIgnoreCase("customerOrderCreated") || type.equalsIgnoreCase("customerOrderUpdated")) {
            Intent intent = new Intent(this, OrderDetail.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            intent.putExtra("o_id", messageBody.getData().getId() + "");

//        intent.putExtra("order", messageBody.getData());

//        Constants.orderResult = messageBody.getData();

            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT);


            Bitmap rawBitmap = BitmapFactory.decodeResource(getResources(),
                    R.drawable.app_icon_rounded);
            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.ic_logo_svg)
                    .setLargeIcon(rawBitmap)
                    .setContentTitle(getString(R.string.app_name))
                    .setContentText(messageBody.getMessage())
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);

            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0, notificationBuilder.build());

        } else {
            Intent intent = new Intent(this, ChefOrderDetail.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("o_id", messageBody.getData().getId() + "");
//        intent.putExtra("order", messageBody.getData());

//        Constants.orderResult = messageBody.getData();

            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT);


            Bitmap rawBitmap = BitmapFactory.decodeResource(getResources(),
                    R.drawable.app_icon_rounded);
            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.ic_logo_svg)
                    .setLargeIcon(rawBitmap)
                    .setContentTitle(getString(R.string.app_name))
                    .setContentText(messageBody.getMessage())
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);

            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0, notificationBuilder.build());
        }


    }


    private void sendNotification(String msg) {
        Gson gson = new Gson();
        NotificationModel element = gson.fromJson(msg, NotificationModel.class);
        Log.e("JSON", gson.toJson(element));

        if (element.getType().equalsIgnoreCase("chat_message")) {
            if (!isInBackground && GoGrub.isChat) {
                Log.e(TAG, "Chat Open");
            } else {
                sendMessageNotification(gson.toJson(element));
            }
        } else if (element.getType().equalsIgnoreCase("customerOrderCreated") || element.getType().equalsIgnoreCase("customerOrderUpdated")) {
            sendNotificationScreen(gson.toJson(element), element.getType());
        } else if (element.getType().equalsIgnoreCase("chefOrderCreated") || element.getType().equalsIgnoreCase("chefOrderUpdated")) {
            sendNotificationScreen(gson.toJson(element), element.getType());
        }

    }
}


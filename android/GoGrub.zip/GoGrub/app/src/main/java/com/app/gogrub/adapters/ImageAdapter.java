package com.app.gogrub.adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.activities.AddProductActivity;
import com.app.gogrub.activities.ChefRegisterationActivity;
import com.app.gogrub.activities.KitchenRegActivity;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.ImageModel;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.CustomDialoge;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;

public class ImageAdapter extends RecyclerView.Adapter<ImageVH> implements ResponseHandler {

    Activity activity;
    ArrayList<ImageModel> list;

    int img_position;

    public ImageAdapter(Activity activity, ArrayList<ImageModel> list) {
        this.activity = activity;
        this.list = list;
    }

    @Override
    public ImageVH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.img_layout, parent, false);
        return new ImageVH(v);
    }

    @Override
    public void onBindViewHolder(ImageVH holder, final int position) {
        final ImageModel item = list.get(position);

        if (item.getPath().length() > 0) {
            if (item.isUrl()) {
                holder.iv_del.setVisibility(View.VISIBLE);
                Picasso.with(activity).load(item.getPath()).fit().centerCrop().placeholder(R.drawable.img_placeholder).into(holder.iv_img);
            } else {
                holder.iv_del.setVisibility(View.VISIBLE);
                Picasso.with(activity).load(new File(item.getPath())).fit().centerCrop().placeholder(R.drawable.img_placeholder).into(holder.iv_img);
            }
        } else {
            holder.iv_del.setVisibility(View.INVISIBLE);
            holder.iv_img.setImageResource(R.drawable.add_img);
        }


        holder.iv_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (item.isUrl) {

                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
                    alertDialogBuilder.setTitle("Attention");
                    alertDialogBuilder.setMessage("Are you sure you want to Delete this Image?");
                    alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            img_position = position;
                            deleteImage(item.getId());

//                    Toast.makeText(NewPlacesActivity.this, "Removed", Toast.LENGTH_SHORT).show();

                        }
                    });
                    alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();

                        }
                    });
                    alertDialogBuilder.create();
                    alertDialogBuilder.show();

                } else {
                    ((AddProductActivity) activity).filesRemove(position);
                }
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (item.getPath().length() == 0) {
                    if (Constants.checkPermission(activity))
                        if (activity instanceof AddProductActivity)
                            ((AddProductActivity) activity).selectImage();
                        else if (activity instanceof ChefRegisterationActivity)
                            ((ChefRegisterationActivity) activity).selectImage();
                        else
                            ((KitchenRegActivity) activity).selectImage();

                }
            }
        });
    }

    private void deleteImage(int id) {
        if (Internet.isAvailable(activity)) {
            Loading.show(activity, false, "Please wait...");
            new RestCaller(ImageAdapter.this, GoGrub.getRestClient().deleteImage(new SessionManager(activity).get(Constants.ACCESS_TOKEN), id), 1);
        } else {
            Toast.makeText(activity, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        GenericResponse genericResponse = (GenericResponse) response.body();
        CustomDialoge.show(activity, genericResponse.getMessage_title(), genericResponse.getMsg());
        list.remove(img_position);
        notifyDataSetChanged();
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();
    }
}

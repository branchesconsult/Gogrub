package com.app.gogrub.restapis;

import android.graphics.Bitmap;

/**
 * Created by zeeshan on 6/2/17.
 */

public interface iImageResponseHandler {
    void onDownloadCompleted(Bitmap image);

    void onDownloadError(String error);
}

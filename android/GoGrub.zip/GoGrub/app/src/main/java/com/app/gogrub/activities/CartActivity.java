package com.app.gogrub.activities;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.gogrub.R;
import com.app.gogrub.adapters.CartAdapter;
import com.app.gogrub.models.orderProduct.OrderProduct;
import com.app.gogrub.utils.Constants;

import java.util.ArrayList;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class CartActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<OrderProduct> list = new ArrayList<>();
    CartAdapter cartAdapter;
    public TextView tv_ok, tv_cancel, tv_subtotal, tv_total, tv_delCharges,step, no_data, btn_meals;
    LinearLayout bill_con, btn_con;
    RelativeLayout text_con;

    private AlertDialog.Builder alertDialogBuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        recyclerView = findViewById(R.id.recyclerView);

        step=findViewById(R.id.step);
        tv_ok = findViewById(R.id.tv_ok);
        tv_cancel = findViewById(R.id.tv_cancel);
        tv_subtotal = findViewById(R.id.tv_subtotal);
        tv_delCharges = findViewById(R.id.tv_del_charges);
        tv_total = findViewById(R.id.tv_total);
        bill_con = findViewById(R.id.bill_con);
        btn_con = findViewById(R.id.bottom_con);
        text_con = findViewById(R.id.text_con);
        no_data = findViewById(R.id.no_data);
        btn_meals = findViewById(R.id.btn_meals);

        if (Constants.orderProducts.size() > 0) {
            no_data.setVisibility(View.GONE);
            list.addAll(Constants.orderProducts);
        } else {
            bill_con.setVisibility(View.GONE);
            btn_con.setVisibility(View.GONE);
            text_con.setVisibility(View.GONE);
            step.setVisibility(View.GONE);
        }

        btn_meals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CartActivity.this, OtherMealsByChef.class));
            }
        });

        cartAdapter = new CartAdapter(this, list, tv_subtotal, tv_total);

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
//        ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);
//        new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(recyclerView);


        recyclerView.setAdapter(cartAdapter);

        tv_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Constants.orderProducts.clear();
            }
        });

        tv_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CartActivity.this, NextStep.class));
            }
        });

        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }



}

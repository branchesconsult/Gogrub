package com.app.gogrub.adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.models.MessageModel;

import java.util.ArrayList;

/**
 * Created by farazqureshi on 02/08/2018.
 */

public class ChatAdapter extends RecyclerView.Adapter<ChatVH> {

    Activity activity;
    ArrayList<MessageModel> list;

    public ChatAdapter(Activity activity, ArrayList<MessageModel> list) {
        this.activity = activity;
        this.list = list;
    }

    @Override
    public ChatVH onCreateViewHolder(ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.msg_layout, parent, false);
        return new ChatVH(v);
    }

    @Override
    public void onBindViewHolder(ChatVH holder, int i) {
        MessageModel item = list.get(i);
        if (!item.isSender()) {
            holder.receiver.setVisibility(View.GONE);
            holder.sender.setText(item.getMsg());
        } else {
            holder.sender.setVisibility(View.GONE);
            holder.receiver.setText(item.getMsg());
        }

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

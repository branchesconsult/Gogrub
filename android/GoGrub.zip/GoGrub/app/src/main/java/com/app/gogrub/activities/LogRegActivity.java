package com.app.gogrub.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.register.RegisterResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.iid.FirebaseInstanceId;
import com.hbb20.CountryCodePicker;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

/**
 * Created by farazqureshi on 31/07/2018.
 */

public class LogRegActivity extends AppCompatActivity implements ResponseHandler {

    CountryCodePicker ccp;
    EditText etName, etEmail, etPhone, etPassword, etCPassword;
    Button btn_create;
    LinearLayout sign_in, ll_fb;

    SessionManager sessionManager;
    private String fcm_token, device_id;
    private FirebaseAnalytics mFirebaseAnalytics;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        sessionManager = new SessionManager(this);

        // Obtain the FirebaseAnalytics instance.
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mFirebaseAnalytics.getAppInstanceId();

        fcm_token = FirebaseInstanceId.getInstance().getToken();
        Log.d("MYTAG", "This is your Firebase token : " + fcm_token);
        SessionManager.put(Constants.DEVICE_TOKEN, fcm_token);

        device_id = Settings.Secure.getString(this.getContentResolver(),
                Settings.Secure.ANDROID_ID);

        ccp = findViewById(R.id.ccp);
        ccp.setEnabled(false);

        etName = findViewById(R.id.name);
        etEmail = findViewById(R.id.email);
        etPhone = findViewById(R.id.phone);
        ll_fb = findViewById(R.id.social_tv);
        etPassword = findViewById(R.id.password);
        etCPassword = findViewById(R.id.cpassword);
        btn_create = findViewById(R.id.btn_create);
        sign_in = findViewById(R.id.sign_in);

        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btn_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.hideKeyboard(LogRegActivity.this);
                if (!etPhone.getText().toString().isEmpty() && !etName.getText().toString().isEmpty() && !etEmail.getText().toString().isEmpty() && !etPassword.getText().toString().isEmpty() && !etCPassword.getText().toString().isEmpty()) {
                    if (etName.getText().toString().contains(" ")) {
                        if (etPhone.getText().toString().length() == 10) {
                            if (etEmail.getText().toString().contains("@") && etEmail.getText().toString().contains(".")) {
                                if (etPassword.getText().toString().length() >= 6) {
                                    if (etCPassword.getText().toString().equalsIgnoreCase(etPassword.getText().toString())) {
                                        Loading.show(LogRegActivity.this, false, "Please wait...");
                                        sessionManager.put(Constants.PASSWORD, etPassword.getText().toString());
                                        new RestCaller(LogRegActivity.this, GoGrub.getRestClient().signup(etName.getText().toString(),
                                                etEmail.getText().toString(),
                                                etPhone.getText().toString(),
                                                etPassword.getText().toString(),
                                                etCPassword.getText().toString(),
                                                Constants.DEVICE_TYPE,
                                                sessionManager.get(Constants.DEVICE_TOKEN),
                                                device_id), 1);
                                    } else {
                                        etCPassword.setError("Password not matched");
                                        etCPassword.requestFocus();
                                        etCPassword.performClick();
                                    }
                                } else {
                                    etPassword.setError("Minimum 6 characters required");
                                    etPassword.requestFocus();
                                    etPassword.performClick();
                                }
                            } else {
                                etEmail.setError("Enter a valid email");
                                etEmail.requestFocus();
                                etEmail.performClick();
                            }
                        } else {
                            etPhone.setError("Enter a valid phone");
                            etPhone.requestFocus();
                            etPhone.performClick();
                        }
                    } else {
                        etName.setError("Enter your full name please");
                        etName.requestFocus();
                        etName.performClick();
                    }
                } else {
                    Toast.makeText(LogRegActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }

            }
        });

        ll_fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LogRegActivity.this, "Done", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        RegisterResponse registerResponse = (RegisterResponse) response.body();
        if (registerResponse.getSuccess()) {
            sessionManager.put(Constants.ACCESS_TOKEN, "Bearer " + registerResponse.getToken());
            sessionManager.put(Constants.USER_ID, registerResponse.getUser().getId()+"");
            sessionManager.put(Constants.PHONE, registerResponse.getUser().getMobile());
            sessionManager.put(Constants.NAME, registerResponse.getUser().getFullName());
            sessionManager.put(Constants.EMAIL, registerResponse.getUser().getEmail());
            sessionManager.put(Constants.IMG, registerResponse.getUser().getAvatar());
            sessionManager.put(Constants.isApplied, registerResponse.getUser().isApplied_as_chef());
            startActivity(new Intent(LogRegActivity.this, CodeVerificationActivity.class));
            this.finish();
        }
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();
        if (error.getError().getMessage() != null) {
            Toast.makeText(this, error.getError().getMessage(), Toast.LENGTH_SHORT).show();
        } else if (error.getError().getMobile() != null || error.getError().getEmail() != null) {
            if (error.getError().getMobile() != null && error.getError().getEmail() != null) {
                Toast.makeText(this, error.getError().getMobile(), Toast.LENGTH_SHORT).show();
                Toast.makeText(this, error.getError().getEmail(), Toast.LENGTH_SHORT).show();
            } else if (error.getError().getMobile() != null) {
                Toast.makeText(this, error.getError().getMobile(), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, error.getError().getEmail(), Toast.LENGTH_SHORT).show();

            }
        }

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }
}

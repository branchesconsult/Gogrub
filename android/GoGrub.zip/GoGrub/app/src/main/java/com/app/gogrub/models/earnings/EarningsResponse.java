package com.app.gogrub.models.earnings;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EarningsResponse {

    @SerializedName("total_earnings")
    @Expose
    private Integer totalEarnings;
    @SerializedName("current_month_earnings")
    @Expose
    private String currentMonthEarnings;
    @SerializedName("active_orders")
    @Expose
    private Integer activeOrders;
    @SerializedName("cancelled_orders")
    @Expose
    private Integer cancelledOrders;
    @SerializedName("completed_orders")
    @Expose
    private Integer completedOrders;
    @SerializedName("avg_rating")
    @Expose
    private Double avgRating;

    public Integer getTotalEarnings() {
        return totalEarnings;
    }

    public void setTotalEarnings(Integer totalEarnings) {
        this.totalEarnings = totalEarnings;
    }

    public String getCurrentMonthEarnings() {
        return currentMonthEarnings;
    }

    public void setCurrentMonthEarnings(String currentMonthEarnings) {
        this.currentMonthEarnings = currentMonthEarnings;
    }

    public Integer getActiveOrders() {
        return activeOrders;
    }

    public void setActiveOrders(Integer activeOrders) {
        this.activeOrders = activeOrders;
    }

    public Integer getCancelledOrders() {
        return cancelledOrders;
    }

    public void setCancelledOrders(Integer cancelledOrders) {
        this.cancelledOrders = cancelledOrders;
    }

    public Integer getCompletedOrders() {
        return completedOrders;
    }

    public void setCompletedOrders(Integer completedOrders) {
        this.completedOrders = completedOrders;
    }

    public Double getAvgRating() {
        return avgRating;
    }

    public void setAvgRating(Double avgRating) {
        this.avgRating = avgRating;
    }
}

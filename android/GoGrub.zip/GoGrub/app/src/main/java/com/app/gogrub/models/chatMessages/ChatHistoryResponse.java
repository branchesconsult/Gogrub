
package com.app.gogrub.models.chatMessages;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ChatHistoryResponse {

    @SerializedName("chats_summery")
    @Expose
    private List<ChatsSummery> chatsSummery = null;

    public List<ChatsSummery> getChatsSummery() {
        return chatsSummery;
    }

    public void setChatsSummery(List<ChatsSummery> chatsSummery) {
        this.chatsSummery = chatsSummery;
    }

}

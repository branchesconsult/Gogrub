package com.app.gogrub.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.OrderDetailAdapter;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.orderDetails.Detail;
import com.app.gogrub.models.orderDetails.OrderDetailResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class OrderDetail extends AppCompatActivity implements ResponseHandler {

    ArrayList<Detail> list = new ArrayList<>();
    RecyclerView recyclerView;
    OrderDetailAdapter adapter;
    ImageView iv_cart, iv_back;
    //    Button btn_cancel;
    TextView orderId, phone, address, tv_status, tv_subtotal, tv_del_charges, tv_total;
    SessionManager sessionManager;

    CardView chat_con;
    TextView chef_name;
    CircleImageView chef_img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);

        sessionManager = new SessionManager(this);

        recyclerView = findViewById(R.id.recyclerView);

        iv_cart = findViewById(R.id.iv_cart);
        iv_back = findViewById(R.id.iv_back);
//        btn_cancel = findViewById(R.id.btn_cancel);
        orderId = findViewById(R.id.title);
        phone = findViewById(R.id.phone);
        tv_del_charges = findViewById(R.id.tv_del_charges);
        tv_subtotal = findViewById(R.id.tv_subtotal);
        tv_total = findViewById(R.id.tv_total);
        address = findViewById(R.id.address);
        chat_con = findViewById(R.id.chat_con);
        tv_status = findViewById(R.id.tv_status);
        chef_name = findViewById(R.id.chef_name);
        chef_img = findViewById(R.id.chef_img);

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        adapter = new OrderDetailAdapter(this, list);
        recyclerView.setAdapter(adapter);

        iv_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(OrderDetail.this, CartActivity.class));
            }
        });

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

//        btn_cancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                FragmentManager fragmentManager = getSupportFragmentManager();
//                CancelDialog dialog = new CancelDialog();
//                dialog.show(fragmentManager, "");
//            }
//        });

        getOrderDetail();

    }

    private void getOrderDetail() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(OrderDetail.this, GoGrub.getRestClient().getOrderDetails(sessionManager.get(Constants.ACCESS_TOKEN), Integer.parseInt(getIntent().getStringExtra("o_id"))), 1);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();

        final OrderDetailResponse orderDetailResponse = (OrderDetailResponse) response.body();

        list.addAll(orderDetailResponse.getOrder().getDetail());
        adapter.notifyDataSetChanged();
        orderId.setText("ID: " + orderDetailResponse.getOrder().getId());
        phone.setText(orderDetailResponse.getOrder().getCustomerPhone());
        address.setText(orderDetailResponse.getOrder().getCustomerAddress());
        if (orderDetailResponse.getOrder().getStatus().getId() == 1) {
            tv_status.setText(orderDetailResponse.getOrder().getStatus().getStatus());
        } else if (orderDetailResponse.getOrder().getStatus().getId() == 2) {
            tv_status.setBackground(getResources().getDrawable(R.drawable.btn_field_red));
            tv_status.setText(orderDetailResponse.getOrder().getStatus().getStatus());
        } else if (orderDetailResponse.getOrder().getStatus().getId() == 3) {
            tv_status.setText(orderDetailResponse.getOrder().getStatus().getStatus());
            tv_status.setBackground(getResources().getDrawable(R.drawable.btn_field));
        } else {
            tv_status.setText(orderDetailResponse.getOrder().getStatus().getStatus());
            tv_status.setBackground(getResources().getDrawable(R.drawable.btn_field_red));
        }
        tv_subtotal.setText("Rs " + orderDetailResponse.getOrder().getSubtotal());
        tv_del_charges.setText("Rs " + orderDetailResponse.getOrder().getDeliveryCharges());
        tv_total.setText("Rs " + orderDetailResponse.getOrder().getTotal());

        chef_name.setText(orderDetailResponse.getOrder().getChef().getFullName());

        Picasso.with(OrderDetail.this).load(orderDetailResponse.getOrder().getChef().getAvatar()).fit().centerCrop().placeholder(R.drawable.img_placeholder).into(chef_img);

        chat_con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(OrderDetail.this, ChatActivity.class);
                i.putExtra("o_id", orderDetailResponse.getOrder().getId() + "");
                i.putExtra("r_id", orderDetailResponse.getOrder().getChef().getId() + "");
                i.putExtra("name", orderDetailResponse.getOrder().getChef().getFullName() + "");
                startActivity(i);
            }
        });

        if (orderDetailResponse.getOrder().getStatus().getId() == 4) {
            chat_con.setVisibility(View.GONE);
        }


    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }
}

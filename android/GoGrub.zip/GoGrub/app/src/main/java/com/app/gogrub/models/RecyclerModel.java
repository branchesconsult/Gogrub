package com.app.gogrub.models;

/**
 * Created by farazqureshi on 31/07/2018.
 */

public class RecyclerModel {

    String title;
    boolean isSelected;

    public RecyclerModel(String title, boolean isSelected) {
        this.title = title;
        this.isSelected = isSelected;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}

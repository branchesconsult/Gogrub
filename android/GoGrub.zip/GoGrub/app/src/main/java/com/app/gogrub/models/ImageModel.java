package com.app.gogrub.models;

public class ImageModel {

    public int id;
    public String path;
    public boolean isUrl;

    public ImageModel(){

    }

    public ImageModel(String path, boolean isUrl) {
        this.path = path;
        this.isUrl = isUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }


    public boolean isUrl() {
        return isUrl;
    }

    public void setUrl(boolean url) {
        isUrl = url;
    }
}

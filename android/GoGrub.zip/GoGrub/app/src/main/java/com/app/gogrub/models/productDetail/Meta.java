package com.app.gogrub.models.productDetail;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Meta implements Serializable {
    @SerializedName("chef_intro")
    @Expose
    String chef_intro;

    public String getChef_intro() {
        return chef_intro;
    }

    public void setChef_intro(String chef_intro) {
        this.chef_intro = chef_intro;
    }
}

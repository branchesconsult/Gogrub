package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.gogrub.R;

/**
 * Created by devicebee on 01/08/2018.
 */

public class CartItemVH extends RecyclerView.ViewHolder {

    ImageView iv_plus, iv_minus;
    TextView tv_name, tv_quantity, tv_price;
    LinearLayout ll_del;

    public RelativeLayout viewForeground, view_background;

    public CartItemVH(View itemView) {
        super(itemView);
        tv_name = itemView.findViewById(R.id.tv_name);
        tv_quantity = itemView.findViewById(R.id.tv_quantity);
        tv_price = itemView.findViewById(R.id.tv_price);
        iv_plus = itemView.findViewById(R.id.iv_plus);
        iv_minus = itemView.findViewById(R.id.iv_minus);
        ll_del = itemView.findViewById(R.id.ll_del);
        view_background = itemView.findViewById(R.id.view_background);
        viewForeground = itemView.findViewById(R.id.view_foreground);

    }
}

package com.app.gogrub.models;

/**
 * Created by devicebee on 01/08/2018.
 */

public class FoodModel {

    public String title;
    public int img;

    public FoodModel(String title, int img) {
        this.title = title;
        this.img = img;
    }
}

package com.app.gogrub.models.register;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by farazqureshi on 23/09/2018.
 */

public class Pivot_ {

    @SerializedName("role_id")
    @Expose
    private Integer roleId;
    @SerializedName("permission_id")
    @Expose
    private Integer permissionId;

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(Integer permissionId) {
        this.permissionId = permissionId;
    }
}

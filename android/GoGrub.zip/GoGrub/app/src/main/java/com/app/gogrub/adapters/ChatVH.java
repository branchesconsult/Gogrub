package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.app.gogrub.R;

/**
 * Created by farazqureshi on 02/08/2018.
 */

public class ChatVH extends RecyclerView.ViewHolder {

    TextView sender, receiver;

    public ChatVH(View itemView) {
        super(itemView);

        sender = itemView.findViewById(R.id.sender);
        receiver = itemView.findViewById(R.id.receiver);

    }
}

package com.app.gogrub.activities;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.gogrub.R;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.SessionManager;
import com.mukesh.permissions.AppPermissions;

import java.util.ArrayList;
import java.util.List;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

/**
 * Created by devicebee on 01/08/2018.
 */

public class OrderPlacedActivity extends AppCompatActivity {

    TextView tv_time, tv_orderid;
    public Button btn_continue;
    ImageView iv_call, iv_chat;

    private static final String[] ALL_PERMISSIONS = {
            Manifest.permission.CALL_PHONE
    };
    private static final int ALL_REQUEST_CODE = 0;
    private AppPermissions mRuntimePermission;
    boolean havePermissions = false;

    SessionManager sessionManager;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_place);

        btn_continue = findViewById(R.id.btn_continue);
        tv_time = findViewById(R.id.tv_time);
        tv_orderid = findViewById(R.id.tv_orderid);
        iv_call = findViewById(R.id.iv_call);
        iv_chat = findViewById(R.id.iv_chat);

        sessionManager = new SessionManager(this);

        setPermission();

        tv_orderid.setText(Constants.ORDERID);
        tv_time.setText(Constants.ORDERTIME + " mins");

        sessionManager.put(Constants.ORDERTIME, Constants.ORDERTIME);

        iv_chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(OrderPlacedActivity.this, ChatActivity.class);
                i.putExtra("o_id", Constants.ORDERID);
                i.putExtra("r_id", Constants.CHEF_ID + "");
                i.putExtra("name", Constants.CHEFNAME);
                startActivity(i);

            }
        });

        iv_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:+92" + Constants.CHEF_PHONE));
                if (android.support.v4.app.ActivityCompat.checkSelfPermission(OrderPlacedActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                startActivity(callIntent);
            }
        });

        btn_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(OrderPlacedActivity.this, DashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i.putExtra("order", "order");
                startActivity(i);
            }
        });

    }

    public void setPermission() {
        mRuntimePermission = new AppPermissions(this);
        if (mRuntimePermission.hasPermission(ALL_PERMISSIONS)) {

        } else {
            mRuntimePermission.requestPermission(ALL_PERMISSIONS, ALL_REQUEST_CODE);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case ALL_REQUEST_CODE:
                List<Integer> permissionResults = new ArrayList<>();
                for (int grantResult : grantResults) {
                    permissionResults.add(grantResult);
                }
                if (permissionResults.contains(PackageManager.PERMISSION_DENIED)) {
                    //Toast.makeText(this, "All Permissions not granted", Toast.LENGTH_SHORT).show();
                } else {
                    havePermissions = true;
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(OrderPlacedActivity.this, DashboardActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        i.putExtra("order", "order");
        startActivity(i);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}

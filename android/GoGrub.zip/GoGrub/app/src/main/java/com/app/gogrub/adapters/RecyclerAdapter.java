package com.app.gogrub.adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.models.RecyclerModel;
import com.app.gogrub.utils.Constants;

import java.util.ArrayList;

/**
 * Created by farazqureshi on 31/07/2018.
 */

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerVH> {

    Activity activity;
    ArrayList<RecyclerModel> list;
    boolean isSingle;

    public RecyclerAdapter(Activity activity, ArrayList<RecyclerModel> list, boolean isSingle) {
        this.activity = activity;
        this.list = list;
        this.isSingle = isSingle;
    }

    @Override
    public RecyclerVH onCreateViewHolder(ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_list, parent, false);
        return new RecyclerVH(v);
    }

    @Override
    public void onBindViewHolder(RecyclerVH holder, final int i) {
        final RecyclerModel item = list.get(i);

        holder.tv_txt.setText(item.getTitle());

        if (item.isSelected()) {
            holder.iv_check.setImageResource(R.drawable.ic_check_circle);
        } else {
            holder.iv_check.setImageResource(R.drawable.ic_circle);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isSingle) {
                    for (int j = 0; j < list.size(); j++) {
                        list.get(j).setSelected(false);
                    }
                    if (item.isSelected()) {
                        item.setSelected(false);
                        Constants.sortBy = "";
                        notifyDataSetChanged();
                    } else {
                        item.setSelected(true);
                        Constants.sortBy = item.getTitle();
                        notifyDataSetChanged();
                    }
                } else {
                    if (item.isSelected()) {
                        for (int j = 0; j < Constants.cuisines.size(); j++) {
                            if (Constants.cuisines.get(j).equalsIgnoreCase(i + "")) {
                                Constants.cuisines.remove(j);
                                break;
                            }
                        }
                        item.setSelected(false);
                        notifyDataSetChanged();
                    } else {
                        item.setSelected(true);
                        Constants.cuisines.add(i + "");
                        notifyDataSetChanged();
                    }
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

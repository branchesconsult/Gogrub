package com.app.gogrub.activities;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import com.app.gogrub.R;
import com.app.gogrub.utils.SessionManager;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.mukesh.permissions.AppPermissions;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class Splash_One extends AppCompatActivity {


    private static final ScheduledExecutorService worker =
            Executors.newSingleThreadScheduledExecutor();

    private Handler handler;
    private ImageView logo;

    private static final String[] ALL_PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WAKE_LOCK,
    };
    private static final int ALL_REQUEST_CODE = 0;
    private AppPermissions mRuntimePermission;
    boolean havePermissions = false;
    SessionManager sessionManager;
    private FirebaseAnalytics mFirebaseAnalytics;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        sessionManager = new SessionManager(this);
        logo = findViewById(R.id.logo);

        setPermission();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case ALL_REQUEST_CODE:
                List<Integer> permissionResults = new ArrayList<>();
                for (int grantResult : grantResults) {
                    permissionResults.add(grantResult);
                }
                if (permissionResults.contains(PackageManager.PERMISSION_DENIED)) {
                    //Toast.makeText(this, "All Permissions not granted", Toast.LENGTH_SHORT).show();
                    goApp();
                } else {
                    havePermissions = true;
                    goApp();
                }
                break;
        }
    }

    private void goApp() {
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                logo.setVisibility(View.VISIBLE);
//                tv_title.setVisibility(View.VISIBLE);
//                AnimationUtility.(logo);
                YoYo.with(Techniques.Pulse)
                        .duration(4000)
                        .playOn(logo);

            }
        }, 40);
//        setPermission();

        Runnable task = new Runnable() {
            public void run() {
                if (sessionManager.checkLogin()) {
                    startActivity(new Intent(Splash_One.this, DashboardActivity.class));
                    finish();
                } else {
                    startActivity(new Intent(Splash_One.this, Splash.class));
                    finish();
                }
            }
        };
        worker.schedule(task, 2000, TimeUnit.MILLISECONDS);

    }

    public void setPermission() {
        mRuntimePermission = new AppPermissions(this);
        if (mRuntimePermission.hasPermission(ALL_PERMISSIONS)) {
            goApp();
        } else {
            mRuntimePermission.requestPermission(ALL_PERMISSIONS, ALL_REQUEST_CODE);
        }
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

}

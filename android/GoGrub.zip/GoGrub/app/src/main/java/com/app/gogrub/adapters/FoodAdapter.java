package com.app.gogrub.adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.activities.AddProductActivity;
import com.app.gogrub.activities.DashboardActivity;
import com.app.gogrub.activities.FoodDetail;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.products.Product;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.CustomDialoge;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by farazqureshi on 29/07/2018.
 */

public class FoodAdapter extends RecyclerView.Adapter<FoodVH> implements ResponseHandler {

    Activity activity;
    ArrayList<Product> list;
    private Product product;

    public FoodAdapter(Activity activity, ArrayList<Product> list) {
        this.activity = activity;
        this.list = list;
    }

    @Override
    public FoodVH onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_foood, viewGroup, false);
        return new FoodVH(v);
    }

    @Override
    public void onBindViewHolder(FoodVH holder, final int position) {
        final Product item = list.get(position);
//        holder.iv_img.setImageResource(list.get(i).img);
        if (list.get(position).getImages().size() > 0) {
            Log.d("URL", list.get(position).getImages().get(0).getImageLarge());
            Picasso.with(activity).load(list.get(position).getImages().get(0).getImageLarge()).placeholder(R.drawable.img_placeholder).fit().centerCrop().into(holder.iv_img);
        } else {
            Picasso.with(activity).load(R.drawable.img_placeholder).placeholder(R.drawable.img_placeholder).fit().centerCrop().into(holder.iv_img);
        }
        holder.tv_chef.setText(" " + list.get(position).getChef().getFullName().substring(0, 1).toUpperCase() + list.get(position).getChef().getFullName().substring(1));
        holder.tv_food.setText(list.get(position).getName().substring(0, 1).toUpperCase() + list.get(position).getName().substring(1));
        holder.tv_serving.setText(" " + list.get(position).getServingSize());
        holder.tv_serving_left.setText(" " + list.get(position).getRemaining_servings());
        holder.tv_price.setText("Rs " + list.get(position).getPrice());

        if (activity instanceof DashboardActivity) {
            if (((DashboardActivity) activity).isChef) {
                holder.ll_del.setVisibility(View.VISIBLE);
            } else {
                holder.ll_del.setVisibility(View.GONE);
            }
        }

        holder.ll_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
                alertDialogBuilder.setTitle("Attention");
                alertDialogBuilder.setMessage("Are you sure you want to Delete this Product?");
                alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();

                        deleteProduct(item);

                        notifyDataSetChanged();
//                    Toast.makeText(NewPlacesActivity.this, "Removed", Toast.LENGTH_SHORT).show();

                    }
                });
                alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();

                    }
                });
                alertDialogBuilder.create();
                alertDialogBuilder.show();
            }
        });

        if (list.get(position).getRemaining_servings() == 0) {
            holder.tv_status.setText(" Sold Out!");
            holder.tv_status.setTextColor(activity.getResources().getColor(R.color.red));
        } else {
            holder.tv_status.setText(" Available");
            holder.tv_status.setTextColor(activity.getResources().getColor(R.color.green_txt));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (activity instanceof DashboardActivity) {
                    if (((DashboardActivity) activity).isChef) {
                        Constants.PRODUCT = list.get(position);
                        Intent intent = new Intent(activity, AddProductActivity.class);
                        intent.putExtra("edit", "edit");
                        activity.startActivity(intent);

                    } else {
                        Intent intent = new Intent(activity, FoodDetail.class);
                        Constants.productId = list.get(position).getId();
                        activity.startActivity(intent);
                    }
                } else {
                    Intent intent = new Intent(activity, FoodDetail.class);
                    Constants.productId = list.get(position).getId();
                    activity.startActivity(intent);
                }
            }
        });

        holder.tv_food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (activity instanceof DashboardActivity) {
                    if (((DashboardActivity) activity).isChef) {
                        Constants.PRODUCT = list.get(position);
                        Intent intent = new Intent(activity, AddProductActivity.class);
                        intent.putExtra("edit", "edit");
                        activity.startActivity(intent);

                    } else {
                        Intent intent = new Intent(activity, FoodDetail.class);
                        Constants.productId = list.get(position).getId();
                        activity.startActivity(intent);
                    }
                } else {
                    Intent intent = new Intent(activity, FoodDetail.class);
                    Constants.productId = list.get(position).getId();
                    activity.startActivity(intent);
                }
            }
        });

        double d = list.get(position).getChef().getAvgRating();
        holder.ratingBar.setRating((float) d);
    }

    private void deleteProduct(Product item) {
        product = item;
        if (Internet.isAvailable(activity)) {
            Loading.show(activity, false, "Please wait...");
            new RestCaller(FoodAdapter.this, GoGrub.getRestClient().deleteProduct(new SessionManager(activity).get(Constants.ACCESS_TOKEN), item.getId()), 1);
        } else {
            Toast.makeText(activity, "No Internet connection available", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        GenericResponse genericResponse = (GenericResponse) response.body();
        if (genericResponse.isSuccess()) {
            CustomDialoge.show(activity, genericResponse.getMessage_title(), genericResponse.getMsg());
            list.remove(product);
            notifyDataSetChanged();
        }
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }

}

package com.app.gogrub.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class SettingsActivity extends AppCompatActivity implements ResponseHandler {

    ImageView iv_back;
    TextView terms, privacy, about;
    LinearLayout logout;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        sessionManager = new SessionManager(this);

        iv_back = findViewById(R.id.iv_back);
        logout = findViewById(R.id.logout);
        terms = findViewById(R.id.terms);
        privacy = findViewById(R.id.privacy);
        about = findViewById(R.id.about);


        terms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.TITLE = "Terms & Conditions";
                startActivity(new Intent(SettingsActivity.this, PageActivity.class));
            }
        });

        privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.TITLE = "Privacy Policy";
                startActivity(new Intent(SettingsActivity.this, PageActivity.class));

            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.TITLE = "About";
                startActivity(new Intent(SettingsActivity.this, PageActivity.class));

            }
        });


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logoutApp();
            }
        });

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void logoutApp() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait..");
            new RestCaller(SettingsActivity.this, GoGrub.getRestClient().logout(sessionManager.get(Constants.ACCESS_TOKEN), Settings.Secure.getString(this.getContentResolver(),
                    Settings.Secure.ANDROID_ID)), 3);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }

    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        GenericResponse genericResponse = (GenericResponse) response.body();
        sessionManager.clearSession();
        Intent i = new Intent(SettingsActivity.this, Splash.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();
    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }
}

package com.app.gogrub.adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.app.gogrub.R;
import com.app.gogrub.activities.ChefRegisterationActivity;
import com.app.gogrub.activities.KitchenRegActivity;
import com.app.gogrub.utils.Constants;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;

public class ChefImageAdapter extends RecyclerView.Adapter<ImageVH> {

    Activity activity;
    ArrayList<String> list;
    Button btn_save;

    public ChefImageAdapter(Activity activity, ArrayList<String> list) {
        this.activity = activity;
        this.list = list;
    }

    public ChefImageAdapter(Activity activity, ArrayList<String> list, Button btn_save) {
        this.activity = activity;
        this.list = list;
        this.btn_save = btn_save;
    }

    @Override
    public ImageVH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chef_img_layout, parent, false);
        return new ImageVH(v);
    }

    @Override
    public void onBindViewHolder(ImageVH holder, final int position) {

        if (list.get(position).length() > 0) {
            holder.iv_del.setVisibility(View.VISIBLE);
            Picasso.with(activity).load(new File(list.get(position))).fit().centerCrop().placeholder(R.drawable.img_placeholder).into(holder.iv_img);
        } else {
            holder.iv_del.setVisibility(View.INVISIBLE);
            holder.iv_img.setImageResource(R.drawable.add_img);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (list.get(position).length() == 0) {
                    if (Constants.checkPermission(activity))
                        if (activity instanceof ChefRegisterationActivity)
                            ((ChefRegisterationActivity) activity).selectImage();
                        else
                            ((KitchenRegActivity) activity).selectImage();

                }
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (activity instanceof ChefRegisterationActivity) {
                    ((ChefRegisterationActivity) activity).filesRemove(position);
                } else {
                    ((KitchenRegActivity) activity).filesRemove(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

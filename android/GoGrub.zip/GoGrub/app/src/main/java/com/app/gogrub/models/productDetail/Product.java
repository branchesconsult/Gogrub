
package com.app.gogrub.models.productDetail;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Product implements Serializable {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("chef_id")
    @Expose
    private Integer chefId;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("cuisine_id")
    @Expose
    private Integer cuisineId;
    @SerializedName("serving_size")
    @Expose
    private Integer servingSize;
    @SerializedName("total_servings")
    @Expose
    private Integer totalServings;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("price")
    @Expose
    private Integer price;
    @SerializedName("discounted_price")
    @Expose
    private Integer discountedPrice;
    @SerializedName("availability_from")
    @Expose
    private String availabilityFrom;
    @SerializedName("availability_to")
    @Expose
    private Object availabilityTo;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("updated_at")
    @Expose
    private String updatedAt;
    @SerializedName("deleted_at")
    @Expose
    private Object deletedAt;
    @SerializedName("images")
    @Expose
    private List<Image> images = null;
    @SerializedName("cuisine")
    @Expose
    private Cuisine cuisine;
    @SerializedName("chef")
    @Expose
    private Chef chef;
    @SerializedName("remaining_servings")
    @Expose
    private int remaining_servings;
    @SerializedName("posted_at")
    @Expose
    private String posted_at;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChefId() {
        return chefId;
    }

    public void setChefId(Integer chefId) {
        this.chefId = chefId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCuisineId() {
        return cuisineId;
    }

    public void setCuisineId(Integer cuisineId) {
        this.cuisineId = cuisineId;
    }

    public Integer getServingSize() {
        return servingSize;
    }

    public void setServingSize(Integer servingSize) {
        this.servingSize = servingSize;
    }

    public Integer getTotalServings() {
        return totalServings;
    }

    public void setTotalServings(Integer totalServings) {
        this.totalServings = totalServings;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getDiscountedPrice() {
        return discountedPrice;
    }

    public void setDiscountedPrice(Integer discountedPrice) {
        this.discountedPrice = discountedPrice;
    }

    public String getAvailabilityFrom() {
        return availabilityFrom;
    }

    public void setAvailabilityFrom(String availabilityFrom) {
        this.availabilityFrom = availabilityFrom;
    }

    public Object getAvailabilityTo() {
        return availabilityTo;
    }

    public void setAvailabilityTo(Object availabilityTo) {
        this.availabilityTo = availabilityTo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Object getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Object deletedAt) {
        this.deletedAt = deletedAt;
    }

    public List<Image> getImages() {
        return images;
    }

    public void setImages(List<Image> images) {
        this.images = images;
    }

    public Cuisine getCuisine() {
        return cuisine;
    }

    public void setCuisine(Cuisine cuisine) {
        this.cuisine = cuisine;
    }

    public Chef getChef() {
        return chef;
    }

    public void setChef(Chef chef) {
        this.chef = chef;
    }

    public int getRemaining_servings() {
        return remaining_servings;
    }

    public void setRemaining_servings(int remaining_servings) {
        this.remaining_servings = remaining_servings;
    }

    public String getPosted_at() {
        return posted_at;
    }

    public void setPosted_at(String posted_at) {
        this.posted_at = posted_at;
    }
}

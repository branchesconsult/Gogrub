package com.app.gogrub.activities;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.FoodAdapter;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.products.Product;
import com.app.gogrub.models.products.ProductResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.SessionManager;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class OtherMealsByChef extends AppCompatActivity implements ResponseHandler, SwipeRefreshLayout.OnRefreshListener {

    private CardView container;
    private ImageView ivBack;
    private TextView title;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private RecyclerView recyclerView;
    private SessionManager sessionManager;
    private FoodAdapter foodAdapter;

    ArrayList<Product> list = new ArrayList<>();

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-18 18:46:59 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    private void findViews() {
        container = (CardView) findViewById(R.id.container);
        ivBack = (ImageView) findViewById(R.id.iv_back);
        title = (TextView) findViewById(R.id.title);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_container);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.other_meals_chef);

        findViews();


        sessionManager = new SessionManager(OtherMealsByChef.this);

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary,
                android.R.color.holo_green_dark,
                android.R.color.holo_orange_dark,
                android.R.color.holo_blue_dark);

        mSwipeRefreshLayout.post(new Runnable() {

            @Override
            public void run() {

                mSwipeRefreshLayout.setRefreshing(true);

                // Fetching data from server
                loadRecyclerViewData();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        foodAdapter = new FoodAdapter(this, list);
        recyclerView.setAdapter(foodAdapter);

        title.setText(Constants.CHEFNAME);


    }


    @Override
    public void onRefresh() {
        loadRecyclerViewData();
    }

    private void loadRecyclerViewData() {
        mSwipeRefreshLayout.setRefreshing(true);
        getChefProducts();
    }

    private void getChefProducts() {
//        Loading.show(this, false, "Please wait...");
        mSwipeRefreshLayout.setRefreshing(true);
        new RestCaller(OtherMealsByChef.this, GoGrub.getRestClient().getOtherMealsByChef(sessionManager.get(Constants.ACCESS_TOKEN), Constants.CHEF_ID + ""), 1);
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {

        if (reqCode == 1) {
            mSwipeRefreshLayout.setRefreshing(false);
            ProductResponse productResponse = (ProductResponse) response.body();
            list.clear();
            if (productResponse.getProducts() != null) {
                if (productResponse.getProducts().size() > 0) {
                    list.addAll(productResponse.getProducts());
                    foodAdapter.notifyDataSetChanged();
                }
            }
        }

    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {

    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}

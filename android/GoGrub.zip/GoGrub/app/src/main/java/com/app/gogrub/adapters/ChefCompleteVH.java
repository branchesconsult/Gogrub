package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;

import com.app.gogrub.R;

public class ChefCompleteVH extends RecyclerView.ViewHolder {
    public TextView tvOrderid;
    public TextView tvOrdertime;
    public TextView tvOrderList;
    public TextView tvPricetitle;
    public RatingBar ratingbar;
    public TextView tvTotalPrice;

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-16 17:47:31 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    public void findViews(View itemView) {
        tvOrderid = (TextView)itemView.findViewById( R.id.tv_orderid );
        tvOrdertime = (TextView)itemView.findViewById( R.id.tv_ordertime );
        tvOrderList = (TextView)itemView.findViewById( R.id.tv_order_list );
        tvPricetitle = (TextView)itemView.findViewById( R.id.tv_pricetitle );
        ratingbar = (RatingBar)itemView.findViewById( R.id.ratingbar );
        tvTotalPrice = (TextView)itemView.findViewById( R.id.tv_total_price );
    }


    public ChefCompleteVH(View itemView) {
        super(itemView);
        findViews(itemView);
    }
}

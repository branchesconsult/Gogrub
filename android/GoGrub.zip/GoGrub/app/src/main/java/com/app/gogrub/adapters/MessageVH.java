package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.app.gogrub.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class MessageVH extends RecyclerView.ViewHolder {

    CircleImageView ivDp;
    TextView tv_name, tv_msg, tv_time;

    public MessageVH(View itemView) {
        super(itemView);
        ivDp = itemView.findViewById(R.id.ivDp);
        tv_name = itemView.findViewById(R.id.tv_name);
        tv_msg = itemView.findViewById(R.id.tv_msg);
        tv_time = itemView.findViewById(R.id.tv_time);

    }
}

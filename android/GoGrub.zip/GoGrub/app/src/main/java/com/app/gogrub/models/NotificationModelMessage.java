package com.app.gogrub.models;

import com.app.gogrub.models.chat.Chat;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NotificationModelMessage {

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("object")
    @Expose
    private Chat data;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Chat getData() {
        return data;
    }

    public void setData(Chat data) {
        this.data = data;
    }
}

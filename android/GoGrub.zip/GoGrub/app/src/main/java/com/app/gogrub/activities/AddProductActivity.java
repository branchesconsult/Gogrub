package com.app.gogrub.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.ImageAdapter;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.ImageModel;
import com.app.gogrub.models.addProduct.AddProductResponse;
import com.app.gogrub.models.cuisines.Cuisine;
import com.app.gogrub.models.cuisines.CuisinesResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.ImageUtils;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.PermissionManager;
import com.app.gogrub.utils.SessionManager;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;
import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class AddProductActivity extends AppCompatActivity implements ResponseHandler, AdapterView.OnItemSelectedListener,
        TimePickerDialog.OnTimeSetListener,
        com.wdullaer.materialdatetimepicker.date.DatePickerDialog.OnDateSetListener {

    RecyclerView imgRecycler;
    EditText etName, etSeriverSize, etTotalServings, etPrice, etPreparationTime, etDescription;
    Button btnCancel, btnPublish;
    TextView tvTime, tv_timeTo;
    Spinner spn_cuisineType;

    private static final int SELECT_FILE = 0;
    private static final int REQUEST_CAMERA = 1;
    private PermissionManager permissionsManager;
    ArrayList<String> files; //These are the uris for the files to be uploaded
    MediaType mediaType = MediaType.parse("");

    ArrayList<ImageModel> list = new ArrayList<>();
    private String img_path;
    private String userChoosenTask;
    private ImageAdapter adapter;
    SessionManager sessionManager;


    ArrayList<String> cuisines = new ArrayList<>();
    ArrayList<Cuisine> cuisinesList = new ArrayList<>();
    private int cuisineType = 0;
    private String available_date_time, available_date_time_to;
    private String date, date_;
    private int t = 0;
    private Uri photoURI;
    private String imageFilePath;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        sessionManager = new SessionManager(this);
        files = new ArrayList<>();

        etDescription = findViewById(R.id.et_desc);
        etName = findViewById(R.id.foodName);
        etSeriverSize = findViewById(R.id.etServingSize);
        etPrice = findViewById(R.id.etPrice);
        etPreparationTime = findViewById(R.id.etPreparationTime);
        imgRecycler = findViewById(R.id.img_recycler);
        btnPublish = findViewById(R.id.btnPublish);
        btnCancel = findViewById(R.id.btnCancel);
        tvTime = findViewById(R.id.tvtime);
        tv_timeTo = findViewById(R.id.tv_time);
        etTotalServings = findViewById(R.id.etTotalServings);
        spn_cuisineType = findViewById(R.id.cuisine_type);
        spn_cuisineType.setOnItemSelectedListener(this);

        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        etName.setText("");
        etSeriverSize.setText("");
        etDescription.setText("");
        etPrice.setText("");
        etTotalServings.setText("");

        getCuisines();

        permissionsManager = PermissionManager.getInstance(AddProductActivity.this);
        permissionsManager.getPermissionifNotAvailble(new String[]{Manifest.permission.ACCESS_NETWORK_STATE
                , Manifest.permission.INTERNET
                , Manifest.permission.READ_EXTERNAL_STORAGE
                , Manifest.permission.WRITE_EXTERNAL_STORAGE
                , Manifest.permission.CAMERA
        }, 111);

        list.add(new ImageModel("", false));

        adapter = new ImageAdapter(this, list);

        imgRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        imgRecycler.setAdapter(adapter);

        tvTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t = 1;
                Calendar now = Calendar.getInstance();

                DatePickerDialog dpd = DatePickerDialog.newInstance(
                        AddProductActivity.this,
                        now.get(Calendar.YEAR),
                        now.get(Calendar.MONTH),
                        now.get(Calendar.DATE)
                );
                dpd.setMinDate(new GregorianCalendar(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE)));
                dpd.setTitle(getResources().getString(R.string.date_msg));
                dpd.show(getFragmentManager(), "Datepickerdialog");

            }
        });

        tv_timeTo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t = 2;
                Calendar now = Calendar.getInstance();

                DatePickerDialog dpd = DatePickerDialog.newInstance(
                        AddProductActivity.this,
                        now.get(Calendar.YEAR),
                        now.get(Calendar.MONTH),
                        now.get(Calendar.DATE)
                );
                dpd.setMinDate(new GregorianCalendar(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DATE)));
                dpd.setTitle(getResources().getString(R.string.date_msg));
                dpd.show(getFragmentManager(), "Datepickerdialog");


            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnPublish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etName.getText().toString().length() > 0 &&
                        etDescription.getText().toString().length() > 0 &&
                        etPrice.getText().toString().length() > 0 &&
                        etSeriverSize.getText().toString().length() > 0 &&
                        available_date_time != null &&
                        available_date_time_to != null &&
                        etPreparationTime.getText().toString().length() > 0 &&
                        etTotalServings.getText().toString().length() > 0 && cuisineType != 0) {
                    if (getIntent().getStringExtra("edit") != null) {
                        if (list.size() > 0) {
                            final MultipartBody.Part[] fileParts = new MultipartBody.Part[list.size()];
                            for (int i = 0; i < list.size() - 1; i++) {
                                if (!list.get(i).isUrl()) {
                                    File file = new File(list.get(i).getPath());
                                    RequestBody fileBody = RequestBody.create(mediaType, file);
                                    //Setting the file name as an empty string here causes the same issue, which is sending the request successfully without saving the files in the backend, so don't neglect the file name parameter.
                                    fileParts[i] = MultipartBody.Part.createFormData(String.format(Locale.ENGLISH, "product_images[%d]", i), file.getName(), fileBody);
                                }
                            }

                            Loading.show(AddProductActivity.this, false, "Please wait...");
                            new RestCaller(AddProductActivity.this, GoGrub.getRestClient().editProduct(
                                    sessionManager.get(Constants.ACCESS_TOKEN),
                                    Constants.PRODUCT.getId() + "",
                                    etName.getText().toString(),
                                    cuisineType + "",
                                    etPrice.getText().toString(),
                                    available_date_time,
                                    etSeriverSize.getText().toString(),
                                    etTotalServings.getText().toString(),
                                    etDescription.getText().toString(),
                                    etPreparationTime.getText().toString(),
                                    available_date_time_to,
                                    fileParts), 3);
                        } else {
                            Loading.show(AddProductActivity.this, false, "Please wait...");
                            new RestCaller(AddProductActivity.this, GoGrub.getRestClient().editProduct(
                                    sessionManager.get(Constants.ACCESS_TOKEN),
                                    Constants.PRODUCT.getId() + "",
                                    etName.getText().toString(),
                                    cuisineType + "",
                                    etPrice.getText().toString(),
                                    available_date_time,
                                    etSeriverSize.getText().toString(),
                                    etTotalServings.getText().toString(),
                                    etDescription.getText().toString(),
                                    etPreparationTime.getText().toString(),
                                    available_date_time_to), 3);

                        }
                    } else {
                        if (list.size() > 0) {

                            final MultipartBody.Part[] fileParts = new MultipartBody.Part[list.size()];
                            for (int i = 0; i < list.size() - 1; i++) {
                                File file = new File(list.get(i).getPath());
                                RequestBody fileBody = RequestBody.create(mediaType, file);
                                //Setting the file name as an empty string here causes the same issue, which is sending the request successfully without saving the files in the backend, so don't neglect the file name parameter.
                                fileParts[i] = MultipartBody.Part.createFormData(String.format(Locale.ENGLISH, "product_images[%d]", i), file.getName(), fileBody);
                            }

                            Loading.show(AddProductActivity.this, false, "Please wait...");
                            new RestCaller(AddProductActivity.this, GoGrub.getRestClient().addProduct(
                                    sessionManager.get(Constants.ACCESS_TOKEN),
                                    etName.getText().toString(),
                                    cuisineType + "",
                                    etPrice.getText().toString(),
                                    available_date_time,
                                    etSeriverSize.getText().toString(),
                                    etTotalServings.getText().toString(),
                                    etDescription.getText().toString(),
                                    etPreparationTime.getText().toString(),
                                    available_date_time_to,
                                    fileParts), 2);

                        } else {
                            Toast.makeText(AddProductActivity.this, "At least add 1 image", Toast.LENGTH_SHORT).show();
                        }
                    }

                } else {
                    Toast.makeText(AddProductActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getCuisines() {
        Loading.show(this, false, "Please wait...");
        new RestCaller(AddProductActivity.this, GoGrub.getRestClient().getCuisine(), 1);
    }


    public void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Library",
                "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(AddProductActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask = "Choose from Library";
                    galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent() {
        EasyImage.openGallery(this, SELECT_FILE);
    }

    private void cameraIntent() {
        EasyImage.openCamera(this, REQUEST_CAMERA);
    }


    @Override
    public void onActivityResult(final int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        EasyImage.handleActivityResult(requestCode, resultCode, data, this, new DefaultCallback() {
            @Override
            public void onImagePicked(File imageFile, EasyImage.ImageSource source, int type) {
                if (type == SELECT_FILE) {
                    img_path = new File(ImageUtils.compressImage(imageFile.getPath())).getPath();
                    Log.d("PATH", "" + img_path);

                    if (img_path != null) {
                        list.add(0, new ImageModel(img_path, false));
                        if (list.size() == 7) {
                            list.remove(6);
                        }
                        files.add(img_path);
                        adapter.notifyDataSetChanged();
                        imgRecycler.smoothScrollToPosition(0);
                    }
                } else if (type == REQUEST_CAMERA) {
                    img_path = new File(ImageUtils.compressImage(imageFile.getPath())).getPath();
                    Log.d("PATH", "" + img_path);

                    if (img_path != null) {
                        list.add(0, new ImageModel(img_path, false));
                        if (list.size() == 7) {
                            list.remove(6);
                        }
                        files.add(img_path);
                        adapter.notifyDataSetChanged();
                        imgRecycler.smoothScrollToPosition(0);
                    }
                }
            }
        });
    }


    public void filesRemove(int i) {
        list.remove(i);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        if (reqCode == 1) {
            CuisinesResponse cuisinesResponse = (CuisinesResponse) response.body();
            if (cuisinesResponse.getCuisines().size() > 0) {
                cuisinesList.addAll(cuisinesResponse.getCuisines());
                cuisines.add("Select Cuisine");
                for (int i = 0; i < cuisinesList.size(); i++) {
                    Cuisine cuisine = (Cuisine) cuisinesList.get(i);
                    cuisines.add(cuisine.getName());
                }
                ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, cuisines);

                // Drop down layout style - list view with radio button
                dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                // attaching data adapter to spinner
                spn_cuisineType.setAdapter(dataAdapter);
            }

            if (getIntent().getStringExtra("edit") != null) {
                etName.setText(Constants.PRODUCT.getName());
                etTotalServings.setText(Constants.PRODUCT.getTotalServings() + "");
                etSeriverSize.setText(Constants.PRODUCT.getServingSize() + "");
                etPrice.setText(Constants.PRODUCT.getPrice() + "");
                etPreparationTime.setText(Constants.PRODUCT.getPreparation_time() + "");
//                spn_cuisineType.set
                available_date_time = Constants.PRODUCT.getAvailabilityForm();
                available_date_time_to = Constants.PRODUCT.getAvailabilityTo();
                tvTime.setText(available_date_time);
                tv_timeTo.setText(available_date_time_to);
                etDescription.setText(Constants.PRODUCT.getDescription());
                list.clear();
                for (int i = 0; i < Constants.PRODUCT.getImages().size(); i++) {
                    ImageModel imageModel = new ImageModel();
                    imageModel.setPath(Constants.PRODUCT.getImages().get(i).getImageLarge());
                    imageModel.setId(Constants.PRODUCT.getImages().get(i).getId());
                    imageModel.setUrl(true);
                    list.add(imageModel);
                }
                if (list.size() < 6) {
                    list.add(new ImageModel("", false));
                }
                adapter.notifyDataSetChanged();
                cuisineType = Constants.PRODUCT.getCuisineId();
                spn_cuisineType.setSelection(Constants.PRODUCT.getCuisineId() + 1);

                btnPublish.setText("Save Changes");
            }

        } else {
            AddProductResponse addProductResponse = (AddProductResponse) response.body();
            if (addProductResponse.getSuccess()) {
                if (getIntent().getStringExtra("edit") != null) {
                    Intent i = new Intent(AddProductActivity.this, DashboardActivity.class);
                    i.putExtra("edit", "edit");
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                } else {
                    Intent i = new Intent(AddProductActivity.this, DashboardActivity.class);
                    i.putExtra("added", "added");
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);

                }
            }

        }
    }

    private int getSelectedCuisine(Integer cuisineId) {
        int i = 0;
        for (int j = 0; j < cuisines.size(); j++) {

        }
        return i;
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();
        if (error.getError().getAvailability_from() != null) {
            Toast.makeText(this, error.getError().getAvailability_from(), Toast.LENGTH_SHORT).show();
        } else if (error.getError().getAvailability_to() != null) {
            Toast.makeText(this, error.getError().getAvailability_to(), Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
        String item = parent.getItemAtPosition(position).toString();
        // Showing selected spinner item
        if (position != 0) {
            cuisineType = cuisinesList.get(position - 1).getId();
        } else {
            cuisineType = 0;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        cuisineType = 0;
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        if (t == 1) {
            String day = "";
            String month = "";
            if (String.valueOf(monthOfYear + 1).length() == 1) {
                month = "0" + (monthOfYear + 1);
            } else {
                month = (monthOfYear + 1) + "";
            }
            if (String.valueOf(dayOfMonth).length() == 1) {
                day = "0" + dayOfMonth;
            } else {
                day = dayOfMonth + "";
            }
            tvTime.setText(year + "/" + month + "/" + day);
            date = year + "/" + month + "/" + day;
            available_date_time = year + "-" + month + "-" + day;

            Calendar now = Calendar.getInstance();
            TimePickerDialog dpd = TimePickerDialog.newInstance(
                    AddProductActivity.this,
                    now.get(Calendar.HOUR_OF_DAY),
                    now.get(Calendar.MINUTE),
                    true
            );
            dpd.setMaxTime(23, 0, 0);
            dpd.setTitle(getResources().getString(R.string.time_msg));
            dpd.show(getFragmentManager(), "Datepickerdialog");
        } else {

            String day = "";
            String month = "";
            if (String.valueOf(monthOfYear + 1).length() == 1) {
                month = "0" + (monthOfYear + 1);
            } else {
                month = (monthOfYear + 1) + "";
            }
            if (String.valueOf(dayOfMonth).length() == 1) {
                day = "0" + dayOfMonth;
            } else {
                day = dayOfMonth + "";
            }
            tv_timeTo.setText(year + "/" + month + "/" + day);
            date_ = year + "/" + month + "/" + day;
            available_date_time_to = year + "-" + month + "-" + day;

            Calendar now = Calendar.getInstance();
            TimePickerDialog dpd = TimePickerDialog.newInstance(
                    AddProductActivity.this,
                    now.get(Calendar.HOUR_OF_DAY),
                    now.get(Calendar.MINUTE),
                    true
            );
            dpd.setMaxTime(23, 0, 0);
            dpd.setTitle(getResources().getString(R.string.time_msg));
            dpd.show(getFragmentManager(), "Datepickerdialog");
        }
    }

    @Override
    public void onTimeSet(TimePickerDialog view, int hourOfDay, int minute, int second) {
        if (t == 1) {
            String sec = "" + second;
            String min = "" + minute;
            String hour = "" + hourOfDay;
            if (String.valueOf(hourOfDay).length() == 1) {
                hour = "0" + hourOfDay;
            }
            if (String.valueOf(minute).length() == 1) {
                min = "0" + minute;
            }
            if (String.valueOf(second).length() == 1) {
                sec = "0" + second;
            }
            tvTime.setText(date + " " + hour + ":" + min + ":" + sec);
            available_date_time = available_date_time + " " + hour + ":" + min + ":" + sec;
        } else {
            String sec = "" + second;
            String min = "" + minute;
            String hour = "" + hourOfDay;
            if (String.valueOf(hourOfDay).length() == 1) {
                hour = "0" + hourOfDay;
            }
            if (String.valueOf(minute).length() == 1) {
                min = "0" + minute;
            }
            if (String.valueOf(second).length() == 1) {
                sec = "0" + second;
            }
            tv_timeTo.setText(date_ + " " + hour + ":" + min + ":" + sec);
            available_date_time_to = available_date_time_to + " " + hour + ":" + min + ":" + sec;
        }
    }
}

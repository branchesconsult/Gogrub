package com.app.gogrub.activities;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.CancelledAdapter;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.chefOrders.Order;
import com.app.gogrub.models.chefOrders.OrdersResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class CancelledOrders extends AppCompatActivity implements ResponseHandler {
    private ImageView ivBack;
    private RecyclerView recyclerView;
    private TextView noData;

    ArrayList<Order> list;
    SessionManager sessionManager;

    CancelledAdapter adapter;

    private void findViews() {
        ivBack = (ImageView) findViewById(R.id.iv_back);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        noData = (TextView) findViewById(R.id.no_data);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cancelled_orders);

        sessionManager = new SessionManager(this);
        list = new ArrayList<>();

        adapter = new CancelledAdapter(this, list);

        findViews();

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);
        fetchCancelOrders();
    }

    private void fetchCancelOrders() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(CancelledOrders.this, GoGrub.getRestClient().getCancelledOrders(new SessionManager(this).get(Constants.ACCESS_TOKEN)), 1);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();

        OrdersResponse ordersResponse = (OrdersResponse) response.body();
        list.clear();
        if (ordersResponse.getOrders().size() > 0) {
            noData.setVisibility(View.GONE);
            list.addAll(ordersResponse.getOrders());
        } else {
            noData.setVisibility(View.VISIBLE);
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();
    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

}


package com.app.gogrub.models.msgResponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SendMsgResponse {

    @SerializedName("chat")
    @Expose
    private Chat chat;

    public Chat getChat() {
        return chat;
    }

    public void setChat(Chat chat) {
        this.chat = chat;
    }

}

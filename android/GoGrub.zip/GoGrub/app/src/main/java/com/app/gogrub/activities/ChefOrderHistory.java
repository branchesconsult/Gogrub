package com.app.gogrub.activities;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.ChefActiveAdapter;
import com.app.gogrub.adapters.ChefCompletedAdapter;
import com.app.gogrub.fragments.MessageEvent;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.chefOrders.Order;
import com.app.gogrub.models.chefOrders.OrdersResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.SessionManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ChefOrderHistory extends AppCompatActivity implements ResponseHandler, SwipeRefreshLayout.OnRefreshListener {


    ArrayList<Order> activelist = new ArrayList<>();
    ArrayList<Order> completelist = new ArrayList<>();
    ChefActiveAdapter activeAdapter;
    ChefCompletedAdapter completedAdapter;
    RecyclerView recyclerView;
    ImageView iv_back;
    TextView no_data;
    private ImageView imgOrder;

    private TextView active;
    private TextView completed;
    boolean isActive = true;
    private int val = 1;

    SwipeRefreshLayout mSwipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chef_orderhistory);

        iv_back = findViewById(R.id.iv_back);
        recyclerView = findViewById(R.id.recyclerView);
        no_data = findViewById(R.id.no_data);
        imgOrder = (ImageView) findViewById(R.id.img_order);
        active = (TextView) findViewById(R.id.active);
        completed = (TextView) findViewById(R.id.completed);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        activeAdapter = new ChefActiveAdapter(this, activelist);
        completedAdapter = new ChefCompletedAdapter(this, completelist);

        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_container);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary,
                android.R.color.holo_green_dark,
                android.R.color.holo_orange_dark,
                android.R.color.holo_blue_dark);

        mSwipeRefreshLayout.post(new Runnable() {

            @Override
            public void run() {

                mSwipeRefreshLayout.setRefreshing(true);

                // Fetching data from server

                getOrders(new SessionManager(ChefOrderHistory.this).get(Constants.ACCESS_TOKEN), 1);

            }
        });


        recyclerView.setAdapter(activeAdapter);
//        completed.setPadding(0, 0, 30, 0);


        completed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgOrder.setImageResource(R.drawable.order_bg_2);
                completed.setTextColor(Color.WHITE);
                active.setTextColor(Color.GRAY);
                val = 2;
//                completed.setPadding(0, 0, 50, 0);
                getOrders(new SessionManager(ChefOrderHistory.this).get(Constants.ACCESS_TOKEN), 2);
            }
        });

        active.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgOrder.setImageResource(R.drawable.order_bg_1);
                completed.setTextColor(Color.GRAY);
                active.setTextColor(Color.WHITE);
                val = 1;
//                completed.setPadding(0, 0, 30, 0);
                getOrders(new SessionManager(ChefOrderHistory.this).get(Constants.ACCESS_TOKEN), 1);

            }
        });


    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MessageEvent event) {
        if (event.getMessage().equalsIgnoreCase("order_updated")) {
            getOrders(new SessionManager(ChefOrderHistory.this).get(Constants.ACCESS_TOKEN), val);

        }
    }

    ;

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    private void getOrders(String token, int i) {
        mSwipeRefreshLayout.setRefreshing(true);
        if (i == 1) {
            isActive = true;
            new RestCaller(ChefOrderHistory.this, GoGrub.getRestClient().getActiveOrders(token), 1);
            recyclerView.setAdapter(activeAdapter);
        } else {
            isActive = false;
            new RestCaller(ChefOrderHistory.this, GoGrub.getRestClient().getCompletedOrders(token), 1);
            recyclerView.setAdapter(completedAdapter);
        }

    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        mSwipeRefreshLayout.setRefreshing(false);

        OrdersResponse ordersResponse = (OrdersResponse) response.body();
        activelist.clear();
        completelist.clear();
        activeAdapter.notifyDataSetChanged();
        completedAdapter.notifyDataSetChanged();
        if (ordersResponse.getOrders().size() > 0) {
            no_data.setVisibility(View.GONE);
            activelist.addAll(ordersResponse.getOrders());
            completelist.addAll(ordersResponse.getOrders());
            if (isActive) {
                activeAdapter.notifyDataSetChanged();
            } else {
                completedAdapter.notifyDataSetChanged();
            }
        } else {
            no_data.setVisibility(View.VISIBLE);
        }

        runLayoutAnimation(recyclerView);


    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        mSwipeRefreshLayout.setRefreshing(false);

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        mSwipeRefreshLayout.setRefreshing(false);

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        mSwipeRefreshLayout.setRefreshing(false);

    }

    private void runLayoutAnimation(final RecyclerView recyclerView) {
        final Context context = recyclerView.getContext();
        final LayoutAnimationController controller =
                AnimationUtils.loadLayoutAnimation(context, R.anim.layout_animation_from_bottom);

        recyclerView.setLayoutAnimation(controller);
//        recyclerView.getAdapter().notifyDataSetChanged();
        recyclerView.scheduleLayoutAnimation();

    }

    @Override
    public void onRefresh() {
        getOrders(new SessionManager(this).get(Constants.ACCESS_TOKEN), val);
    }
}

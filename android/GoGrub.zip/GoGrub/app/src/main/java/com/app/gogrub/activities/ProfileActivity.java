package com.app.gogrub.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.RefreshUserResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.ImageUtils;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.PermissionManager;
import com.app.gogrub.utils.SessionManager;
import com.squareup.picasso.Picasso;

import java.io.File;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;
import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ProfileActivity extends AppCompatActivity implements ResponseHandler {
    private ImageView ivBack;
    private CircleImageView ivChef;
    private EditText et_name;
    private EditText etEmail;
    private EditText etPass;
    private EditText etNewPass, et_old_pass;
    private Button btnSave;
    private String userChoosenTask;

    private static final int SELECT_FILE = 0;
    private static final int REQUEST_CAMERA = 1;
    private PermissionManager permissionsManager;
    MediaType mediaType = MediaType.parse("");
    private String img_path;
    SessionManager sessionManager;
    private MultipartBody.Part dp;

    private String imageFilePath = "";
    private Uri photoURI;

    private void findViews() {
        ivBack = (ImageView) findViewById(R.id.iv_back);
        ivChef = (CircleImageView) findViewById(R.id.iv_chef);
        et_name = (EditText) findViewById(R.id.et_name);
        et_old_pass = findViewById(R.id.et_old_pass);
        etEmail = (EditText) findViewById(R.id.et_email);
        etPass = (EditText) findViewById(R.id.et_pass);
        etNewPass = (EditText) findViewById(R.id.et_new_pass);
        btnSave = (Button) findViewById(R.id.btn_save);

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        etEmail.setEnabled(true);
        ivChef.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectImage();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (img_path == null) {
                    if (et_old_pass.getText().toString().length() > 0) {
                        if (sessionManager.get(Constants.PASSWORD).equalsIgnoreCase(et_old_pass.getText().toString())) {
                            if (etPass.getText().toString().equalsIgnoreCase(etNewPass.getText().toString())) {
                                Loading.show(ProfileActivity.this, false, "Please wait...");
                                new RestCaller(ProfileActivity.this, GoGrub.getRestClient().updateUser(sessionManager.get(Constants.ACCESS_TOKEN),
                                        et_name.getText().toString(),
                                        etEmail.getText().toString(),
                                        et_old_pass.getText().toString(),
                                        etPass.getText().toString(),
                                        etNewPass.getText().toString()), 1);
                            } else {
                                Toast.makeText(ProfileActivity.this, "New Password and Confirm Password does not match", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(ProfileActivity.this, "Old Password is not correct", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    File file = new File(img_path);
                    RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
                    dp =
                            MultipartBody.Part.createFormData("avatar", file.getName(), requestFile);

                    Loading.show(ProfileActivity.this, false, "Please wait...");
                    new RestCaller(ProfileActivity.this, GoGrub.getRestClient().updateUserImage(sessionManager.get(Constants.ACCESS_TOKEN),
                            et_name.getText().toString(),
                            etEmail.getText().toString(),
                            dp), 1);

                }
            }
        });
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_activity);
        findViews();
        sessionManager = new SessionManager(this);

        permissionsManager = PermissionManager.getInstance(this);
        permissionsManager.getPermissionifNotAvailble(new String[]{Manifest.permission.ACCESS_NETWORK_STATE
                , Manifest.permission.INTERNET
                , Manifest.permission.READ_EXTERNAL_STORAGE
                , Manifest.permission.WRITE_EXTERNAL_STORAGE
                , Manifest.permission.CAMERA
        }, 111);
        if (sessionManager.get(Constants.IMG).length() > 0)
            Picasso.with(this).load(sessionManager.get(Constants.IMG)).placeholder(R.drawable.img_placeholder).into(ivChef);

        et_name.setText(sessionManager.get(Constants.NAME));
        etEmail.setText(sessionManager.get(Constants.EMAIL));
        etEmail.setEnabled(true);


    }

    public void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Library",
                "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(ProfileActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask = "Choose from Library";
                    galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent() {
        EasyImage.openGallery(this, SELECT_FILE);
    }

    private void cameraIntent() {
        EasyImage.openCamera(this, REQUEST_CAMERA);
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        EasyImage.handleActivityResult(requestCode, resultCode, data, this, new DefaultCallback() {
            @Override
            public void onImagePicked(File imageFile, EasyImage.ImageSource source, int type) {
                if (type == SELECT_FILE) {
                    img_path = new File(ImageUtils.compressImage(imageFile.getPath())).getPath();
                    Log.d("PATH", "" + img_path);

                    if (img_path != null) {
                        Picasso.with(ProfileActivity.this).load(new File(img_path)).fit().centerCrop().placeholder(R.drawable.img_placeholder).into(ivChef);
                    }
                } else if (type == REQUEST_CAMERA) {
                    img_path = new File(ImageUtils.compressImage(imageFile.getPath())).getPath();
                    Log.d("PATH", "" + img_path);

                    if (img_path != null) {
                        Picasso.with(ProfileActivity.this).load(new File(img_path)).fit().centerCrop().placeholder(R.drawable.img_placeholder).into(ivChef);
                    }
                }
            }
        });


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //  Toast.makeText(ParentActivity.this, "Request Code => "+requestCode, Toast.LENGTH_SHORT).show();
        switch (requestCode) {
            case 111:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {


                } else {
                    Toast.makeText(this, "Please allow the location permission. Thanks", Toast.LENGTH_SHORT).show();
                    permissionsManager = PermissionManager.getInstance(ProfileActivity.this);
                    permissionsManager.getPermissionifNotAvailble(new String[]{Manifest.permission.ACCESS_NETWORK_STATE
                            , Manifest.permission.INTERNET
                            , Manifest.permission.READ_EXTERNAL_STORAGE
                            , Manifest.permission.WRITE_EXTERNAL_STORAGE
                            , Manifest.permission.CAMERA
                    }, 111);
                }
                break;
            default:
                break;
        }
    }


    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();

        RefreshUserResponse loginResponse = (RefreshUserResponse) response.body();

        sessionManager.put(Constants.PHONE, loginResponse.getUser().getMobile());
        sessionManager.put(Constants.NAME, loginResponse.getUser().getFullName());
        sessionManager.put(Constants.EMAIL, loginResponse.getUser().getEmail());
        sessionManager.put(Constants.IMG, loginResponse.getUser().getAvatar());
        sessionManager.put(Constants.isApplied, loginResponse.getUser().isApplied_as_chef());


    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();
    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();
    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();
    }
}

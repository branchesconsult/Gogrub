package com.app.gogrub.activities;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.ChatAdapter;
import com.app.gogrub.laravelechoandroid.Echo;
import com.app.gogrub.laravelechoandroid.EchoCallback;
import com.app.gogrub.laravelechoandroid.EchoOptions;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.MessageModel;
import com.app.gogrub.models.chat.AllChatResponse;
import com.app.gogrub.models.msgResponse.SendMsgResponse;
import com.app.gogrub.models.recMsg.RecMessage;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ChatActivity extends AppCompatActivity implements ResponseHandler {

    ArrayList<MessageModel> list = new ArrayList<>();
    ChatAdapter adapter;
    RecyclerView messageRecyclerView;
    Button sendButton;
    EditText messageEditText;
    ImageView iv_back;
    TextView title;
    private String TAG = "SOCKETIO";
    //    private Echo echo;
    private LinearLayoutManager layoutManager;
    private Echo echo;


    private static final ScheduledExecutorService worker =
            Executors.newSingleThreadScheduledExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        EchoOptions options = new EchoOptions();

// Setup host of your Laravel Echo Server
        options.host = Constants.CHAT_SERVER_URL;

        /*
         * Add headers for authorizing your users (private and presence channels).
         * This line can change matching how you have configured
         * your guards on your Laravel application
         */
        options.headers.put("Authorization", "Bearer {token}");

// Create the client

        echo = new Echo(options);
        echo.connect(new EchoCallback() {
            @Override
            public void call(Object... args) {
                // Success connect
                Log.i(TAG, new Gson().toJson(args));
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                        Toast.makeText(ChatActivity.this, "Success", Toast.LENGTH_SHORT).show();
                        runSubscriber();
                    }
                });
            }
        }, new EchoCallback() {
            @Override
            public void call(Object... args) {
                // Error connect
                Log.i(TAG, new Gson().toJson(args));
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(ChatActivity.this, "Error while connecting to server", Toast.LENGTH_SHORT).show();

                    }
                });
            }
        });


        sendButton = findViewById(R.id.sendButton);
        iv_back = findViewById(R.id.iv_back);
        messageEditText = findViewById(R.id.messageEditText);
        title = findViewById(R.id.title);
        messageRecyclerView = findViewById(R.id.messageRecyclerView);

        layoutManager = new LinearLayoutManager(this);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);
        messageRecyclerView.setLayoutManager(layoutManager);
        messageRecyclerView.setItemAnimator(new DefaultItemAnimator());
        messageRecyclerView.setHasFixedSize(true);
        messageRecyclerView.setItemViewCacheSize(20);
        messageRecyclerView.setDrawingCacheEnabled(true);
        messageRecyclerView.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);


        messageRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        adapter = new ChatAdapter(this, list);
        messageRecyclerView.setAdapter(adapter);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (messageEditText.getText().toString().length() > 0) {
                    list.add(new MessageModel(messageEditText.getText().toString(), true));
                    adapter.notifyDataSetChanged();
                    messageRecyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);
                    addMessage();
                }
            }
        });

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        title.setText(getIntent().getStringExtra("name"));

        getMessages();


    }

    private void getMessages() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(ChatActivity.this, GoGrub.getRestClient().getChat(new SessionManager(this).get(Constants.ACCESS_TOKEN), getIntent().getStringExtra("o_id")), 1);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    private void runSubscriber() {
        echo.channel("order-chat-" + getIntent().getStringExtra("o_id") + "-" + new SessionManager(this).get(Constants.USER_ID))
                .listen(".chat.receive", new EchoCallback() {
                    @Override
                    public void call(final Object... args) {
                        // Event thrown.
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Log.i(TAG, new Gson().toJson(args));
                                String msg_json = new Gson().toJson(args);
//                                msg_json = msg_json.substring(19, msg_json.length() - 1);
                                msg_json = msg_json.substring(msg_json.indexOf(",") + 1);
                                msg_json = msg_json.substring(0, msg_json.length() - 1);
                                RecMessage msgModel = new Gson().fromJson(msg_json, RecMessage.class);
                                MessageModel messageModel = new MessageModel(msgModel.getNameValuePairs().getMessage(), false);
                                list.add(messageModel);
                                adapter.notifyDataSetChanged();

                                messageRecyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);


                            }
                        });
                    }
                });
    }


    private void addMessage() {
        if (Internet.isAvailable(this)) {
            new RestCaller(ChatActivity.this, GoGrub.getRestClient().sendMsg(new SessionManager(this).get(Constants.ACCESS_TOKEN), Integer.parseInt(getIntent().getStringExtra("o_id")), getIntent().getStringExtra("r_id"), messageEditText.getText().toString()), 2);
            messageEditText.setText("");
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        echo.disconnect();
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }


    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        if (reqCode == 1) {
            Loading.cancel();
            AllChatResponse chatResponse = (AllChatResponse) response.body();
            if (chatResponse.getChats().size() > 0) {
                for (int i = 0; i < chatResponse.getChats().size(); i++) {
                    MessageModel messageModel = new MessageModel(chatResponse.getChats().get(i).getMessage(), chatResponse.getChats().get(i).getSender());
                    list.add(messageModel);
                }
                adapter.notifyDataSetChanged();

                Runnable task = new Runnable() {
                    public void run() {
                        messageRecyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);

                    }
                };
                worker.schedule(task, 500, TimeUnit.MILLISECONDS);


            }
        } else {
            SendMsgResponse sendMsgResponse = (SendMsgResponse) response.body();
        }
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    protected void onStart() {
        super.onStart();
        GoGrub.isChat = true;
    }

    @Override
    public void onStop() {
        super.onStop();
        GoGrub.isChat = false;
    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }

}


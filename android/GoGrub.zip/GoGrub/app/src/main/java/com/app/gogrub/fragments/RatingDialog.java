package com.app.gogrub.fragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.AnimationUtility;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;

import org.greenrobot.eventbus.EventBus;

import retrofit2.Call;
import retrofit2.Response;

public class RatingDialog extends DialogFragment implements ResponseHandler {

    private View view;

    private ImageView ivCancel;
    private TextView tvChef;
    private RatingBar ratingbar;
    private EditText etRating;
    private TextView tvCancel;
    private TextView tvOk;
    private Handler handler;

    LinearLayout ll_view;

    private void findViews(View v) {
        ll_view = v.findViewById(R.id.root);
        ivCancel = v.findViewById(R.id.iv_cancel);
        tvChef = v.findViewById(R.id.tv_chef);
        ratingbar = v.findViewById(R.id.ratingbar);
        etRating = v.findViewById(R.id.et_rating);
        tvCancel = v.findViewById(R.id.tv_cancel);
        tvOk = v.findViewById(R.id.tv_ok);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.rate_food, container, false);
        handler = new Handler();

        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setStyle(DialogFragment.STYLE_NO_FRAME, android.R.style.Theme);

        findViews(view);

        tvChef.setText("Rate " + Constants.CHEFNAME);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ll_view.setVisibility(View.VISIBLE);
                AnimationUtility.slideInDown(ll_view);
            }
        }, 300);


        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismissWithAnimation();
            }
        });

        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismissWithAnimation();
            }
        });

        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ratingbar.getRating() != 0.0) {
                    rateOrder();
                } else {
                    Toast.makeText(getActivity(), "Please rate your order", Toast.LENGTH_SHORT).show();
                }
            }
        });


        return view;
    }

    private void rateOrder() {
        if (Internet.isAvailable(getActivity())) {
            Loading.show(getActivity(), false, "Please wait...");
            new RestCaller(RatingDialog.this, GoGrub.getRestClient().rateOrder(new SessionManager(getActivity()).get(Constants.ACCESS_TOKEN),
                    Constants.orderId,
                    ratingbar.getRating() + "",
                    etRating.getText().toString()), 1);
        } else {
            Toast.makeText(getActivity(), "No internet connection", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setLayout(width, height);
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new Dialog(getActivity(), getTheme()) {
            @Override
            public void onBackPressed() {
                dismissWithAnimation();
            }
        };
    }

    private void dismissWithAnimation() {
        try {
            AnimationUtility.slideOutUp(ll_view);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    getDialog().dismiss();
                }
            }, 500);
        } catch (Exception e) {
            Log.e("oncreate ", e.toString());
            e.printStackTrace();
        }
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();

        GenericResponse genericResponse = (GenericResponse) response.body();

        if (genericResponse.isSuccess()) {


            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
            alertDialogBuilder.setTitle(genericResponse.getMessage_title());
            alertDialogBuilder.setMessage(genericResponse.getMsg());
            alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    dismissWithAnimation();
                    EventBus.getDefault().post(new MessageEvent("rated"));
                }
            });

            alertDialogBuilder.create();
            alertDialogBuilder.show();


        }

    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }
}


package com.app.gogrub.models.recMsg;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Chat {

    @SerializedName("nameValuePairs")
    @Expose
    private NameValuePairs_ nameValuePairs;

    public NameValuePairs_ getNameValuePairs() {
        return nameValuePairs;
    }

    public void setNameValuePairs(NameValuePairs_ nameValuePairs) {
        this.nameValuePairs = nameValuePairs;
    }

}

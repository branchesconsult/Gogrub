package com.app.gogrub.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Error {

    @SerializedName("error_title")
    @Expose
    private String errorTitle;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("status_code")
    @Expose
    private Integer statusCode;
    @SerializedName("availability_to")
    private String availability_to;

    @SerializedName("availability_from")
    private String availability_from;

    public String getErrorTitle() {
        return errorTitle;
    }

    public void setErrorTitle(String errorTitle) {
        this.errorTitle = errorTitle;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAvailability_to() {
        return availability_to;
    }

    public void setAvailability_to(String availability_to) {
        this.availability_to = availability_to;
    }

    public String getAvailability_from() {
        return availability_from;
    }

    public void setAvailability_from(String availability_from) {
        this.availability_from = availability_from;
    }
}

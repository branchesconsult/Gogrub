package com.app.gogrub.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.earnings.EarningsResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ChefEarnings extends AppCompatActivity implements ResponseHandler {

    private ImageView ivBack;
    private TextView tvTotal;
    private TextView monthlyEaring;
    private TextView activeOrders;
    private TextView completedOrders;
    private TextView avgRating;
    private CardView cancelOrders;
    private TextView cancelledOrders;
    private SessionManager sessionManager;

    private void findViews() {
        ivBack = (ImageView) findViewById(R.id.iv_back);
        tvTotal = (TextView) findViewById(R.id.tv_total);
        monthlyEaring = (TextView) findViewById(R.id.monthly_earing);
        activeOrders = (TextView) findViewById(R.id.active_orders);
        completedOrders = (TextView) findViewById(R.id.completed_orders);
        avgRating = (TextView) findViewById(R.id.avg_rating);
        cancelOrders = (CardView) findViewById(R.id.cancel_orders);
        cancelledOrders = (TextView) findViewById(R.id.cancelled_orders);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chef_earnings);

        sessionManager = new SessionManager(this);

        findViews();

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        fetchEarnings();

        cancelOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ChefEarnings.this, CancelledOrders.class));
            }
        });


    }

    private void fetchEarnings() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(ChefEarnings.this, GoGrub.getRestClient().fecthEarnings(sessionManager.get(Constants.ACCESS_TOKEN)), 1);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        EarningsResponse earningsResponse = (EarningsResponse) response.body();

        tvTotal.setText("Rs " + earningsResponse.getTotalEarnings());
        completedOrders.setText("" + earningsResponse.getCompletedOrders());
        monthlyEaring.setText(earningsResponse.getCurrentMonthEarnings());
        activeOrders.setText("" + earningsResponse.getActiveOrders());
        avgRating.setText(earningsResponse.getAvgRating() + "");
        cancelledOrders.setText(earningsResponse.getCancelledOrders() + "");
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

}

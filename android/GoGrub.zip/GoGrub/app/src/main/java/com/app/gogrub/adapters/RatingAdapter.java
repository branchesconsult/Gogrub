package com.app.gogrub.adapters;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.models.products.RatingReview;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RatingAdapter extends RecyclerView.Adapter<RatingVH> {

    Activity activity;
    ArrayList<RatingReview> list;

    public RatingAdapter(Activity activity, ArrayList<RatingReview> list) {
        this.activity = activity;
        this.list = list;
    }

    @NonNull
    @Override
    public RatingVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new RatingVH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_rating, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RatingVH holder, int position) {

        holder.userName.setText(list.get(position).getUser().getFullName());
        Picasso.with(activity).load(list.get(position).getUser().getAvatar()).centerCrop().fit().into(holder.userImg);
        holder.review.setText(list.get(position).getReview());
        double d = list.get(position).getRating();

        holder.rating.setRating((float) d);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

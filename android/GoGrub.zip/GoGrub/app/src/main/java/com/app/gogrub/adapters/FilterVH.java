package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.app.gogrub.R;

/**
 * Created by farazqureshi on 31/07/2018.
 */

public class FilterVH extends RecyclerView.ViewHolder {

    TextView item_title;
    RecyclerView itemsRecylcer;

    public FilterVH(View itemView) {
        super(itemView);

        itemsRecylcer = itemView.findViewById(R.id.itemsRecylcer);
        item_title =itemView.findViewById(R.id.item_title);

    }
}

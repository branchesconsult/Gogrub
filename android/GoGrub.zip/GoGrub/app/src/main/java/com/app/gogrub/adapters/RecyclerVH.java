package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.gogrub.R;

/**
 * Created by farazqureshi on 31/07/2018.
 */

public class RecyclerVH extends RecyclerView.ViewHolder{

    ImageView iv_check;
    TextView tv_txt;

    public RecyclerVH(View itemView) {
        super(itemView);
        iv_check = itemView.findViewById(R.id.iv_check);
        tv_txt = itemView.findViewById(R.id.tv_title);
    }
}

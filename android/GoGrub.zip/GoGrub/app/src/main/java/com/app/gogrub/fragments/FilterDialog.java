package com.app.gogrub.fragments;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.R;
import com.app.gogrub.activities.DashboardActivity;
import com.app.gogrub.adapters.FilterAdapter;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.FilterModel;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.PlaceInfo;
import com.app.gogrub.models.RecyclerModel;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.utils.AnimationUtility;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.warkiz.widget.IndicatorSeekBar;
import com.warkiz.widget.OnSeekChangeListener;
import com.warkiz.widget.SeekParams;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;

import static android.content.Context.LOCATION_SERVICE;

public class FilterDialog extends DialogFragment implements ResponseHandler,
        GoogleApiClient.OnConnectionFailedListener {

    private LinearLayout root;
    private CardView container;
    private RelativeLayout topCon;
    private ImageView ivCancel;
    private LinearLayout llDistance;
    private TextView tvDistance;
    private LinearLayout llLocation;
    private TextView tvLoc;
    private LinearLayout etLocCon;
    private LinearLayout seekCon;
    private IndicatorSeekBar seekBar;
    private RecyclerView dialogRecycler;
    private TextView tvClear;
    private TextView tvOk;
    private PlaceInfo mPlace;
    public ArrayList<String> placesList = new ArrayList<>();

    View view;
    private Handler handler;

    ArrayList<FilterModel> filterModels = new ArrayList<>();
    FilterAdapter filterAdapter;
    private AlertDialog alertDialog;

    ImageView iv_current_loc;
    EditText et_address;

    String TAG = "FILTER";
    private SessionManager sessionManager;

    private void findViews(View v) {
        root = (LinearLayout) v.findViewById(R.id.root);
        container = (CardView) v.findViewById(R.id.container);
        topCon = (RelativeLayout) v.findViewById(R.id.top_con);
        ivCancel = (ImageView) v.findViewById(R.id.iv_cancel);
        llDistance = (LinearLayout) v.findViewById(R.id.ll_distance);
        tvDistance = (TextView) v.findViewById(R.id.tv_distance);
        llLocation = (LinearLayout) v.findViewById(R.id.ll_location);
        tvLoc = (TextView) v.findViewById(R.id.tv_loc);
        etLocCon = (LinearLayout) v.findViewById(R.id.et_loc_con);
        seekCon = (LinearLayout) v.findViewById(R.id.seek_con);
        seekBar = (IndicatorSeekBar) v.findViewById(R.id.seekBar);
        dialogRecycler = (RecyclerView) v.findViewById(R.id.dialogRecycler);
        tvClear = (TextView) v.findViewById(R.id.tv_clear);
        tvOk = (TextView) v.findViewById(R.id.tv_ok);
        et_address = v.findViewById(R.id.et_address);
        iv_current_loc = v.findViewById(R.id.iv_current_loc);

        llDistance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llDistance.setBackgroundColor(getResources().getColor(R.color.green));
                tvDistance.setTextColor(getResources().getColor(R.color.white));

                llLocation.setBackgroundColor(getResources().getColor(R.color.white));
                tvLoc.setTextColor(getResources().getColor(R.color.dark_gray));

                seekCon.setVisibility(View.VISIBLE);
                etLocCon.setVisibility(View.GONE);
            }
        });

        llLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llLocation.setBackgroundColor(getResources().getColor(R.color.green));
                tvLoc.setTextColor(getResources().getColor(R.color.white));

                llDistance.setBackgroundColor(getResources().getColor(R.color.white));
                tvDistance.setTextColor(getResources().getColor(R.color.dark_gray));

                etLocCon.setVisibility(View.VISIBLE);
                seekCon.setVisibility(View.GONE);

            }
        });


//        et_address.setOnItemClickListener(mAutocompleteClickListener);


        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismissWithAnimation();
            }
        });


        LocationManager service = (LocationManager) getActivity().getSystemService(LOCATION_SERVICE);
        boolean enabled = service
                .isProviderEnabled(LocationManager.GPS_PROVIDER);

        if (!enabled) {
            alertDialog = new AlertDialog.Builder(
                    getActivity()).create();
            alertDialog.setTitle("Attention");
            alertDialog.setMessage("Please enable your location from settings");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    startActivity(intent);
                }
            });
            alertDialog.show();
        }

        seekBar.setOnSeekChangeListener(new OnSeekChangeListener() {
            @Override
            public void onSeeking(SeekParams seekParams) {
//                        String TAG = "seekBar";
//                        Log.i(TAG, seekParams.seekBar.toString());
//                        Log.i(TAG, seekParams.progress + "");
//                        Log.i(TAG, seekParams.progressFloat + "");
//                        Log.i(TAG, seekParams.fromUser + "");
//                        //when tick count > 0
//                        Log.i(TAG, seekParams.thumbPosition + "");
//                        Log.i(TAG, seekParams.tickText);
//
//          seekBar.setIndicatorTextFormat("${PROGRESS} %");

                Constants.distance = seekParams.seekBar.getProgress() + "";

            }

            @Override
            public void onStartTrackingTouch(IndicatorSeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(IndicatorSeekBar seekBar) {
            }
        });


        et_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent intent =
                            new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY)
                                    .build((DashboardActivity) getActivity());
                    getActivity().startActivityForResult(intent, Constants.PLACE_AUTOCOMPLETE_REQUEST_CODE);
                } catch (GooglePlayServicesRepairableException e) {
                    // TODO: Handle the error.
                } catch (GooglePlayServicesNotAvailableException e) {
                    // TODO: Handle the error.
                }

            }
        });


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.dialog, container, false);
        handler = new Handler();

        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setStyle(DialogFragment.STYLE_NO_FRAME, android.R.style.Theme);

        findViews(view);

        sessionManager = new SessionManager(getActivity());

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                root.setVisibility(View.VISIBLE);
                AnimationUtility.slideInDown(root);
            }
        }, 300);

        dialogRecycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));

        ArrayList<RecyclerModel> items1 = new ArrayList();
        ArrayList<RecyclerModel> items2 = new ArrayList();
        ArrayList<RecyclerModel> items3 = new ArrayList();

//        items1.add(new RecyclerModel("Best Match", false));
        items1.add(new RecyclerModel("Price", false));
        items1.add(new RecyclerModel("Name", false));
        items1.add(new RecyclerModel("Rating", false));

        items2.add(new RecyclerModel("Chinese", false));
        items2.add(new RecyclerModel("Pakistani", false));
        items2.add(new RecyclerModel("Italian", false));

        items3.add(new RecyclerModel("First Order Discount", false));
        items3.add(new RecyclerModel("Minimum Spend Discount", false));
        items3.add(new RecyclerModel("Meal Deals", false));

        filterModels.add(new FilterModel("Sort By", items1));
        filterModels.add(new FilterModel("Cuisines", items2));

        filterAdapter = new FilterAdapter(getActivity(), filterModels);
        dialogRecycler.setAdapter(filterAdapter);


        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismissWithAnimation();
            }
        });

        tvClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismissWithAnimation();
            }
        });

        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.applyFilter = true;
                EventBus.getDefault().post(new MessageEvent("filter"));
                dismissWithAnimation();

            }
        });

        iv_current_loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.currentLocation = true;
                et_address.setText(new SessionManager(getActivity()).get(Constants.ADDRESS_ONE));

            }
        });


        return view;
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new Dialog(getActivity(), getTheme()) {
            @Override
            public void onBackPressed() {
                dismissWithAnimation();
            }
        };
    }

    private void dismissWithAnimation() {
        try {
            AnimationUtility.slideOutUp(root);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    getDialog().dismiss();
                }
            }, 500);
        } catch (Exception e) {
            Log.e("oncreate ", e.toString());
            e.printStackTrace();
        }
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();

        GenericResponse genericResponse = (GenericResponse) response.body();

        if (genericResponse.isSuccess()) {
            Toast.makeText(getActivity(), genericResponse.getMsg(), Toast.LENGTH_SHORT).show();
            dismissWithAnimation();
        }

    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setLayout(width, height);
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        if (!Constants.currentLocation) {
            et_address.setText(sessionManager.get(Constants.TEMP_ADDRESS));

        }
    }

}

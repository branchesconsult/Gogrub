package com.app.gogrub.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.RefreshUserResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class BecomeChef extends AppCompatActivity implements ResponseHandler {
    private LinearLayout startSelling;

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-17 16:31:50 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    private void findViews() {
        startSelling = (LinearLayout) findViewById(R.id.start_selling);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.become_chef);

        findViews();

        startSelling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refreshUser();
            }
        });

        findViewById(R.id.iv_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void refreshUser() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(BecomeChef.this, GoGrub.getRestClient().refreshUser(new SessionManager(BecomeChef.this).get(Constants.ACCESS_TOKEN)), 2);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        Loading.cancel();
        RefreshUserResponse loginResponse = (RefreshUserResponse) response.body();
        if (loginResponse.getUser().isChef() && loginResponse.getUser().isApplied_as_chef()) {
            startActivity(new Intent(BecomeChef.this, AddProductActivity.class));
        } else if (!loginResponse.getUser().isChef() && loginResponse.getUser().isApplied_as_chef()) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(BecomeChef.this);
            alertDialogBuilder.setTitle("Attention");
            alertDialogBuilder.setMessage("You already applied for chef registration services");
            alertDialogBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            alertDialogBuilder.create();
            alertDialogBuilder.show();
        } else if (!loginResponse.getUser().isChef() && !loginResponse.getUser().isApplied_as_chef()) {
            startActivity(new Intent(BecomeChef.this, ChefRegisterationActivity.class));
        }
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }
}

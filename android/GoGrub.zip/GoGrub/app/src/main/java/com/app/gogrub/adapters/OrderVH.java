package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.app.gogrub.R;

/**
 * Created by devicebee on 01/08/2018.
 */

public class OrderVH extends RecyclerView.ViewHolder {

    TextView orderId, orderTime, orderItem, orderPrice;
    Button btn_rate;

    public OrderVH(View itemView) {
        super(itemView);
        orderId = itemView.findViewById(R.id.tv_orderid);
        orderTime = itemView.findViewById(R.id.tv_ordertime);
        orderItem = itemView.findViewById(R.id.tv_order_list);
        orderPrice = itemView.findViewById(R.id.tv_total_price);
        btn_rate = itemView.findViewById(R.id.btn_rate);

    }
}

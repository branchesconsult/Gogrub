package com.app.gogrub.activities;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.page.PageResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class PageActivity extends AppCompatActivity implements ResponseHandler{

    ImageView iv_back;
    TextView tv_description, tv_title;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_activity);

        iv_back = findViewById(R.id.iv_back);
        tv_title = findViewById(R.id.tv_title);
        tv_description = findViewById(R.id.tv_description);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        tv_title.setText(Constants.TITLE);
        getDescription();


    }

    private void getDescription() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            if (Constants.TITLE.startsWith("Terms")) {
                new RestCaller(PageActivity.this, GoGrub.getRestClient().getTerms(), 1);
            } else if (Constants.TITLE.startsWith("About")) {
                new RestCaller(PageActivity.this, GoGrub.getRestClient().getAbout(), 1);
            } else {
                new RestCaller(PageActivity.this, GoGrub.getRestClient().getPrivacy(), 1);
            }
        } else {
            Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        PageResponse pageResponse = (PageResponse)response.body();
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            tv_description.setText(Html.fromHtml(pageResponse.getPage().getDescription(), Html.FROM_HTML_MODE_LEGACY));
        }else {
            tv_description.setText(Html.fromHtml(pageResponse.getPage().getDescription()));
        }

    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }
}

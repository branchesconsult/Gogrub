package com.app.gogrub.models;

import java.util.ArrayList;

/**
 * Created by farazqureshi on 31/07/2018.
 */

public class FilterModel {

    String title;
    ArrayList<RecyclerModel> items;

    public FilterModel(String title, ArrayList<RecyclerModel> items) {
        this.title = title;
        this.items = items;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList<RecyclerModel> getItems() {
        return items;
    }

    public void setItems(ArrayList<RecyclerModel> items) {
        this.items = items;
    }
}

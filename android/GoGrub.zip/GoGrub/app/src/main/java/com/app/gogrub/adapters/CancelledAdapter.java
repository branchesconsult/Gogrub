package com.app.gogrub.adapters;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.models.chefOrders.Order;

import java.util.ArrayList;

public class CancelledAdapter extends RecyclerView.Adapter<CancelledVH> {

    Activity activity;
    ArrayList<Order> list;

    public CancelledAdapter(Activity activity, ArrayList<Order> list) {
        this.activity = activity;
        this.list = list;
    }

    @NonNull
    @Override
    public CancelledVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CancelledVH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cancel, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CancelledVH holder, int position) {

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

package com.app.gogrub.activities;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.MessageAdapter;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.chatMessages.ChatHistoryResponse;
import com.app.gogrub.models.chatMessages.ChatsSummery;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.SessionManager;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ChatHistory extends AppCompatActivity implements ResponseHandler, SwipeRefreshLayout.OnRefreshListener {

    MessageAdapter adapter;
    private ImageView ivBack;
    private RecyclerView recyclerView;
    private TextView noData;
    private ArrayList<ChatsSummery> list = new ArrayList<>();

    SwipeRefreshLayout mSwipeRefreshLayout;

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-12 13:42:06 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    private void findViews() {
        ivBack = (ImageView) findViewById(R.id.iv_back);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        noData = (TextView) findViewById(R.id.no_data);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_history);

        findViews();

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        adapter = new MessageAdapter(this, list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);

        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_container);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary,
                android.R.color.holo_green_dark,
                android.R.color.holo_orange_dark,
                android.R.color.holo_blue_dark);

        mSwipeRefreshLayout.post(new Runnable() {

            @Override
            public void run() {
                // Fetching data from server

                getChats();
            }
        });


        if (list.size() > 0) {
            noData.setVisibility(View.GONE);
        } else {
            noData.setVisibility(View.VISIBLE);
        }


    }

    private void getChats() {
        if (Internet.isAvailable(this)) {
            mSwipeRefreshLayout.setRefreshing(true);
            new RestCaller(ChatHistory.this, GoGrub.getRestClient().getChats(new SessionManager(this).get(Constants.ACCESS_TOKEN)), 1);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        mSwipeRefreshLayout.setRefreshing(false);

        ChatHistoryResponse chatHistoryResponse = (ChatHistoryResponse) response.body();
        list.clear();
        if (chatHistoryResponse.getChatsSummery().size() > 0) {
            noData.setVisibility(View.GONE);
            list.addAll(chatHistoryResponse.getChatsSummery());
        } else {
            noData.setVisibility(View.VISIBLE);
        }
        adapter.notifyDataSetChanged();

    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        mSwipeRefreshLayout.setRefreshing(false);

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        mSwipeRefreshLayout.setRefreshing(false);

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        mSwipeRefreshLayout.setRefreshing(false);

    }

    @Override
    public void onRefresh() {
        getChats();
    }
}

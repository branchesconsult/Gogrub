package com.app.gogrub;

import android.app.Application;

import com.app.gogrub.restapis.RestApis;
import com.app.gogrub.restapis.RetroClient;

import retrofit2.Retrofit;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

/**
 * Created by farazqureshi on 30/07/2018.
 */

public class GoGrub extends Application {

    public static boolean isChat=false;
    private static GoGrub _instance;

    public static GoGrub getAppContext() {
        return _instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        _instance = this;
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/segoeui-medium.ttf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );

    }

    public static RestApis getRestClient() {
        return RetroClient.getRetroClient().getApiServices();
    }

    public static Retrofit getRetrofit() {
        return RetroClient.getRetroClient().getRetrofit();
    }


}


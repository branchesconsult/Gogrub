package com.app.gogrub.adapters;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.models.chefOrderDetail.Detail;

import java.util.ArrayList;

public class ChefItemDetailAdapter extends RecyclerView.Adapter<ChefItemVH> {

    Activity activity;
    ArrayList<Detail> list;

    public ChefItemDetailAdapter(Activity activity, ArrayList<Detail> list) {
        this.activity = activity;
        this.list = list;
    }

    @NonNull
    @Override
    public ChefItemVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.chef_detail_item, parent, false);
        return new ChefItemVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ChefItemVH holder, int position) {

        Detail item = list.get(position);
        if (item.getProduct() != null) {
            holder.itemName.setText(item.getProduct().getName());
        }

        holder.itemPrice.setText("Rs " + list.get(position).getPrice());
        holder.itemQty.setText("" + list.get(position).getQty());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

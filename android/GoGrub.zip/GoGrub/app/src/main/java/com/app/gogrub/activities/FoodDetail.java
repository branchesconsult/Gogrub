package com.app.gogrub.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.RatingAdapter;
import com.app.gogrub.fragments.InfoDialog;
import com.app.gogrub.fragments.OrderDialog;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.productDetail.ProductDetailResponse;
import com.app.gogrub.models.products.RatingReview;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;
import com.daimajia.slider.library.Indicators.PagerIndicator;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.DefaultSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;


public class FoodDetail extends AppCompatActivity implements ResponseHandler, BaseSliderView.OnSliderClickListener {

    private ImageView ivBack;
    private TextView pName;
    private ImageView ivInfo, pImage;
    private TextView pPrice;
    private CardView container;
    private TextView tv_status;
    private TextView pCuisine;
    private TextView pServing;
    private TextView pPostTime;
    private TextView pDesc;
    private CardView rateCon;
    private LinearLayout llRateCon;
    private TextView tvRating;
    private RatingBar rtbProductRating;
    private CircleImageView user_img;
    private CardView aboutCon;
    private TextView tvAbt;
    private CircleImageView chef_img;
    private TextView chefName;
    private TextView chefDesc;
    private FloatingActionButton btnChat;
    private Button btnContinue;
    private SessionManager sessionManager;
    CardView about_con;
    private SliderLayout slider;
    int position_pic = 0;

    RatingAdapter adapter;
    RecyclerView reviewRecycler;
    private ArrayList<RatingReview> list;

    private void findViews() {
        slider = findViewById(R.id.slider);
        ivBack = (ImageView) findViewById(R.id.iv_back);
        pName = (TextView) findViewById(R.id.pName);
        ivInfo = (ImageView) findViewById(R.id.iv_info);
        pPrice = (TextView) findViewById(R.id.pPrice);
        container = (CardView) findViewById(R.id.container);
        tv_status = (TextView) findViewById(R.id.tv_status);
        pCuisine = (TextView) findViewById(R.id.pCuisine);
        pServing = (TextView) findViewById(R.id.pServing);
        pPostTime = (TextView) findViewById(R.id.pPostTime);
        pDesc = (TextView) findViewById(R.id.pDesc);
//        pImage = findViewById(R.id.pImage);
        rateCon = (CardView) findViewById(R.id.rate_con);
        llRateCon = (LinearLayout) findViewById(R.id.ll_rate_con);
        tvRating = (TextView) findViewById(R.id.tv_rating);
        rtbProductRating = (RatingBar) findViewById(R.id.rtbProductRating);
        user_img = findViewById(R.id.user_img);
        aboutCon = (CardView) findViewById(R.id.about_con);
        tvAbt = (TextView) findViewById(R.id.tv_abt);
        chef_img = findViewById(R.id.chef_img);
        chefName = (TextView) findViewById(R.id.chef_name);
        chefDesc = (TextView) findViewById(R.id.chef_desc);
        btnChat = (FloatingActionButton) findViewById(R.id.btn_chat);
        btnContinue = (Button) findViewById(R.id.btn_continue);
        about_con = findViewById(R.id.about_con);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_detail);

        sessionManager = new SessionManager(this);

        findViews();

        list = new ArrayList<>();

        ivInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                InfoDialog dialog = new InfoDialog();
                dialog.show(fragmentManager, "");
            }
        });

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                OrderDialog dialog = new OrderDialog();
                dialog.show(fragmentManager, "");
            }
        });

        btnChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FoodDetail.this, ChatActivity.class));
            }
        });

        reviewRecycler = findViewById(R.id.reviewRecycler);
        adapter = new RatingAdapter(this, list);
        reviewRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        reviewRecycler.setAdapter(adapter);

        about_con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FoodDetail.this, ChefProfile.class));
            }
        });

        getProductDetails(Constants.productId);


    }

    private void getProductDetails(int productId) {
        Loading.show(this, false, "Please wait...");
        new RestCaller(FoodDetail.this, GoGrub.getRestClient().getProductDetail(sessionManager.get(Constants.ACCESS_TOKEN), productId), 1);
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();

        ProductDetailResponse productDetailResponse = (ProductDetailResponse) response.body();

        Constants.product = productDetailResponse;
        Constants.CHEF = productDetailResponse.getProduct().getChef();

        pName.setText(productDetailResponse.getProduct().getName().substring(0, 1).toUpperCase() + productDetailResponse.getProduct().getName().substring(1));
        pPrice.setText("Rs " + productDetailResponse.getProduct().getPrice());
        if (productDetailResponse.getProduct().getRemaining_servings() == 0) {
            tv_status.setText("Sold Out!");
            tv_status.setTextColor(getResources().getColor(R.color.red));

            btnContinue.setClickable(false);
            btnContinue.setText("Sold Out!");
            btnContinue.setBackground(getResources().getDrawable(R.drawable.btn_gray));
        } else {
            tv_status.setText("Available");
            tv_status.setTextColor(getResources().getColor(R.color.green_txt));
        }


        chefDesc.setText(productDetailResponse.getProduct().getChef().getDescription());
        pCuisine.setText(productDetailResponse.getProduct().getCuisine().getName());
        pServing.setText("For " + productDetailResponse.getProduct().getServingSize() + " Person");
        pPostTime.setText(productDetailResponse.getProduct().getPosted_at());
        pDesc.setText(productDetailResponse.getProduct().getDescription());

//        Picasso.with(this).load(productDetailResponse.getProduct().getImages().get(0).getImageLarge()).into(pImage);

        if (productDetailResponse.getProduct().getChef().getRatingReviews().size() == 0) {
            rateCon.setVisibility(View.GONE);
        } else {
            tvRating.setText(productDetailResponse.getProduct().getChef().getAvgRating() + "");
            double d = productDetailResponse.getProduct().getChef().getAvgRating();
            rtbProductRating.setRating((float) d);
            list.addAll(productDetailResponse.getProduct().getChef().getRatingReviews());
            adapter.notifyDataSetChanged();
        }

        for (int i = 0; i < Constants.product.getProduct().getImages().size(); i++) {
            DefaultSliderView sliderView = new DefaultSliderView(FoodDetail.this);

            sliderView
                    .image(Constants.product.getProduct().getImages().get(i).getImageLarge())
                    .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                    .empty(R.drawable.img_placeholder)
                    .setOnSliderClickListener(this);

            slider.addSlider(sliderView);
        }
//        slider.setPresetTransformer(SliderLayout.Transformer.Default);
        slider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
        slider.stopAutoCycle();
//        slider.setCustomAnimation(new DescriptionAnimation());
//        slider.setDuration(5000);
        slider.setIndicatorVisibility(PagerIndicator.IndicatorVisibility.Visible);
        Picasso.with(this).load(Constants.product.getProduct().getChef().getAvatar()).centerCrop().fit().into(chef_img);

        slider.addOnPageChangeListener(new ViewPagerEx.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float v, int i1) {

            }

            @Override
            public void onPageSelected(int position) {
                position_pic = position;

            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });


        chefName.setText(productDetailResponse.getProduct().getChef().getFullName().substring(0, 1).toUpperCase() + productDetailResponse.getProduct().getChef().getFullName().substring(1));

//        if (productDetailResponse.getProduct().getChef().getMeta().size() > 0)
//            chefDesc.setText(productDetailResponse.getProduct().getChef().getMeta().get(0).getChef_intro());
//        else
//            chefDesc.setVisibility(View.INVISIBLE);

    }

    public void changePosition(int position) {
        position_pic = position;
        slider.setCurrentPosition(position);
    }


    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();
        Toast.makeText(this, error.getError().getMessage(), Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onSliderClick(BaseSliderView slider) {
        Intent intent = new Intent(FoodDetail.this, FullScreenImage.class);

        //Constant bna k solve kr li kal
        //ok
        final ProductDetailResponse result = Constants.product;
        intent.putExtra("product", result);
        intent.putExtra("pos", position_pic + "");
        startActivity(intent);

    }
}

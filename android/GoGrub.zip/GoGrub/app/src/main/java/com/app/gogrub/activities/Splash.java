package com.app.gogrub.activities;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.login.LoginResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.PermissionManager;
import com.app.gogrub.utils.SessionManager;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.iid.FirebaseInstanceId;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class Splash extends AppCompatActivity implements ResponseHandler {

    LinearLayout sign_up, ll_fb;
    EditText etMobile, etPassword;
    TextView tv_forgot;
    SessionManager sessionManager;
    private String fcm_token, device_id;
    private FirebaseAnalytics mFirebaseAnalytics;
    private PermissionManager permissionsManager;
    private String email_fb, name, pic;


    private static final ScheduledExecutorService worker =
            Executors.newSingleThreadScheduledExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        sessionManager = new SessionManager(this);

        // Obtain the FirebaseAnalytics instance.
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mFirebaseAnalytics.getAppInstanceId();

        try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "com.app.gogrub",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
//                Toast.makeText(this, ""+Base64.encodeToString(md.digest(), Base64.DEFAULT), Toast.LENGTH_SHORT).show();
            }
        } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }


        fcm_token = FirebaseInstanceId.getInstance().getToken();
        Log.d("MYTAG", "This is your Firebase token : " + fcm_token);
        SessionManager.put(Constants.DEVICE_TOKEN, fcm_token);

        device_id = Settings.Secure.getString(this.getContentResolver(),
                Settings.Secure.ANDROID_ID);

        permissionsManager = PermissionManager.getInstance(Splash.this);
        permissionsManager.getPermissionifNotAvailble(new String[]{android.Manifest.permission.ACCESS_NETWORK_STATE
                , Manifest.permission.INTERNET
                , Manifest.permission.ACCESS_FINE_LOCATION
                , Manifest.permission.ACCESS_COARSE_LOCATION}, 111);

        etMobile = findViewById(R.id.mobile);
        etPassword = findViewById(R.id.password);
        ll_fb = findViewById(R.id.social_tv);
//        fb_btn = findViewById(R.id.fb_btn);
        tv_forgot = findViewById(R.id.tv_forgot);

        tv_forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Splash.this, ForgotPassword.class));
            }
        });

        findViewById(R.id.btn_continue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Internet.isAvailable(Splash.this)) {
                    if (!etMobile.getText().toString().isEmpty() && !etPassword.getText().toString().isEmpty()) {
                        sessionManager.put(Constants.PASSWORD, etPassword.getText().toString());
                        Loading.show(Splash.this, false, "Please wait...");
                        String phone = etMobile.getText().toString();
                        if (phone.startsWith("0")) {
                            phone = phone.substring(1);
                        }
                        new RestCaller(Splash.this, GoGrub.getRestClient().login(phone,
                                etPassword.getText().toString(),
                                Constants.DEVICE_TYPE,
                                fcm_token,
                                device_id), 1);
                    } else {
                        if (etMobile.getText().toString().isEmpty()) {
                            etMobile.setError("Please enter your number");
                        } else if (etPassword.getText().toString().isEmpty()) {
                            etPassword.setError("Please enter your password");
                        } else {
                            Toast.makeText(Splash.this, "Please fill both fields", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(Splash.this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
                }
            }

        });

        sign_up = findViewById(R.id.sign_up);

        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Splash.this, LogRegActivity.class));
            }
        });

        ll_fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                fb_btn.performClick();
            }
        });

//        fb_btn.setReadPermissions(Arrays.asList(
//                "public_profile", "email"));
//        callbackManager = CallbackManager.Factory.create();
//
//
//        fb_btn.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
//            @Override
//            public void onSuccess(LoginResult loginResult) {
//                loginResult.getAccessToken().getUserId();
//                loginResult.getAccessToken().getToken();
//                final AccessToken accessToken = loginResult.getAccessToken();
//
//                GraphRequest request = GraphRequest.newMeRequest(
//                        loginResult.getAccessToken(),
//                        new GraphRequest.GraphJSONObjectCallback() {
//                            @Override
//                            public void onCompleted(JSONObject object, GraphResponse response) {
//                                Log.v("LoginActivity", response.toString());
//
//                                // Application code
//                                try {
//                                    email_fb = object.getString("email");
//                                    Log.v("facebook - profile=data", email_fb);
//
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }
//                            }
//                        });
//                Bundle parameters = new Bundle();
//                parameters.putString("fields", "email");
//                request.setParameters(parameters);
//                request.executeAsync();
//
//                if (Profile.getCurrentProfile() == null) {
//                    Loading.show(Splash.this, false, "Please wait...");
//                    mProfileTracker = new ProfileTracker() {
//                        @Override
//                        protected void onCurrentProfileChanged(Profile profile, Profile profile2) {
//                            // profile2 is the new profile
//                            pic = profile2.getProfilePictureUri(500, 500) + "";
//                            name = profile2.getName();
//                            SessionManager.put(Constants.NAME, name);
//                            SessionManager.put(Constants.IMG, pic);
//                            Log.v("facebook - profile", name + "\n" + pic);
//                            mProfileTracker.stopTracking();
//                            Log.d("login_success_1", "successful");
//                            Runnable task = new Runnable() {
//                                public void run() {
//                                    loginFb(email_fb, name, pic);
//                                }
//                            };
//                            worker.schedule(task, 3000, TimeUnit.MILLISECONDS);
//                        }
//                    };
//
//                } else {
//                    Loading.show(Splash.this, false, "Please wait...");
//                    Profile profile = Profile.getCurrentProfile();
//                    String id = profile.getId();
//                    pic = profile.getProfilePictureUri(500, 500) + "";
//                    name = profile.getName();
//                    SessionManager.put(Constants.NAME, name);
//                    SessionManager.put(Constants.IMG, pic);
//                    Log.d("login_success_2", "successful");
//                    Log.v("facebook", profile.getName() + "\n" + id + "\n" + pic);
//                    Runnable task = new Runnable() {
//                        public void run() {
//                            Loading.show(Splash.this, false, "Please wait...");
//                            loginFb(email_fb, name, pic);
//                        }
//                    };
//                    worker.schedule(task, 3000, TimeUnit.MILLISECONDS);
//
//                }
//            }
//
//
//            @Override
//            public void onCancel() {
//                Toast.makeText(Splash.this, "Login Canceled", Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void onError(FacebookException error) {
//                Toast.makeText(Splash.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });

    }

    private void loginFb(String email, String name, String profile_pic) {
        if (Internet.isAvailable(this)) {
            Loading.show(Splash.this, false, "Please wait...");
            new RestCaller(Splash.this, GoGrub.getRestClient().newFbLogin(email, email, name, profile_pic, SessionManager.get(Constants.DEVICE_TOKEN)), 2);
        } else {
            Toast.makeText(this, "Check your Internet Connection", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }


    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        if (reqCode == 1) {
            LoginResponse loginResponse = (LoginResponse) response.body();
            if (loginResponse.getSuccess()) {
                if (loginResponse.getUser().getConfirmed() == 1) {
                    sessionManager.put(Constants.ACCESS_TOKEN, "Bearer " + loginResponse.getToken());
                    sessionManager.put(Constants.PHONE, loginResponse.getUser().getMobile());
                    sessionManager.put(Constants.USER_ID, loginResponse.getUser().getId() + "");
                    sessionManager.put(Constants.NAME, loginResponse.getUser().getFullName());
                    sessionManager.put(Constants.EMAIL, loginResponse.getUser().getEmail());
                    sessionManager.put(Constants.isChef, loginResponse.getUser().isChef());
                    sessionManager.put(Constants.IMG, loginResponse.getUser().getAvatar());
                    sessionManager.put(Constants.isApplied, loginResponse.getUser().isApplied_as_chef());

//                if (loginResponse.getUser().isChef()) {
//                    startActivity(new Intent(Splash.this, SellerDashboardActivity.class));
//                    this.finish();
//                } else {
                    startActivity(new Intent(Splash.this, DashboardActivity.class));
                    this.finish();
//                }
                } else {
                    sessionManager.put(Constants.ACCESS_TOKEN, "Bearer " + loginResponse.getToken());
                    sessionManager.put(Constants.PHONE, loginResponse.getUser().getMobile());
                    sessionManager.put(Constants.USER_ID, loginResponse.getUser().getId() + "");
                    sessionManager.put(Constants.NAME, loginResponse.getUser().getFullName());
                    sessionManager.put(Constants.EMAIL, loginResponse.getUser().getEmail());
                    sessionManager.put(Constants.isChef, loginResponse.getUser().isChef());
                    sessionManager.put(Constants.IMG, loginResponse.getUser().getAvatar());
                    sessionManager.put(Constants.isApplied, loginResponse.getUser().isApplied_as_chef());
                    startActivity(new Intent(Splash.this, CodeVerificationActivity.class));
                    this.finish();
                }
            } else {
                Toast.makeText(this, loginResponse.getMessage(), Toast.LENGTH_SHORT).show();

            }
        } else {

        }
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();
        Toast.makeText(this, error.getMsg(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();
    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //  Toast.makeText(ParentActivity.this, "Request Code => "+requestCode, Toast.LENGTH_SHORT).show();
        switch (requestCode) {
            case 111:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (sessionManager.checkLogin()) {
                        startActivity(new Intent(Splash.this, DashboardActivity.class));
                        finish();
                    }
                } else {
                    Toast.makeText(this, "Please allow the location permission. Thanks", Toast.LENGTH_SHORT).show();
                    permissionsManager = PermissionManager.getInstance(Splash.this);
                    permissionsManager.getPermissionifNotAvailble(new String[]{android.Manifest.permission.ACCESS_NETWORK_STATE
                            , Manifest.permission.INTERNET
                            , Manifest.permission.ACCESS_FINE_LOCATION
                            , Manifest.permission.ACCESS_COARSE_LOCATION}, 111);
                }
                break;
            default:
                break;
        }
    }
}

package com.app.gogrub.activities;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.ChefItemDetailAdapter;
import com.app.gogrub.fragments.MessageEvent;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.chefOrderDetail.COrderResponse;
import com.app.gogrub.models.chefOrderDetail.Detail;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;
import com.squareup.picasso.Picasso;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ChefOrderDetail extends AppCompatActivity implements ResponseHandler {
    private CardView container;
    private ImageView ivBack;
    private TextView title;
    private RelativeLayout textCon;
    private TextView txtOrder;
    private TextView tvStatus;
    private LinearLayout loSummary;
    private TextView phone;
    private TextView address;
    private CardView bill;
    private LinearLayout con;
    private RecyclerView recyclerView;
    private TextView tvTotal;
    private CardView insCon;
    private TextView tvInstructions;
    private CardView chatCon;
    private CircleImageView userImg;
    private TextView userName, tv_del_charges, txt_chat;
    private Button btnComplete, btnCancel;
    LinearLayout btnCon;
    ChefItemDetailAdapter adapter;

    ArrayList<Detail> list = new ArrayList<>();

    boolean isCompleted;
    private COrderResponse orderDetailResponse;


    private void findViews() {
        container = (CardView) findViewById(R.id.container);
        ivBack = (ImageView) findViewById(R.id.iv_back);
        title = (TextView) findViewById(R.id.title);
        textCon = (RelativeLayout) findViewById(R.id.text_con);
        txtOrder = (TextView) findViewById(R.id.txt_order);
        tvStatus = (TextView) findViewById(R.id.tv_status);
        loSummary = (LinearLayout) findViewById(R.id.loSummary);
        phone = (TextView) findViewById(R.id.phone);
        address = (TextView) findViewById(R.id.address);
        bill = (CardView) findViewById(R.id.bill);
        tv_del_charges = findViewById(R.id.tv_del_charges);
        con = (LinearLayout) findViewById(R.id.con);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        tvTotal = (TextView) findViewById(R.id.tv_total);
        insCon = (CardView) findViewById(R.id.ins_con);
        tvInstructions = (TextView) findViewById(R.id.tv_instructions);
        chatCon = (CardView) findViewById(R.id.chat_con);
        userImg = (CircleImageView) findViewById(R.id.user_img);
        userName = (TextView) findViewById(R.id.user_name);
        btnComplete = (Button) findViewById(R.id.btn_complete);
        btnCon = findViewById(R.id.btnCon);
        txt_chat = findViewById(R.id.txt_chat);
        btnCancel = findViewById(R.id.btnCancel);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chef_order_detail);

        findViews();

        if (getIntent().getStringExtra("completed") != null) {
            btnCon.setVisibility(View.GONE);
            txt_chat.setVisibility(View.GONE);
            chatCon.setClickable(false);
            chatCon.setEnabled(false);
        }


        adapter = new ChefItemDetailAdapter(this, list);

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);

        btnComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                completeOrder();
            }
        });

        chatCon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ChefOrderDetail.this, ChatActivity.class);
                i.putExtra("o_id", orderDetailResponse.getOrder().getId() + "");
                i.putExtra("r_id", orderDetailResponse.getOrder().getCustomerId() + "");
                i.putExtra("name", orderDetailResponse.getOrder().getCustomerFullName() + "");
                startActivity(i);
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ChefOrderDetail.this);
                alertDialogBuilder.setTitle("Attention");
                alertDialogBuilder.setMessage("Are you sure you want to Cancel this order?");
                alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        canceleOrder();
//                    Toast.makeText(NewPlacesActivity.this, "Removed", Toast.LENGTH_SHORT).show();

                    }
                });
                alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();

                    }
                });
                alertDialogBuilder.create();
                alertDialogBuilder.show();
            }
        });

        getChefOrderDetail(getIntent().getStringExtra("o_id"));

    }

    private void getChefOrderDetail(String o_id) {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(ChefOrderDetail.this, GoGrub.getRestClient().getChefOrderDetails(new SessionManager(this).get(Constants.ACCESS_TOKEN),
                    Integer.parseInt(o_id)),
                    1);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    private void canceleOrder() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(ChefOrderDetail.this, GoGrub.getRestClient().changeOrderStauts(new SessionManager(this).get(Constants.ACCESS_TOKEN), orderDetailResponse.getOrder().getId(), Constants.cancel), 2);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    private void completeOrder() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(ChefOrderDetail.this, GoGrub.getRestClient().changeOrderStauts(new SessionManager(this).get(Constants.ACCESS_TOKEN), orderDetailResponse.getOrder().getId(), Constants.completed), 2);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }


    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        if (reqCode == 2) {
            GenericResponse genericResponse = (GenericResponse) response.body();
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ChefOrderDetail.this);
            alertDialogBuilder.setTitle(genericResponse.getMessage_title());
            alertDialogBuilder.setMessage(genericResponse.getMsg());
            alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    finish();

                    EventBus.getDefault().post(new MessageEvent("order_updated"));
                }
            });

            alertDialogBuilder.create();
            alertDialogBuilder.show();
        } else {
            orderDetailResponse = (COrderResponse) response.body();
            userName.setText(orderDetailResponse.getOrder().getCustomerFullName());
            Picasso.with(this).load(orderDetailResponse.getOrder().getUser().getAvatar()).fit().centerCrop().fit().into(userImg);


            phone.setText(orderDetailResponse.getOrder().getCustomerPhone());
            address.setText(orderDetailResponse.getOrder().getCustomerAddress());

            tvTotal.setText("Rs " + orderDetailResponse.getOrder().getTotal());
            title.setText("ID: " + orderDetailResponse.getOrder().getId());
            tv_del_charges.setText("Rs " + orderDetailResponse.getOrder().getDeliveryCharges());

            list.addAll(orderDetailResponse.getOrder().getDetail());
            adapter.notifyDataSetChanged();

            if (orderDetailResponse.getOrder().getSpecialInstructions() != null) {
                insCon.setVisibility(View.VISIBLE);
                tvInstructions.setText(orderDetailResponse.getOrder().getSpecialInstructions());
            } else {
                insCon.setVisibility(View.GONE);
            }


        }


    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }
}

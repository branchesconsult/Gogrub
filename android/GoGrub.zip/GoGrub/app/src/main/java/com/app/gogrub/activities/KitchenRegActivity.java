package com.app.gogrub.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.ChefImageAdapter;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.ImageUtils;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.PermissionManager;
import com.app.gogrub.utils.SessionManager;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;
import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class KitchenRegActivity extends AppCompatActivity implements ResponseHandler {
    private ImageView ivCancel;
    private ImageView ivCamera;
    private ImageView ivGallery;
    private RecyclerView imgRecycler;

    private Button btnNext;

    private static final int SELECT_FILE = 0;
    private static final int REQUEST_CAMERA = 1;
    private PermissionManager permissionsManager;
    ArrayList<String> files; //These are the uris for the files to be uploaded
    MediaType mediaType = MediaType.parse("");

    ArrayList<String> list = new ArrayList<>();
    private String img_path;
    private String userChoosenTask;
    private ChefImageAdapter adapter;
    SessionManager sessionManager;
    private String imageFilePath = "";
    private Uri photoURI;

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-10 14:37:45 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    private void findViews() {
        ivCancel = (ImageView) findViewById(R.id.iv_cancel);
        ivCamera = (ImageView) findViewById(R.id.iv_camera);
        ivGallery = (ImageView) findViewById(R.id.iv_gallery);
        imgRecycler = (RecyclerView) findViewById(R.id.img_recycler);
        btnNext = (Button) findViewById(R.id.btn_next);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kitchen_activity);

        findViews();

        sessionManager = new SessionManager(this);
        files = new ArrayList<>();

        permissionsManager = PermissionManager.getInstance(this);
        permissionsManager.getPermissionifNotAvailble(new String[]{Manifest.permission.ACCESS_NETWORK_STATE
                , Manifest.permission.INTERNET
                , Manifest.permission.READ_EXTERNAL_STORAGE
                , Manifest.permission.WRITE_EXTERNAL_STORAGE
                , Manifest.permission.CAMERA
        }, 111);

        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        ivCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (files.size() < 7) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        cameraIntent();
                    }
                } else {
                    Toast.makeText(KitchenRegActivity.this, "Only 6 images can be uploaded", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ivGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (files.size() < 7) {
                    galleryIntent();
                } else {
                    Toast.makeText(KitchenRegActivity.this, "Only 6 images can be uploaded", Toast.LENGTH_SHORT).show();
                }
            }
        });

        adapter = new ChefImageAdapter(this, list);

        imgRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        imgRecycler.setAdapter(adapter);


        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerChef();
            }
        });

    }

    private File createImageFile() throws IOException {

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
        imageFilePath = image.getAbsolutePath();

        return image;
    }

    public void filesRemove(int i) {
        files.remove(i);
        list.remove(i);
        if (files.size() < 1) {
            btnNext.setEnabled(false);
            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_gray));
        } else {
            btnNext.setEnabled(true);
            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_field));
        }
        adapter.notifyDataSetChanged();
    }


    private void registerChef() {

        if (files.size() > 0) {

            final MultipartBody.Part[] fileParts = new MultipartBody.Part[files.size()];
            for (int i = 0; i < files.size(); i++) {
                File file = new File(files.get(i));
                RequestBody fileBody = RequestBody.create(mediaType, file);
                //Setting the file name as an empty string here causes the same issue, which is sending the request successfully without saving the files in the backend, so don't neglect the file name parameter.
                fileParts[i] = MultipartBody.Part.createFormData(String.format(Locale.ENGLISH, "kitchen_image[%d]", i), file.getName(), fileBody);
            }
            final MultipartBody.Part[] cnic_images = new MultipartBody.Part[Constants.CNIC_Images.size()];
            for (int j = 0; j < Constants.CNIC_Images.size(); j++) {
                File file = new File(Constants.CNIC_Images.get(j));
                RequestBody fileBody = RequestBody.create(mediaType, file);
                //Setting the file name as an empty string here causes the same issue, which is sending the request successfully without saving the files in the backend, so don't neglect the file name parameter.
                cnic_images[j] = MultipartBody.Part.createFormData(String.format(Locale.ENGLISH, "cnic_image[%d]", j), file.getName(), fileBody);
            }

            if (Internet.isAvailable(this)) {
                Loading.show(this, false, "Please wait...");
                new RestCaller(KitchenRegActivity.this, GoGrub.getRestClient().registerChef(sessionManager.get(Constants.ACCESS_TOKEN), cnic_images, fileParts), 1);
            } else {
                Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
            }

        } else {
            Toast.makeText(this, "Please attach kitchen images", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Constants.CNIC_Images.clear();
        finish();
    }

    public void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Library",
                "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(KitchenRegActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask = "Choose from Library";
                    galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent() {
        EasyImage.openGallery(this, SELECT_FILE);
    }

    private void cameraIntent() {
        EasyImage.openCamera(this, REQUEST_CAMERA);
    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        EasyImage.handleActivityResult(requestCode, resultCode, data, this, new DefaultCallback() {
            @Override
            public void onImagePicked(File imageFile, EasyImage.ImageSource source, int type) {
                if (type == SELECT_FILE) {
                    img_path = new File(ImageUtils.compressImage(imageFile.getPath())).getPath();
                    Log.d("PATH", "" + img_path);

                    if (img_path != null) {
                        list.add(0, img_path);
                        files.add(img_path);
                        if (files.size() > 0) {
                            btnNext.setEnabled(true);
                            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_field));
                        } else {
                            btnNext.setEnabled(false);
                            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_gray));

                        }
                        adapter.notifyDataSetChanged();

                        imgRecycler.smoothScrollToPosition(0);
                    }
                } else if (type == REQUEST_CAMERA) {
                    img_path = new File(ImageUtils.compressImage(imageFile.getPath())).getPath();
                    Log.d("PATH", "" + img_path);

                    if (img_path != null) {
                        list.add(0, img_path);
                        files.add(img_path);
                        if (files.size() > 0) {
                            btnNext.setEnabled(true);
                            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_field));
                        } else {
                            btnNext.setEnabled(false);
                            btnNext.setBackground(getResources().getDrawable(R.drawable.btn_gray));

                        }
                        adapter.notifyDataSetChanged();

                        imgRecycler.smoothScrollToPosition(0);
                    }
                }
            }
        });


    }


    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        GenericResponse genericResponse = (GenericResponse) response.body();
        if (genericResponse.isSuccess()) {
            android.support.v7.app.AlertDialog.Builder alertDialogBuilder = new android.support.v7.app.AlertDialog.Builder(KitchenRegActivity.this);
            alertDialogBuilder.setTitle(genericResponse.getMessage_title());
            alertDialogBuilder.setMessage(genericResponse.getMsg());
            alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent i = new Intent(KitchenRegActivity.this, DashboardActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                    dialog.dismiss();
                    finish();

                }
            });
            alertDialogBuilder.create();
            alertDialogBuilder.show();
        }
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //  Toast.makeText(ParentActivity.this, "Request Code => "+requestCode, Toast.LENGTH_SHORT).show();
        switch (requestCode) {
            case 111:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {


                } else {
                    Toast.makeText(this, "Please allow the location permission. Thanks", Toast.LENGTH_SHORT).show();
                    permissionsManager = PermissionManager.getInstance(KitchenRegActivity.this);
                    permissionsManager.getPermissionifNotAvailble(new String[]{Manifest.permission.ACCESS_NETWORK_STATE
                            , Manifest.permission.INTERNET
                            , Manifest.permission.READ_EXTERNAL_STORAGE
                            , Manifest.permission.WRITE_EXTERNAL_STORAGE
                            , Manifest.permission.CAMERA
                    }, 111);
                }
                break;
            default:
                break;
        }
    }

}
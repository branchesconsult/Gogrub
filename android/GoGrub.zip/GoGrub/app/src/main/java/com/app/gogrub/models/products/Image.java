
package com.app.gogrub.models.products;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Image {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("imageable_id")
    @Expose
    private Integer imageableId;
    @SerializedName("imageable_type")
    @Expose
    private String imageableType;
    @SerializedName("image_url")
    @Expose
    private String imageUrl;
    @SerializedName("small_thumb")
    @Expose
    private String smallThumb;
    @SerializedName("medium_thumb")
    @Expose
    private String mediumThumb;
    @SerializedName("image_large")
    @Expose
    private String imageLarge;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getImageableId() {
        return imageableId;
    }

    public void setImageableId(Integer imageableId) {
        this.imageableId = imageableId;
    }

    public String getImageableType() {
        return imageableType;
    }

    public void setImageableType(String imageableType) {
        this.imageableType = imageableType;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getSmallThumb() {
        return smallThumb;
    }

    public void setSmallThumb(String smallThumb) {
        this.smallThumb = smallThumb;
    }

    public String getMediumThumb() {
        return mediumThumb;
    }

    public void setMediumThumb(String mediumThumb) {
        this.mediumThumb = mediumThumb;
    }

    public String getImageLarge() {
        return imageLarge;
    }

    public void setImageLarge(String imageLarge) {
        this.imageLarge = imageLarge;
    }

}

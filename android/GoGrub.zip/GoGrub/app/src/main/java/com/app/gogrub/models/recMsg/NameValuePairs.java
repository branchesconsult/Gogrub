
package com.app.gogrub.models.recMsg;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NameValuePairs {

    @SerializedName("chat")
    @Expose
    private Chat chat;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("message_type")
    @Expose
    private String messageType;
    @SerializedName("is_sender")
    @Expose
    private Boolean isSender;

    public Chat getChat() {
        return chat;
    }

    public void setChat(Chat chat) {
        this.chat = chat;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public Boolean getIsSender() {
        return isSender;
    }

    public void setIsSender(Boolean isSender) {
        this.isSender = isSender;
    }

}

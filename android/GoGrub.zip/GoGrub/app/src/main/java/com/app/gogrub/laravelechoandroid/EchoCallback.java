/*
 * EchoCallback.java
 * MrBin99 © 2018
 */
package com.app.gogrub.laravelechoandroid;


import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.Ack;

/**
 * Echo callback.
 */
public interface EchoCallback extends Emitter.Listener, Ack {
}

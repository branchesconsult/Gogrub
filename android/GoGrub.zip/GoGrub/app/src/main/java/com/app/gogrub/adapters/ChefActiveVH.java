package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.app.gogrub.R;

public class ChefActiveVH extends RecyclerView.ViewHolder {
    public TextView tvOrderid;
    public TextView tvOrdertime;
    public TextView tvOrderList;
    public TextView tvPricetitle;
    public TextView tvTotalPrice;

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-16 17:41:36 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    public void findViews(View itemView) {
        tvOrderid = (TextView) itemView.findViewById(R.id.tv_orderid);
        tvOrdertime = (TextView) itemView.findViewById(R.id.tv_ordertime);
        tvOrderList = (TextView) itemView.findViewById(R.id.tv_order_list);
        tvPricetitle = (TextView) itemView.findViewById(R.id.tv_pricetitle);
        tvTotalPrice = (TextView) itemView.findViewById(R.id.tv_total_price);
    }


    public ChefActiveVH(View itemView) {
        super(itemView);
        findViews(itemView);
    }
}

package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.app.gogrub.R;


public class ChefImageVH extends RecyclerView.ViewHolder {

    ImageView iv_img;

    public ChefImageVH(View itemView) {
        super(itemView);
        iv_img = itemView.findViewById(R.id.iv_img);
    }
}

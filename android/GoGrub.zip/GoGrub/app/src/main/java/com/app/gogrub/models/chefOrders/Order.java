
package com.app.gogrub.models.chefOrders;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Order {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("customer_id")
    @Expose
    private Integer customerId;
    @SerializedName("chef_id")
    @Expose
    private Integer chefId;
    @SerializedName("invoice_num")
    @Expose
    private String invoiceNum;
    @SerializedName("special_instructions")
    @Expose
    private String specialInstructions;
    @SerializedName("orderstatus_id")
    @Expose
    private Integer orderstatusId;
    @SerializedName("gogrub_commission")
    @Expose
    private Integer gogrubCommission;
    @SerializedName("chef_full_name")
    @Expose
    private String chefFullName;
    @SerializedName("chef_phone")
    @Expose
    private String chefPhone;
    @SerializedName("chef_email")
    @Expose
    private String chefEmail;
    @SerializedName("chef_location")
    @Expose
    private ChefLocation chefLocation;
    @SerializedName("customer_full_name")
    @Expose
    private String customerFullName;
    @SerializedName("customer_phone")
    @Expose
    private String customerPhone;
    @SerializedName("customer_email")
    @Expose
    private String customerEmail;
    @SerializedName("customer_address")
    @Expose
    private String customerAddress;
    @SerializedName("customer_city")
    @Expose
    private Object customerCity;
    @SerializedName("customer_province")
    @Expose
    private Object customerProvince;
    @SerializedName("customer_country")
    @Expose
    private String customerCountry;
    @SerializedName("customer_location")
    @Expose
    private CustomerLocation customerLocation;
    @SerializedName("estimate_delivery_mins")
    @Expose
    private Integer estimateDeliveryMins;
    @SerializedName("coupon_code")
    @Expose
    private Object couponCode;
    @SerializedName("discount")
    @Expose
    private Integer discount;
    @SerializedName("discount_type")
    @Expose
    private Object discountType;
    @SerializedName("delivery_charges")
    @Expose
    private Integer deliveryCharges;
    @SerializedName("subtotal")
    @Expose
    private Integer subtotal;
    @SerializedName("payment_method")
    @Expose
    private String paymentMethod;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("updated_at")
    @Expose
    private String updatedAt;
    @SerializedName("deleted_at")
    @Expose
    private Object deletedAt;
    @SerializedName("total")
    @Expose
    private Integer total;
    @SerializedName("posted_at")
    @Expose
    private String postedAt;
    @SerializedName("avg_rating")
    @Expose
    private Integer avgRating;
    @SerializedName("detail")
    @Expose
    private List<Detail> detail = null;
    @SerializedName("user")
    @Expose
    private User user;
    @SerializedName("rating_review")
    @Expose
    private List<Object> ratingReview = null;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getChefId() {
        return chefId;
    }

    public void setChefId(Integer chefId) {
        this.chefId = chefId;
    }

    public String getInvoiceNum() {
        return invoiceNum;
    }

    public void setInvoiceNum(String invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public Integer getOrderstatusId() {
        return orderstatusId;
    }

    public void setOrderstatusId(Integer orderstatusId) {
        this.orderstatusId = orderstatusId;
    }

    public Integer getGogrubCommission() {
        return gogrubCommission;
    }

    public void setGogrubCommission(Integer gogrubCommission) {
        this.gogrubCommission = gogrubCommission;
    }

    public String getChefFullName() {
        return chefFullName;
    }

    public void setChefFullName(String chefFullName) {
        this.chefFullName = chefFullName;
    }

    public String getChefPhone() {
        return chefPhone;
    }

    public void setChefPhone(String chefPhone) {
        this.chefPhone = chefPhone;
    }

    public String getChefEmail() {
        return chefEmail;
    }

    public void setChefEmail(String chefEmail) {
        this.chefEmail = chefEmail;
    }

    public ChefLocation getChefLocation() {
        return chefLocation;
    }

    public void setChefLocation(ChefLocation chefLocation) {
        this.chefLocation = chefLocation;
    }

    public String getCustomerFullName() {
        return customerFullName;
    }

    public void setCustomerFullName(String customerFullName) {
        this.customerFullName = customerFullName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public Object getCustomerCity() {
        return customerCity;
    }

    public void setCustomerCity(Object customerCity) {
        this.customerCity = customerCity;
    }

    public Object getCustomerProvince() {
        return customerProvince;
    }

    public void setCustomerProvince(Object customerProvince) {
        this.customerProvince = customerProvince;
    }

    public String getCustomerCountry() {
        return customerCountry;
    }

    public void setCustomerCountry(String customerCountry) {
        this.customerCountry = customerCountry;
    }

    public CustomerLocation getCustomerLocation() {
        return customerLocation;
    }

    public void setCustomerLocation(CustomerLocation customerLocation) {
        this.customerLocation = customerLocation;
    }

    public Integer getEstimateDeliveryMins() {
        return estimateDeliveryMins;
    }

    public void setEstimateDeliveryMins(Integer estimateDeliveryMins) {
        this.estimateDeliveryMins = estimateDeliveryMins;
    }

    public Object getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(Object couponCode) {
        this.couponCode = couponCode;
    }

    public Integer getDiscount() {
        return discount;
    }

    public void setDiscount(Integer discount) {
        this.discount = discount;
    }

    public Object getDiscountType() {
        return discountType;
    }

    public void setDiscountType(Object discountType) {
        this.discountType = discountType;
    }

    public Integer getDeliveryCharges() {
        return deliveryCharges;
    }

    public void setDeliveryCharges(Integer deliveryCharges) {
        this.deliveryCharges = deliveryCharges;
    }

    public Integer getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(Integer subtotal) {
        this.subtotal = subtotal;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Object getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Object deletedAt) {
        this.deletedAt = deletedAt;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public String getPostedAt() {
        return postedAt;
    }

    public void setPostedAt(String postedAt) {
        this.postedAt = postedAt;
    }

    public Integer getAvgRating() {
        return avgRating;
    }

    public void setAvgRating(Integer avgRating) {
        this.avgRating = avgRating;
    }

    public List<Detail> getDetail() {
        return detail;
    }

    public void setDetail(List<Detail> detail) {
        this.detail = detail;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Object> getRatingReview() {
        return ratingReview;
    }

    public void setRatingReview(List<Object> ratingReview) {
        this.ratingReview = ratingReview;
    }

}

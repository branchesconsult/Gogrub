package com.app.gogrub.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

import com.app.gogrub.R;
import com.app.gogrub.models.productDetail.ProductDetailResponse;
import com.app.gogrub.utils.Constants;
import com.daimajia.slider.library.Indicators.PagerIndicator;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.DefaultSliderView;

import java.util.ArrayList;


public class FullScreenImage extends AppCompatActivity implements View.OnClickListener {
    private SliderLayout sliderShow;
    private ImageButton ib_cancel;
    private AppCompatActivity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_screen_image);
        context = this;
        initialize();

        getActivityData();
    }

    public void initialize() {

        ib_cancel = findViewById(R.id.ib_cancel);
        ib_cancel.setOnClickListener(this);

        sliderShow = findViewById(R.id.slider);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_cancel:
                finish();
                break;
        }
    }

    private void getActivityData() {

        ProductDetailResponse result = Constants.product;

        ArrayList<String> file_maps = new ArrayList<>();
        if (result.getProduct().getImages().size() > 0) {
            for (int i = 0; i < result.getProduct().getImages().size(); i++) {
                file_maps.add(i,  result.getProduct().getImages().get(i).getImageLarge());
            }
        }

        for (int i = 0; i < file_maps.size(); i++) {
            DefaultSliderView textSliderView = new DefaultSliderView(this);
            //textSliderView.image("http://www.planwallpaper.com/static/images/desktop-year-of-the-tiger-images-wallpaper.jpg");
            textSliderView
                    .image(file_maps.get(i))
                    .error(R.drawable.img_placeholder).empty(R.drawable.img_placeholder)
                    .setScaleType(BaseSliderView.ScaleType.CenterInside);
            sliderShow.addSlider(textSliderView);
        }
        sliderShow.stopAutoCycle();

        sliderShow.setCustomIndicator((PagerIndicator) findViewById(R.id.custom_indicator));

        sliderShow.setCurrentPosition(Integer.parseInt(getIntent().getStringExtra("pos")));


    }
}

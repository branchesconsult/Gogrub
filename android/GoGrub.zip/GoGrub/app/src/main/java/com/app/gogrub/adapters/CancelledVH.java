package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class CancelledVH extends RecyclerView.ViewHolder{


    public CancelledVH(View itemView) {
        super(itemView);
    }
}

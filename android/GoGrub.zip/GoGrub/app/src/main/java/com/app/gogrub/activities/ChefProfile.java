package com.app.gogrub.activities;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.app.gogrub.R;
import com.app.gogrub.adapters.RatingAdapter;
import com.app.gogrub.models.products.RatingReview;
import com.app.gogrub.utils.Constants;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ChefProfile extends AppCompatActivity {

    TextView title, chef_name, description, tv_rating;
    RecyclerView recyclerView;
    ImageView iv_back;
    RatingAdapter adapter;
    private ArrayList<RatingReview> list = new ArrayList<>();
    CircleImageView iv_chef;
    LinearLayout ll_rate_con;
    RatingBar ratingBar, rating;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chef_profile_activity);

        iv_chef = findViewById(R.id.iv_chef);
        title = findViewById(R.id.title);
        chef_name = findViewById(R.id.chef_name);
        description = findViewById(R.id.chef_desc);
        tv_rating = findViewById(R.id.tv_rating);
        iv_back = findViewById(R.id.iv_back);
        rating = findViewById(R.id.rating);
        ll_rate_con = findViewById(R.id.ll_rate_con);
        ratingBar = findViewById(R.id.ratingbar);
        recyclerView = findViewById(R.id.recyclerView);

        title.setText(Constants.CHEF.getFullName().substring(0, 1).toUpperCase() + Constants.CHEF.getFullName().substring(1));
        chef_name.setText(Constants.CHEF.getFullName().substring(0, 1).toUpperCase() + Constants.CHEF.getFullName().substring(1));
//        location.setText(Constants.CHEF.get);
        description.setText(Constants.CHEF.getDescription());

        double d = Constants.CHEF.getAvgRating();
        ratingBar.setRating((float)d);
        rating.setRating((float)d);
        tv_rating.setText(Constants.CHEF.getAvgRating() + "");


        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        Picasso.with(this).load(Constants.CHEF.getAvatar()).placeholder(R.drawable.img_placeholder).into(iv_chef);

        if (Constants.CHEF.getRatingReviews().size() > 0) {
            list.addAll(Constants.CHEF.getRatingReviews());
        } else {
            ll_rate_con.setVisibility(View.GONE);
        }

        adapter = new RatingAdapter(this, list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);

    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}

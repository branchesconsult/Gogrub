package com.app.gogrub.utils;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.app.gogrub.models.chefOrders.Order;
import com.app.gogrub.models.orderProduct.OrderProduct;
import com.app.gogrub.models.productDetail.Chef;
import com.app.gogrub.models.productDetail.ProductDetailResponse;
import com.app.gogrub.models.products.Product;

import java.util.ArrayList;

/**
 * Created by farazqureshi on 16/05/2017.
 */

public class Constants {

    public static final String ACCESS_TOKEN = "access_token";
    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";

    public static final String DEVICE_TYPE = "android";
    public static final String PHONE = "phone";
    public static final String USER_ID = "userid";

    public static int CHEF_ID = 0;


    public static final String DEVICE_TOKEN = "Device_token";
    public static final String CONTENT_TYPE = "application/json";
    public static final String NAME = "name";
    public static final String CHAT_SERVER_URL = "http://139.180.208.52:6001";
    public static final String IMG = "image";
    public static final String EMAIL = "email";
    public static final String PASSWORD = "password";
    public static Product PRODUCT = new Product();
    public static String CHEFNAME = "chef_name";
    public static String CHEF_PHONE = "phone";
    public static Chef CHEF = new Chef();
    public static String TITLE = "title";
    public static String ORDERTIME = "ordertime";
    public static String ADDRESS_ONE = "address";
    public static String LAT = "lat";
    public static String LNG = "lng";
    public static final String CITY = "city";
    public static String SERVER_IP = "http://139.180.208.52:8084/api/v1/";
    public static int productId;
    public static ProductDetailResponse product = new ProductDetailResponse();
    public static ArrayList<OrderProduct> orderProducts = new ArrayList<>();
    public static String ORDERID = "orderid";
    public static ArrayList<String> CNIC_Images = new ArrayList<>();
    public static String isApplied = "applied";
    public static Integer orderId;
    public static final String isChef = "isChef";
    public static Order item = new Order();
    public static String pending = "1";
    public static String inprogress = "2";
    public static String completed = "3";
    public static String cancel = "4";
    public static ArrayList<String> cuisines = new ArrayList<>();
    public static String sortBy = "";
    public static String distance = "";
    public static boolean applyFilter;
    public static String TEMP_ADDRESS = "temp_address";
    public static String TEMP_LAT = "temp_latitude";
    public static String TEMP_LNG = "temp_longitude";
    public static boolean currentLocation = true;
    public static int PLACE_AUTOCOMPLETE_REQUEST_CODE = 123;

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public static boolean checkPermission(final Context context) {
        int currentAPIVersion = Build.VERSION.SDK_INT;
        if (currentAPIVersion >= android.os.Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_EXTERNAL_STORAGE)
                        && ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
                    alertBuilder.setCancelable(true);
                    alertBuilder.setTitle("Permission necessary");
                    alertBuilder.setMessage("External storage permission is necessary");
                    alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions((Activity) context,
                                    new String[]{android.Manifest.permission.CAMERA,
                                            android.Manifest.permission.READ_EXTERNAL_STORAGE}, 10);
                        }
                    });
                    AlertDialog alert = alertBuilder.create();
                    alert.show();

                } else {
                    ActivityCompat.requestPermissions((Activity) context,
                            new String[]{android.Manifest.permission.CAMERA,
                                    android.Manifest.permission.READ_EXTERNAL_STORAGE}, 10);
                }
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}

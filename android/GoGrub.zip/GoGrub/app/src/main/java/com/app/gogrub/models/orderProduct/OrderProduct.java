package com.app.gogrub.models.orderProduct;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OrderProduct {

    @SerializedName("id")
    @Expose
    int id;

    String name;

    @SerializedName("qty")
    @Expose
    String qty;

    @SerializedName("special_instructions")
    @Expose
    String instructions;

    int price;

    public OrderProduct(int id, String name, String qty, String instructions, int price) {
        this.id = id;
        this.name = name;
        this.qty = qty;
        this.instructions = instructions;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}

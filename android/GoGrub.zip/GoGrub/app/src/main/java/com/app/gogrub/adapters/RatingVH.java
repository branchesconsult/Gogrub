package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;

import com.app.gogrub.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class RatingVH extends RecyclerView.ViewHolder {

    public RatingVH(View itemView) {
        super(itemView);
        findViews(itemView);
    }

    public CircleImageView userImg;
    public TextView userName;
    public RatingBar rating;
    public TextView review;

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-18 16:05:40 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    public void findViews(View viewHolder) {
        userImg = (CircleImageView) viewHolder.findViewById(R.id.user_img);
        userName = (TextView) viewHolder.findViewById(R.id.user_name);
        rating = (RatingBar) viewHolder.findViewById(R.id.rating);
        review = (TextView) viewHolder.findViewById(R.id.review);
    }


}

package com.app.gogrub.activities;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.adapters.FoodAdapter;
import com.app.gogrub.fragments.FilterDialog;
import com.app.gogrub.fragments.MessageEvent;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.RefreshUserResponse;
import com.app.gogrub.models.chefOrders.OrdersResponse;
import com.app.gogrub.models.ordersList.OrdersHistoryResponse;
import com.app.gogrub.models.products.Product;
import com.app.gogrub.models.products.ProductResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.AnimationUtility;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.PermissionManager;
import com.app.gogrub.utils.SessionManager;
import com.app.gogrub.utils.SingleShotLocationProvider;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import nl.psdcompany.duonavigationdrawer.views.DuoDrawerLayout;
import nl.psdcompany.duonavigationdrawer.views.DuoMenuView;
import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class DashboardActivity extends AppCompatActivity implements ResponseHandler, SwipeRefreshLayout.OnRefreshListener {

    RecyclerView recyclerView;
    FoodAdapter foodAdapter;
    ImageView iv_menu, iv_cart, iv_filter;


    private TextView tv_order, tv_cart, tv_orderfood;

    ArrayList<Product> list = new ArrayList<>();
    SessionManager sessionManager;
    private ViewHolder mViewHolder;

    TextView notifications, settings, tv_profile;
    SwipeRefreshLayout mSwipeRefreshLayout;

    private LinearLayout llOrderFood;
    private LinearLayout llProfile;
    private RelativeLayout llOhistory;
    private LinearLayout llCart;
    private LinearLayout llMyPost;
    private LinearLayout llPostFood;
    private LinearLayout llNotifications;
    private LinearLayout llInbox;
    private RelativeLayout llMorders;
    private LinearLayout llEarnings;
    private LinearLayout llSettings, ll_chef, order_place_con, timeCon;
    private TextView tvSettings, order_count, chef_count, no_data, txt_title, est_time, tv_edit;
    private Button btnFood;
    private View vv_menu, vv_cart, vv_filter;
    Handler handler;
    boolean isFirstTime = true;
    public boolean isChef = false;
    public boolean isChef1;
    RelativeLayout noti_con;
    ImageView noti_bell, cart_noti;
    private FloatingActionButton fab;
    private AlertDialog alertDialog;
    private String latitude, longitude;
    private PermissionManager permissionsManager;
    private String TAG = "PLACES";

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-14 01:55:49 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    private void findViews() {
        handler = new Handler();
        llOrderFood = (LinearLayout) findViewById(R.id.ll_order_food);
        llProfile = (LinearLayout) findViewById(R.id.ll_profile);
        llOhistory = (RelativeLayout) findViewById(R.id.ll_ohistory);
        llCart = (LinearLayout) findViewById(R.id.ll_cart);
        llMyPost = (LinearLayout) findViewById(R.id.ll_my_post);
        llPostFood = (LinearLayout) findViewById(R.id.ll_post_food);
        llNotifications = (LinearLayout) findViewById(R.id.ll_notifications);
        llInbox = (LinearLayout) findViewById(R.id.ll_inbox);
        order_count = findViewById(R.id.order_count);
        llMorders = (RelativeLayout) findViewById(R.id.ll_morders);
        chef_count = findViewById(R.id.chef_count);
        llEarnings = (LinearLayout) findViewById(R.id.ll_earnings);
        llSettings = (LinearLayout) findViewById(R.id.ll_settings);
        tvSettings = (TextView) findViewById(R.id.tv_settings);
        ll_chef = findViewById(R.id.chef_items);
        timeCon = findViewById(R.id.time_con);
        noti_con = findViewById(R.id.noti_con);
        noti_bell = findViewById(R.id.noti_bell);
        cart_noti = findViewById(R.id.cart_noti);
        est_time = findViewById(R.id.est_time);
        no_data = findViewById(R.id.no_data);
        vv_menu = findViewById(R.id.vv_menu);
        vv_cart = findViewById(R.id.vv_cart);
        vv_filter = findViewById(R.id.vv_filter);
        order_place_con = findViewById(R.id.order_place_con);
        btnFood = (Button) findViewById(R.id.btn_food);

//        if (getIntent().getStringExtra("order") != null) {
//            showTime();
//        } else

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        sessionManager = new SessionManager(DashboardActivity.this);


        permissionsManager = PermissionManager.getInstance(DashboardActivity.this);
        permissionsManager.getPermissionifNotAvailble(new String[]{android.Manifest.permission.ACCESS_NETWORK_STATE
                , Manifest.permission.INTERNET
                , Manifest.permission.ACCESS_FINE_LOCATION
                , Manifest.permission.ACCESS_COARSE_LOCATION}, 111);


        sessionManager.createLoginSession();
        mViewHolder = new ViewHolder();

        recyclerView = findViewById(R.id.recyclerView);
        iv_menu = findViewById(R.id.iv_menu);
        iv_cart = findViewById(R.id.iv_cart);
        iv_filter = findViewById(R.id.iv_filter);
        tv_cart = findViewById(R.id.tv_cart);
        tv_order = findViewById(R.id.tv_order);
        notifications = findViewById(R.id.tv_notifications);
        settings = findViewById(R.id.tv_settings);
        tv_profile = findViewById(R.id.tv_profile);
        txt_title = findViewById(R.id.txt_title);
        tv_orderfood = findViewById(R.id.tv_orderfood);
        tv_edit = findViewById(R.id.tv_edit);

        findViews();

//        findViewById(R.id.icon).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(DashboardActivity.this, ChatActivity.class));
//            }
//        });

        tv_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!tv_edit.getText().toString().equalsIgnoreCase("Done")) {
                    isChef = true;
                    tv_edit.setText("Done");
                    foodAdapter.notifyDataSetChanged();
                } else {
                    isChef = false;
                    tv_edit.setText("Edit");
                    foodAdapter.notifyDataSetChanged();
                }
            }
        });


        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_container);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary,
                android.R.color.holo_green_dark,
                android.R.color.holo_orange_dark,
                android.R.color.holo_blue_dark);


        btnFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (btnFood.getText().toString().equalsIgnoreCase("Become a Chef")) {
                    startActivity(new Intent(DashboardActivity.this, BecomeChef.class));
                } else if (llMyPost.getVisibility() == View.VISIBLE) {
                    llOrderFood.setVisibility(View.VISIBLE);
                    llProfile.setVisibility(View.VISIBLE);
                    llOhistory.setVisibility(View.VISIBLE);
                    llCart.setVisibility(View.VISIBLE);

                    ll_chef.setVisibility(View.GONE);
                    llMyPost.setVisibility(View.GONE);
                    llPostFood.setVisibility(View.GONE);
                    llNotifications.setVisibility(View.GONE);
                    llInbox.setVisibility(View.GONE);
                    llMorders.setVisibility(View.GONE);
                    llEarnings.setVisibility(View.GONE);

                    tv_edit.setVisibility(View.GONE);
                    iv_cart.setVisibility(View.VISIBLE);
                    iv_filter.setVisibility(View.VISIBLE);

                    vv_cart.setVisibility(View.VISIBLE);
                    vv_filter.setVisibility(View.VISIBLE);

                    isChef1 = false;
                    isChef = false;
                    btnFood.setText("View as Chef");

                    mViewHolder.mDuoDrawerLayout.closeDrawer();
                    loadRecyclerViewData();
                    getUserOrders(sessionManager.get(Constants.ACCESS_TOKEN));


                } else {


                    ll_chef.setVisibility(View.VISIBLE);
                    llOrderFood.setVisibility(View.GONE);
                    llProfile.setVisibility(View.GONE);
                    llOhistory.setVisibility(View.GONE);
                    llCart.setVisibility(View.GONE);

                    llMyPost.setVisibility(View.VISIBLE);
                    llPostFood.setVisibility(View.VISIBLE);
                    llNotifications.setVisibility(View.VISIBLE);
                    llInbox.setVisibility(View.VISIBLE);
                    llMorders.setVisibility(View.VISIBLE);
                    llEarnings.setVisibility(View.VISIBLE);

                    isChef1 = true;
                    btnFood.setText("View as Buyer");
                    tv_edit.setVisibility(View.VISIBLE);
                    iv_cart.setVisibility(View.GONE);
                    iv_filter.setVisibility(View.GONE);

                    vv_cart.setVisibility(View.GONE);
                    vv_filter.setVisibility(View.GONE);
                    mViewHolder.mDuoDrawerLayout.closeDrawer();
                    loadRecyclerViewData();

                    getChefOrders(sessionManager.get(Constants.ACCESS_TOKEN));
                }
            }
        });

        /**
         * Showing Swipe Refresh animation on activity create
         * As animation won't start on onCreate, post runnable is used
         */
        mSwipeRefreshLayout.post(new Runnable() {

            @Override
            public void run() {

                mSwipeRefreshLayout.setRefreshing(true);

                // Fetching data from server
                loadRecyclerViewData();
            }
        });


        tv_orderfood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mViewHolder.mDuoDrawerLayout.closeDrawer();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        foodAdapter = new FoodAdapter(this, list);
        recyclerView.setAdapter(foodAdapter);

        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refreshUser();
            }
        });


        vv_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mViewHolder.mDuoDrawerLayout.openDrawer();
            }
        });

        vv_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DashboardActivity.this, CartActivity.class);
                startActivity(i);
            }
        });


        llMyPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mViewHolder.mDuoDrawerLayout.closeDrawer();
                fetchMyFood();
            }
        });

        llPostFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DashboardActivity.this, AddProductActivity.class));
            }
        });

        llInbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DashboardActivity.this, ChatHistory.class));
            }
        });

        llMorders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DashboardActivity.this, ChefOrderHistory.class));
            }
        });


        llEarnings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DashboardActivity.this, ChefEarnings.class));
            }
        });

        vv_filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FragmentManager fragmentManager = getSupportFragmentManager();
                FilterDialog dialog = new FilterDialog();
                dialog.show(fragmentManager, "");


            }
        });


        tv_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DashboardActivity.this, CartActivity.class);
                startActivity(i);
            }
        });

        tv_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DashboardActivity.this, OrderHistory.class);
                startActivity(i);
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DashboardActivity.this, SettingsActivity.class);
                startActivity(i);

            }
        });

        notifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DashboardActivity.this, NotificationsActivity.class);
                startActivity(i);

            }
        });

        tv_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DashboardActivity.this, ProfileActivity.class);
                startActivity(i);

            }
        });

        noti_con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AnimationUtility.rubber(noti_bell);
            }
        });


        getLocation();


    }

    private void fetchMyFood() {
        if (Internet.isAvailable(this)) {
            mSwipeRefreshLayout.setRefreshing(true);
            new RestCaller(DashboardActivity.this, GoGrub.getRestClient().fetchChefFood(), 4);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    public void hideOrderLayout(String msg) {
        txt_title.setText(msg);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                order_place_con.setVisibility(View.VISIBLE);
                AnimationUtility.slideInDown(order_place_con);
            }
        }, 200);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                AnimationUtility.slideOutUp(order_place_con);
                order_place_con.setVisibility(View.INVISIBLE);
                order_place_con.setVisibility(View.GONE);
            }
        }, 5000);


    }

    public void showTime() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                timeCon.setVisibility(View.VISIBLE);
                AnimationUtility.slideInRight(timeCon);
                startTimer(Integer.parseInt(sessionManager.get(Constants.ORDERTIME)) * 60 * 1000);
            }
        }, 150);
    }

    int count, min, hour = 0;
    long sec;
    CountDownTimer timer;

    private void startTimer(final long minute) {

        timer = new CountDownTimer(minute, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long time = minute - millisUntilFinished;
                sec = time / 1000;
                if (sec > 59) {
                    sec = 0;
                    min++;
                    if (min > 59) {
                        min = 0;
                        hour--;
                    }
                }
                if (sec < 10) {
                    if (min < 10) {
                        if (hour < 10) {
                            est_time.setText("0" + hour + ":0" + min + ":0" + sec);
                        } else {
                            est_time.setText("" + hour + ":0" + min + ":0" + sec);
                        }
                    } else {
                        if (hour < 10) {
                            est_time.setText("0" + hour + ":" + min + ":0" + sec);
                        } else {
                            est_time.setText("" + hour + ":" + min + ":0" + sec);
                        }
                    }
                } else {
                    if (min < 10) {
                        if (hour < 10) {
                            est_time.setText("0" + hour + ":0" + min + ":" + sec);
                        } else {
                            est_time.setText("" + hour + ":0" + min + ":" + sec);
                        }
                    } else {
                        if (hour < 10) {
                            est_time.setText("0" + hour + ":" + min + ":" + sec);
                        } else {
                            est_time.setText("" + hour + ":" + min + ":" + sec);
                        }
                    }
                }
            }

            @Override
            public void onFinish() {

            }
        }.start();
    }

    private void refreshUser() {
        if (Internet.isAvailable(this)) {
            Loading.show(this, false, "Please wait...");
            new RestCaller(DashboardActivity.this, GoGrub.getRestClient().refreshUser(sessionManager.get(Constants.ACCESS_TOKEN)), 2);
        } else {
            Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadRecyclerViewData() {
        // Showing refresh animation before making http call
        mSwipeRefreshLayout.setRefreshing(true);
        fab.setVisibility(View.INVISIBLE);
        if (isChef1) {
            getChefProducts();
        } else {
            getProducts();
        }
    }

    private void getChefProducts() {
//        Loading.show(this, false, "Please wait...");
        mSwipeRefreshLayout.setRefreshing(true);

        new RestCaller(this, GoGrub.getRestClient().getChefProducts(sessionManager.get(Constants.ACCESS_TOKEN)), 1);
    }

    private void getProducts() {
//        Loading.show(this, false, "Please wait...");
        new RestCaller(this, GoGrub.getRestClient().getProducts(sessionManager.get(Constants.ACCESS_TOKEN)), 1);
    }

    @Override
    public void onBackPressed() {
        if (mViewHolder.mDuoDrawerLayout.isDrawerOpen()) {
            mViewHolder.mDuoDrawerLayout.closeDrawer();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
//        Loading.cancel();
        if (reqCode == 1) {
            Constants.applyFilter = false;
            mSwipeRefreshLayout.setRefreshing(false);
            ProductResponse productResponse = (ProductResponse) response.body();
            list.clear();
            if (productResponse.getProducts() != null) {
                if (productResponse.getProducts().size() > 0) {
                    list.addAll(productResponse.getProducts());
                    no_data.setVisibility(View.GONE);
                } else {
                    no_data.setVisibility(View.VISIBLE);
                    tv_edit.setVisibility(View.GONE);
                }
            }
            if (isFirstTime) {
                if (Internet.isAvailable(this)) {
                    Loading.show(this, false, "Please wait...");
                    new RestCaller(DashboardActivity.this, GoGrub.getRestClient().refreshUser(sessionManager.get(Constants.ACCESS_TOKEN)), 2);
                } else {
                    Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
                }
            } else {
                runLayoutAnimation(recyclerView);
                AnimationUtility.bounce(iv_menu);
            }
        } else if (reqCode == 2) {
            Loading.cancel();
            RefreshUserResponse loginResponse = (RefreshUserResponse) response.body();
            if (isFirstTime) {
                if (loginResponse.getUser().isChef()) {
                    llOrderFood.setVisibility(View.VISIBLE);
                    llProfile.setVisibility(View.VISIBLE);
                    llOhistory.setVisibility(View.VISIBLE);
                    llCart.setVisibility(View.VISIBLE);

                    ll_chef.setVisibility(View.GONE);

                    llMyPost.setVisibility(View.GONE);
                    llPostFood.setVisibility(View.GONE);
                    llNotifications.setVisibility(View.GONE);
                    llInbox.setVisibility(View.GONE);
                    llMorders.setVisibility(View.GONE);
                    llEarnings.setVisibility(View.GONE);

                    tv_edit.setVisibility(View.GONE);
                    iv_cart.setVisibility(View.VISIBLE);
                    iv_filter.setVisibility(View.VISIBLE);

                    btnFood.setText("View as Chef");

                    if (getIntent().getStringExtra("added") != null) {
                        hideOrderLayout("Product Added Successfully");
                    } else if (getIntent().getStringExtra("edit") != null) {
                        hideOrderLayout("Product Updated Successfully");
                    } else if (getIntent().getStringExtra("order") != null) {
                        hideOrderLayout("Your Order Placed Successfully");
                    }


                    runLayoutAnimation(recyclerView);
                    AnimationUtility.bounce(iv_menu);

                    getUserOrders(sessionManager.get(Constants.ACCESS_TOKEN));

                } else if (!loginResponse.getUser().isChef() && !loginResponse.getUser().isApplied_as_chef()) {
                    llOrderFood.setVisibility(View.VISIBLE);
                    llProfile.setVisibility(View.VISIBLE);
                    llOhistory.setVisibility(View.VISIBLE);
                    llCart.setVisibility(View.VISIBLE);

                    ll_chef.setVisibility(View.VISIBLE);

                    llMyPost.setVisibility(View.GONE);
                    llPostFood.setVisibility(View.GONE);
                    llNotifications.setVisibility(View.GONE);
                    llInbox.setVisibility(View.GONE);
                    llMorders.setVisibility(View.GONE);
                    llEarnings.setVisibility(View.GONE);

                    tv_edit.setVisibility(View.GONE);
                    iv_cart.setVisibility(View.VISIBLE);
                    iv_filter.setVisibility(View.VISIBLE);

                    btnFood.setVisibility(View.VISIBLE);
                    btnFood.setText("Become a Chef");

                    if (getIntent().getStringExtra("added") != null) {
                        hideOrderLayout("Product Added Successfully");
                    } else if (getIntent().getStringExtra("edit") != null) {
                        hideOrderLayout("Product Updated Successfully");
                    } else if (getIntent().getStringExtra("order") != null) {
                        hideOrderLayout("Your Order Placed Successfully");
                    }


                    runLayoutAnimation(recyclerView);
                    AnimationUtility.bounce(iv_menu);

                    getUserOrders(sessionManager.get(Constants.ACCESS_TOKEN));


                } else if (!loginResponse.getUser().isChef() && loginResponse.getUser().isApplied_as_chef()) {
                    llOrderFood.setVisibility(View.VISIBLE);
                    llProfile.setVisibility(View.VISIBLE);
                    llOhistory.setVisibility(View.VISIBLE);
                    llCart.setVisibility(View.VISIBLE);

                    llMyPost.setVisibility(View.GONE);
                    llPostFood.setVisibility(View.GONE);
                    llNotifications.setVisibility(View.GONE);
                    llInbox.setVisibility(View.GONE);
                    llMorders.setVisibility(View.GONE);
                    llEarnings.setVisibility(View.GONE);

                    tv_edit.setVisibility(View.GONE);
                    iv_cart.setVisibility(View.VISIBLE);
                    iv_filter.setVisibility(View.VISIBLE);


                    btnFood.setVisibility(View.VISIBLE);
                    btnFood.setText("Become a Chef");

                    getUserOrders(sessionManager.get(Constants.ACCESS_TOKEN));


                    if (getIntent().getStringExtra("added") != null) {
                        hideOrderLayout("Product Added Successfully");
                    } else if (getIntent().getStringExtra("edit") != null) {
                        hideOrderLayout("Product Updated Successfully");
                    } else if (getIntent().getStringExtra("order") != null) {
                        hideOrderLayout("Your Order Placed Successfully");
                    }


                    runLayoutAnimation(recyclerView);
                    AnimationUtility.bounce(iv_menu);
                    getUserOrders(sessionManager.get(Constants.ACCESS_TOKEN));


                }
                isFirstTime = false;


            } else {
                if (loginResponse.getUser().isChef() && loginResponse.getUser().isApplied_as_chef()) {
                    startActivity(new Intent(DashboardActivity.this, AddProductActivity.class));
                } else if (!loginResponse.getUser().isChef() && loginResponse.getUser().isApplied_as_chef()) {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DashboardActivity.this);
                    alertDialogBuilder.setTitle("Attention");
                    alertDialogBuilder.setMessage("You already applied for chef registration services");
                    alertDialogBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alertDialogBuilder.create();
                    alertDialogBuilder.show();
                } else if (!loginResponse.getUser().isChef() && !loginResponse.getUser().isApplied_as_chef()) {
                    startActivity(new Intent(DashboardActivity.this, BecomeChef.class));
                }
            }
        } else if (reqCode == 4) {
            mSwipeRefreshLayout.setRefreshing(false);

            ProductResponse productResponse = (ProductResponse) response.body();
            list.clear();
            if (productResponse.getProducts() != null) {
                if (productResponse.getProducts().size() > 0) {
                    list.addAll(productResponse.getProducts());
                    foodAdapter.notifyDataSetChanged();
                }
            }


        } else if (reqCode == 3) {
            OrdersHistoryResponse ordersHistoryResponse = (OrdersHistoryResponse) response.body();

            if (ordersHistoryResponse.getOrders().size() > 0) {
                noti_con.setVisibility(View.VISIBLE);
                AnimationUtility.rubber(noti_bell);
                order_count.setVisibility(View.VISIBLE);
                if (ordersHistoryResponse.getOrders().size() > 0) {
                    order_count.setText("10+");
                } else {
                    order_count.setText("" + ordersHistoryResponse.getOrders().size());
                }
            } else {
                noti_con.setVisibility(View.GONE);
                order_count.setVisibility(View.GONE);
            }

        } else if (reqCode == 5) {

            OrdersResponse ordersResponse = (OrdersResponse) response.body();

            if (ordersResponse.getOrders().size() > 0) {
                noti_con.setVisibility(View.VISIBLE);
                AnimationUtility.rubber(noti_bell);
                chef_count.setVisibility(View.VISIBLE);
                if (ordersResponse.getOrders().size() > 0) {
                    chef_count.setText("10+");
                } else {
                    chef_count.setText("" + ordersResponse.getOrders().size());
                }
            } else {
                noti_con.setVisibility(View.GONE);

            }

        }
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
//        Loading.cancel();
        mSwipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
//        Loading.cancel();
        mSwipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
//        Loading.cancel();
        mSwipeRefreshLayout.setRefreshing(false);
    }

    private void getFilterProducts() {

        mSwipeRefreshLayout.setRefreshing(true);
        String cuisine_id = Constants.cuisines.toString().substring(1, Constants.cuisines.toString().length() - 1);
        if (Constants.currentLocation) {
            new RestCaller(this, GoGrub.getRestClient().filter(sessionManager.get(Constants.ACCESS_TOKEN),
                    Constants.sortBy,
                    cuisine_id,
                    Constants.distance,
                    sessionManager.get(Constants.LAT),
                    sessionManager.get(Constants.LNG)
            ), 1);
        } else {
            new RestCaller(this, GoGrub.getRestClient().filter(sessionManager.get(Constants.ACCESS_TOKEN),
                    Constants.sortBy,
                    cuisine_id,
                    Constants.distance,
                    sessionManager.get(Constants.TEMP_LAT),
                    sessionManager.get(Constants.TEMP_LNG)
            ), 1);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MessageEvent event) {
        if (event.getMessage().equalsIgnoreCase("filter")) {
            if (Constants.applyFilter) {
                getFilterProducts();
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.orderProducts.size() > 0) {
            cart_noti.setVisibility(View.VISIBLE);
        } else {
            cart_noti.setVisibility(View.GONE);
        }
    }

    @Override
    public void onRefresh() {
        loadRecyclerViewData();
    }

    private class ViewHolder {
        private DuoDrawerLayout mDuoDrawerLayout;
        private DuoMenuView mDuoMenuView;

        ViewHolder() {
            mDuoDrawerLayout = findViewById(R.id.drawer_1);
            mDuoMenuView = (DuoMenuView) mDuoDrawerLayout.getMenuView();
        }
    }

    private void fabAnimation() {
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                fab.setVisibility(View.VISIBLE);
//                tv_title.setVisibility(View.VISIBLE);
                AnimationUtility.slideInRight(fab);
            }
        }, 500);
    }

    private void runLayoutAnimation(final RecyclerView recyclerView) {

        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                final Context context = recyclerView.getContext();
                final LayoutAnimationController controller =
                        AnimationUtils.loadLayoutAnimation(context, R.anim.layout_animation_from_bottom);

                recyclerView.setLayoutAnimation(controller);
//        recyclerView.getAdapter().notifyDataSetChanged();
                recyclerView.scheduleLayoutAnimation();

                fabAnimation();

            }
        }, 100);


    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(DashboardActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(DashboardActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            permissionsManager.getPermissionifNotAvailble(new String[]{android.Manifest.permission.ACCESS_NETWORK_STATE
                    , Manifest.permission.INTERNET
                    , Manifest.permission.ACCESS_FINE_LOCATION
                    , Manifest.permission.ACCESS_COARSE_LOCATION}, 111);
            return;
        } else {
            LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
            boolean enabled = service
                    .isProviderEnabled(LocationManager.GPS_PROVIDER);

            if (!enabled) {
                alertDialog = new AlertDialog.Builder(
                        DashboardActivity.this).create();
                alertDialog.setTitle("Attention");
                alertDialog.setMessage("Please enable GPS from settings");
                alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        alertDialog.dismiss();
                        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(intent);
                    }
                });

                alertDialog.show();
            } else {
                sendLocation();
            }
        }

    }

    private void sendLocation() {
        SingleShotLocationProvider.requestSingleUpdate(DashboardActivity.this,
                new SingleShotLocationProvider.LocationCallback() {
                    @Override
                    public void onNewLocationAvailable(SingleShotLocationProvider.GPSCoordinates location) {
                        Log.d("Location", "my location is " + location.toString() + location);
                        if (location != null) {

                            Log.d("Location", location.latitude + " \n" + location.longitude);

                            latitude = location.latitude + "";
                            longitude = location.longitude + "";

                            sessionManager.put(Constants.LAT, latitude);
                            sessionManager.put(Constants.LNG, longitude);

                            Geocoder geocoder;

                            geocoder = new Geocoder(DashboardActivity.this, Locale.getDefault());

                            try {
                                List<Address> addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1);
                                sessionManager.put(Constants.ADDRESS_ONE, addresses.get(0).getAddressLine(0));
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                        }
                    }
                });
    }

    private void getUserOrders(String token) {
        new RestCaller(DashboardActivity.this, GoGrub.getRestClient().getOrders(token), 3);
    }

    private void getChefOrders(String token) {
        new RestCaller(DashboardActivity.this, GoGrub.getRestClient().getActiveOrders(token), 5);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //  Toast.makeText(ParentActivity.this, "Request Code => "+requestCode, Toast.LENGTH_SHORT).show();
        switch (requestCode) {
            case 111:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    getLocation();
                } else {
                    Toast.makeText(this, "Please allow the location permission. Thanks", Toast.LENGTH_SHORT).show();
                    getLocation();
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constants.PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Place place = PlaceAutocomplete.getPlace(this, data);
                Log.e(TAG, "Place: " + place.getName() + "\n" + place.getLatLng().latitude + ", " + place.getLatLng().longitude);
                sessionManager.put(Constants.TEMP_ADDRESS, place.getAddress() + "");
                sessionManager.put(Constants.TEMP_LAT, place.getLatLng().latitude + "");
                sessionManager.put(Constants.TEMP_LNG, place.getLatLng().longitude + "");
                Constants.currentLocation = false;
            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(this, data);
                // TODO: Handle the error.
                Log.e(TAG, status.getStatusMessage());
                Constants.currentLocation = true;

            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
                Constants.currentLocation = true;
            }
        }
    }


}

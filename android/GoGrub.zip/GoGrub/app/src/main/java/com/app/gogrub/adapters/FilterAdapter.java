package com.app.gogrub.adapters;

import android.app.Activity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.models.FilterModel;

import java.util.ArrayList;

/**
 * Created by farazqureshi on 31/07/2018.
 */

public class FilterAdapter extends RecyclerView.Adapter<FilterVH> {

    Activity activity;
    ArrayList<FilterModel> list;

    public FilterAdapter(Activity activity, ArrayList<FilterModel> list) {
        this.activity = activity;
        this.list = list;
    }

    @Override
    public FilterVH onCreateViewHolder(ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_filter, parent, false);
        return new FilterVH(v);
    }

    @Override
    public void onBindViewHolder(FilterVH holder, int i) {
        FilterModel item = list.get(i);

        holder.item_title.setText(item.getTitle());

        if (item.getItems().size() > 0) {
            if (item.getTitle().equalsIgnoreCase("Sort By")) {
                RecyclerAdapter adapter = new RecyclerAdapter(activity, item.getItems(), true);
                holder.itemsRecylcer.setLayoutManager(new LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false));
                holder.itemsRecylcer.setAdapter(adapter);
            } else {
                RecyclerAdapter adapter = new RecyclerAdapter(activity, item.getItems(), false);
                holder.itemsRecylcer.setLayoutManager(new LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false));
                holder.itemsRecylcer.setAdapter(adapter);
            }
        }


    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

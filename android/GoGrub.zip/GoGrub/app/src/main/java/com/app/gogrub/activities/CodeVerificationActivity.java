package com.app.gogrub.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.verify.VerifyResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.Constants;
import com.app.gogrub.utils.Loading;
import com.app.gogrub.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;


public class CodeVerificationActivity extends AppCompatActivity implements ResponseHandler {

    EditText etOne;
    EditText etTwo;
    EditText etThree;
    EditText etFour;
    TextView tvTime;
    TextView tvResendCode;
    EditText tv_phone;
    ImageView iv_edit;

    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_verification);

        sessionManager = new SessionManager(this);

        etOne = findViewById(R.id.etOne);
        etTwo = findViewById(R.id.etTwo);
        etThree = findViewById(R.id.etThree);
        etFour = findViewById(R.id.etFour);
        tvTime = findViewById(R.id.tvTime);
        iv_edit = findViewById(R.id.iv_edit);
        tv_phone = findViewById(R.id.tv_phone);
        tvResendCode = findViewById(R.id.tvResendCode);

        etListeners();
        iv_edit.setVisibility(View.GONE);
        tv_phone.setText("0" + sessionManager.get(Constants.PHONE));
        startTimer();

        iv_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!tv_phone.isEnabled()) {
                    tv_phone.setEnabled(true);
                    tv_phone.requestFocus();
                }
            }
        });

        Toast.makeText(this, "Code is: 1234", Toast.LENGTH_SHORT).show();

        tvResendCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timer.cancel();
                tvTime.setText("0");
                etFour.getText().clear();
                etThree.getText().clear();
                etTwo.getText().clear();
                etOne.getText().clear();
                tvResendCode.setVisibility(View.GONE);
                iv_edit.setVisibility(View.GONE);
                startTimer();

                resendCode();
            }
        });

        tv_phone.setOnEditorActionListener(
                new EditText.OnEditorActionListener() {
                    @Override
                    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                        // Identifier of the action. This will be either the identifier you supplied,
                        // or EditorInfo.IME_NULL if being called due to the enter key being pressed.
                        if (actionId == EditorInfo.IME_ACTION_SEARCH
                                || actionId == EditorInfo.IME_ACTION_DONE
                                || event.getAction() == KeyEvent.ACTION_DOWN
                                && event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                            updatePhone();
                            return true;
                        }
                        // Return true if you have consumed the action, else false.
                        return false;
                    }
                });


    }

    private void resendCode() {
        Loading.show(this, false, "Please wait...");
        new RestCaller(this, GoGrub.getRestClient().resendCode(sessionManager.get(Constants.ACCESS_TOKEN),
                Constants.CONTENT_TYPE,
                sessionManager.get(Constants.PHONE)), 2);
//        Toast.makeText(this, "Code is: 1234", Toast.LENGTH_SHORT).show();

    }

    private void updatePhone() {
        sessionManager.put(Constants.PHONE, tv_phone.getText().toString().substring(1));
        Loading.show(this, false, "Please wait...");
        new RestCaller(this, GoGrub.getRestClient().updatePhone(sessionManager.get(Constants.ACCESS_TOKEN),
                sessionManager.get(Constants.PHONE).substring(1)), 1);
//        Toast.makeText(this, "Code is: 1234", Toast.LENGTH_SHORT).show();

    }


    int count = 0;
    CountDownTimer timer;

    private void startTimer() {
        timer = new CountDownTimer(60000, 1000) {

            public void onTick(long millisUntilFinished) {
                tvTime.setText((millisUntilFinished / 1000) + "");
            }

            public void onFinish() {
                tvTime.setText("0");
                count++;
                tvResendCode.setVisibility(View.VISIBLE);
                iv_edit.setVisibility(View.VISIBLE);

            }
        }.start();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        timer.cancel();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        timer.cancel();
    }

    private void etListeners() {
        etOne.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    etTwo.requestFocus();
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
        etTwo.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    etThree.requestFocus();
                } else if (s.length() == 0) {
                    etOne.requestFocus();

                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
        etThree.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    etFour.requestFocus();
                } else if (s.length() == 0) {
                    etTwo.requestFocus();
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
        etFour.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                if (s.length() == 0) {
                    etThree.requestFocus();
                } else {

                    String pin = etOne.getText().toString().trim() +
                            etTwo.getText().toString().trim() +
                            etThree.getText().toString().trim() +
                            etFour.getText().toString().trim();
                    verifyCode(pin);

                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
        etFour.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                //You can identify which key pressed buy checking keyCode value with KeyEvent.KEYCODE_

                if (keyCode == KeyEvent.KEYCODE_DEL && etFour.getText().length() == 0) {
                    etThree.requestFocus();
                }
                return false;
            }
        });
        etThree.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                //You can identify which key pressed buy checking keyCode value with KeyEvent.KEYCODE_
                if (keyCode == KeyEvent.KEYCODE_DEL && etThree.getText().length() == 0) {
                    etTwo.requestFocus();
                }
                return false;
            }
        });
        etTwo.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                //You can identify which key pressed buy checking keyCode value with KeyEvent.KEYCODE_
                if (keyCode == KeyEvent.KEYCODE_DEL && etTwo.getText().length() == 0) {
                    etOne.requestFocus();
                }
                return false;
            }
        });

    }

    private void verifyCode(String pin) {
        Loading.show(this, false, "Please wait...");
        new RestCaller(this, GoGrub.getRestClient().verifyCode(sessionManager.get(Constants.ACCESS_TOKEN), Constants.CONTENT_TYPE, pin), 1);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        if (reqCode == 1) {
            VerifyResponse verifyResponse = (VerifyResponse) response.body();
            if (verifyResponse.getSuccess()) {
                startActivity(new Intent(CodeVerificationActivity.this, DashboardActivity.class));
                finish();
            }

        } else {
            VerifyResponse verifyResponse = (VerifyResponse) response.body();
            if (verifyResponse.getSuccess()) {
//                startActivity(new Intent(CodeVerificationActivity.this, DashboardActivity.class));
//                finish();
                Toast.makeText(this, verifyResponse.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();

    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();
        Toast.makeText(this, error.getError().getMessage(), Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }
}

package com.app.gogrub.adapters;

import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.activities.OrderDetail;
import com.app.gogrub.activities.OrderHistory;
import com.app.gogrub.fragments.RatingDialog;
import com.app.gogrub.models.ordersList.Order;
import com.app.gogrub.utils.Constants;

import java.util.ArrayList;

/**
 * Created by devicebee on 01/08/2018.
 */

public class OrderAdapter extends RecyclerView.Adapter<OrderVH> {

    Activity activity;
    ArrayList<Order> list;

    public OrderAdapter(Activity activity, ArrayList<Order> list) {
        this.activity = activity;
        this.list = list;
    }

    @Override
    public OrderVH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_view, parent, false);
        return new OrderVH(v);
    }

    @Override
    public void onBindViewHolder(OrderVH holder, int position) {
        final Order order = list.get(position);
        holder.orderId.setText("ID: " + order.getInvoiceNum());
        if (list.get(position).getDetail().size() > 0) {
            ArrayList<String> listProducts = new ArrayList<>();
            for (int i = 0; i < list.get(position).getDetail().size(); i++) {
                if (list.get(position).getDetail().get(i).getProduct() != null)
                    listProducts.add(list.get(position).getDetail().get(i).getProduct().getName());
            }
            holder.orderItem.setText(listProducts.toString().substring(1, listProducts.toString().length() - 1));
        }

        if (!order.isHas_rated()) {
            holder.btn_rate.setVisibility(View.GONE);
        }

        if (order.getStatus().getId() == 3) {
            if (!order.isHas_rated()) {
                holder.btn_rate.setVisibility(View.VISIBLE);
            } else {
                holder.btn_rate.setVisibility(View.GONE);
            }
        } else {
            holder.btn_rate.setVisibility(View.GONE);
        }

        holder.orderPrice.setText("Rs " + order.getTotal());
        holder.orderTime.setText(order.getCreatedAt());

        holder.btn_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = ((OrderHistory) activity).getSupportFragmentManager();
                Constants.orderId = order.getId();
                Constants.CHEFNAME = order.getChef().getFullName();
                RatingDialog dialog = new RatingDialog();
                dialog.show(fragmentManager, "");

            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(activity, OrderDetail.class);
                i.putExtra("o_id", order.getId() + "");
                activity.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

package com.app.gogrub.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.app.gogrub.R;

public class ChefItemVH extends RecyclerView.ViewHolder {
    public TextView itemName;
    public TextView itemQty;
    public TextView itemPrice;

    public ChefItemVH(View itemView) {
        super(itemView);
        findViews(itemView);
    }

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-17 20:24:02 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    public void findViews(View itemView) {
        itemName = (TextView) itemView.findViewById(R.id.item_name);
        itemQty = (TextView) itemView.findViewById(R.id.item_qty);
        itemPrice = (TextView) itemView.findViewById(R.id.item_price);
    }


}

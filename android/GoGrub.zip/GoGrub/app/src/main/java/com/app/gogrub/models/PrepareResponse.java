package com.app.gogrub.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PrepareResponse {

    @SerializedName("prepration_time")
    @Expose
    private Integer preprationTime;
    @SerializedName("delievery_charges")
    @Expose
    private Integer delieveryCharges;
    @SerializedName("delivery_slots")
    @Expose
    private List<Integer> deliverySlots = null;

    public Integer getPreprationTime() {
        return preprationTime;
    }

    public void setPreprationTime(Integer preprationTime) {
        this.preprationTime = preprationTime;
    }

    public Integer getDelieveryCharges() {
        return delieveryCharges;
    }

    public void setDelieveryCharges(Integer delieveryCharges) {
        this.delieveryCharges = delieveryCharges;
    }

    public List<Integer> getDeliverySlots() {
        return deliverySlots;
    }

    public void setDeliverySlots(List<Integer> deliverySlots) {
        this.deliverySlots = deliverySlots;
    }
}

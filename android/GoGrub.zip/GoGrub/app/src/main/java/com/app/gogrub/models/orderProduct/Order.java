package com.app.gogrub.models.orderProduct;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Order {

    @SerializedName("customer_phone")
    @Expose
    String customer_phone;
    @SerializedName("customer_address")
    @Expose
    String customer_address;
    @SerializedName("estimate_delivery_mins")
    @Expose
    String estimate_delivery_mins;
    @SerializedName("customer_lat")
    @Expose
    String customer_lat;
    @SerializedName("customer_lng")
    @Expose
    String customer_lng;
    @SerializedName("payment_method")
    @Expose
    String payment_method;
    @SerializedName("products")
    @Expose
    ArrayList<OrderProduct> list;

    public String getCustomer_phone() {
        return customer_phone;
    }

    public void setCustomer_phone(String customer_phone) {
        this.customer_phone = customer_phone;
    }

    public String getCustomer_address() {
        return customer_address;
    }

    public void setCustomer_address(String customer_address) {
        this.customer_address = customer_address;
    }

    public String getEstimate_delivery_mins() {
        return estimate_delivery_mins;
    }

    public void setEstimate_delivery_mins(String estimate_delivery_mins) {
        this.estimate_delivery_mins = estimate_delivery_mins;
    }

    public String getCustomer_lat() {
        return customer_lat;
    }

    public void setCustomer_lat(String customer_lat) {
        this.customer_lat = customer_lat;
    }

    public String getCustomer_lng() {
        return customer_lng;
    }

    public void setCustomer_lng(String customer_lng) {
        this.customer_lng = customer_lng;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public ArrayList<OrderProduct> getList() {
        return list;
    }

    public void setList(ArrayList<OrderProduct> list) {
        this.list = list;
    }
}

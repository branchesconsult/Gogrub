package com.app.gogrub.adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.gogrub.R;
import com.app.gogrub.models.orderDetails.Detail;

import java.util.ArrayList;

/**
 * Created by farazqureshi on 01/08/2018.
 */

public class OrderDetailAdapter extends RecyclerView.Adapter<DetailOrderVH> {

    Activity activity;
    ArrayList<Detail> list;

    public OrderDetailAdapter(Activity activity, ArrayList<Detail> list) {
        this.activity = activity;
        this.list = list;
    }

    @Override
    public DetailOrderVH onCreateViewHolder(ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_detail_item, parent, false);
        return new DetailOrderVH(v);
    }

    @Override
    public void onBindViewHolder(DetailOrderVH holder, int i) {
        Detail item = list.get(i);

        holder.productName.setText(item.getProduct().getName());
        holder.tv_price.setText("Rs " + item.getTotalPrice());
        holder.tv_qty.setText(item.getQty() + "");


    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

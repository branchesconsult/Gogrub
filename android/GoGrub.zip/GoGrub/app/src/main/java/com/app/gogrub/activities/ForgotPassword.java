package com.app.gogrub.activities;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.app.gogrub.GoGrub;
import com.app.gogrub.R;
import com.app.gogrub.models.ERRORSO;
import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.restapis.ResponseHandler;
import com.app.gogrub.restapis.RestCaller;
import com.app.gogrub.utils.CustomDialoge;
import com.app.gogrub.utils.Internet;
import com.app.gogrub.utils.Loading;

import retrofit2.Call;
import retrofit2.Response;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ForgotPassword extends AppCompatActivity implements ResponseHandler {

    private ImageView ivBack;
    private EditText email;
    private Button btnCreate;
    private LinearLayout signIn;
    private LinearLayout socialTv;

    /**
     * Find the Views in the layout<br />
     * <br />
     * Auto-created on 2018-10-18 18:32:52 by Android Layout Finder
     * (http://www.buzzingandroid.com/tools/android-layout-finder)
     */
    private void findViews() {
        ivBack = (ImageView) findViewById(R.id.iv_back);
        email = (EditText) findViewById(R.id.email);
        btnCreate = (Button) findViewById(R.id.btn_getPass);
        signIn = (LinearLayout) findViewById(R.id.sign_in);
        socialTv = (LinearLayout) findViewById(R.id.social_tv);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgot_pass);

        findViews();

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (email.getText().toString().length() > 0) {
                    if (email.getText().toString().contains("@") || email.getText().toString().contains(".")) {
                        if (Internet.isAvailable(ForgotPassword.this)) {
                            Loading.show(ForgotPassword.this, false, "Please wait...");
                            new RestCaller(ForgotPassword.this, GoGrub.getRestClient().forgotPass(email.getText().toString()), 1);
                        } else {
                            Toast.makeText(ForgotPassword.this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        email.setText("Please enter a valid email");
                        email.performClick();
                    }
                } else {
                    email.setText("Please enter email");
                    email.performClick();
                }
            }
        });
    }

    @Override
    public void onSuccess(Call call, Response response, int reqCode) {
        Loading.cancel();
        GenericResponse genericResponse = (GenericResponse) response.body();
        CustomDialoge.show(ForgotPassword.this, genericResponse.getMessage_title(), genericResponse.getMsg());
    }

    @Override
    public void onFailure(Call call, GenericResponse error, int reqCode) {
        Loading.cancel();
        Toast.makeText(this, error.getMsg(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onErrors(Call call, ERRORSO error, int reqCode) {
        Loading.cancel();
        Toast.makeText(this, error.getError().getMessage(), Toast.LENGTH_SHORT).show();


    }

    @Override
    public void onApiCrash(Call call, Throwable t, int reqCode) {
        Loading.cancel();

    }


    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

}

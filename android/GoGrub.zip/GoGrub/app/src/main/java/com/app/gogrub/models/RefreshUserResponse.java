package com.app.gogrub.models;

import com.app.gogrub.models.register.User;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RefreshUserResponse {
    @SerializedName("user")
    @Expose
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}

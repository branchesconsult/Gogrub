package com.app.gogrub.restapis;

import com.app.gogrub.models.GenericResponse;
import com.app.gogrub.models.PrepareResponse;
import com.app.gogrub.models.RefreshUserResponse;
import com.app.gogrub.models.addProduct.AddProductResponse;
import com.app.gogrub.models.chat.AllChatResponse;
import com.app.gogrub.models.chatMessages.ChatHistoryResponse;
import com.app.gogrub.models.chefOrderDetail.COrderResponse;
import com.app.gogrub.models.chefOrders.OrdersResponse;
import com.app.gogrub.models.cuisines.CuisinesResponse;
import com.app.gogrub.models.earnings.EarningsResponse;
import com.app.gogrub.models.login.LoginResponse;
import com.app.gogrub.models.loginFB.NewLoginResponse;
import com.app.gogrub.models.msgResponse.SendMsgResponse;
import com.app.gogrub.models.orderDetails.OrderDetailResponse;
import com.app.gogrub.models.orderPlacement.OrderResponse;
import com.app.gogrub.models.orderProduct.Order;
import com.app.gogrub.models.ordersList.OrdersHistoryResponse;
import com.app.gogrub.models.page.PageResponse;
import com.app.gogrub.models.productDetail.ProductDetailResponse;
import com.app.gogrub.models.products.ProductResponse;
import com.app.gogrub.models.register.RegisterResponse;
import com.app.gogrub.models.verify.VerifyResponse;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by zeeshan on 6/2/17.
 */

public interface RestApis {

    @FormUrlEncoded
    @POST("login")
    Call<LoginResponse> login(@Field("mobile") String mobile,
                              @Field("password") String password,
                              @Field("device_type") String device_type,
                              @Field("fcm_token") String fcm_token,
                              @Field("device_id") String device_id);


    @FormUrlEncoded
    @POST("register")
    Call<RegisterResponse> signup(@Field("full_name") String full_name,
                                  @Field("email") String email,
                                  @Field("mobile") String mobile,
                                  @Field("password") String password,
                                  @Field("password_confirmation") String password_confirmation,
                                  @Field("device_type") String device_type,
                                  @Field("fcm_token") String fcm_token,
                                  @Field("device_id") String device_id);


    @GET("phone-verify")
    Call<VerifyResponse> verifyCode(@Header("Authorization") String auth,
                                    @Header("Content-Type") String content_type,
                                    @Query("confirmation_code") String pin);

    @FormUrlEncoded
    @POST("resend-verification-code")
    Call<VerifyResponse> resendCode(@Header("Authorization") String auth,
                                    @Header("Content-Type") String content_type,
                                    @Field("mobile") String phone);

    @FormUrlEncoded
    @POST("phone-update")
    Call<VerifyResponse> updatePhone(@Header("Authorization") String auth,
                                     @Field("mobile") String mobile);

    @GET("products")
    Call<ProductResponse> getProducts(@Header("Authorization") String auth);


    @GET("products")
    Call<ProductResponse> filter(@Header("Authorization") String auth,
                                 @Query("sortBy") String sortBy,
                                 @Query("cuisineId") String cuisineId,
                                 @Query("distance") String distance,
                                 @Query("lat") String lat,
                                 @Query("lng") String lng);


    @GET("products")
    Call<ProductResponse> getOtherMealsByChef(@Header("Authorization") String auth, @Query("chef_id") String chef_id);


    @GET("chef/products")
    Call<ProductResponse> getChefProducts(@Header("Authorization") String auth);


    @Multipart
    @POST("products")
    Call<AddProductResponse> addProduct(@Header("Authorization") String auth,
                                        @Part("name") String name,
                                        @Part("cuisine_id") String cuisine_id,
                                        @Part("price") String price,
                                        @Part("availability_from") String availability_form,
                                        @Part("serving_size") String serving_size,
                                        @Part("total_servings") String total_servings,
                                        @Part("description") String description,
                                        @Part("preparation_time") String preparation_time,
                                        @Part("availability_to") String availability_to,
                                        @Part MultipartBody.Part[] files);

    @Multipart
    @POST("chef/products/{id}")
    Call<AddProductResponse> editProduct(@Header("Authorization") String auth,
                                         @Path("id") String product_id,
                                         @Part("name") String name,
                                         @Part("cuisine_id") String cuisine_id,
                                         @Part("price") String price,
                                         @Part("availability_from") String availability_form,
                                         @Part("serving_size") String serving_size,
                                         @Part("total_servings") String total_servings,
                                         @Part("description") String description,
                                         @Part("preparation_time") String preparation_time,
                                         @Part("availability_to") String availability_to,
                                         @Part MultipartBody.Part[] files);

    @FormUrlEncoded
    @POST("chef/products/{id}")
    Call<AddProductResponse> editProduct(@Header("Authorization") String auth,
                                         @Path("id") String product_id,
                                         @Field("name") String name,
                                         @Field("cuisine_id") String cuisine_id,
                                         @Field("price") String price,
                                         @Field("availability_from") String availability_form,
                                         @Field("serving_size") String serving_size,
                                         @Field("total_servings") String total_servings,
                                         @Field("description") String description,
                                         @Field("preparation_time") String preparation_time,
                                         @Field("availability_to") String availability_to);

    @GET("cuisine")
    Call<CuisinesResponse> getCuisine();

    @GET("products/{id}")
    Call<ProductDetailResponse> getProductDetail(@Header("Authorization") String auth, @Path("id") int productId);


    @GET("order/{id}")
    Call<OrderDetailResponse> getOrderDetails(@Header("Authorization") String auth, @Path("id") int productId);


    @GET("chef/orders/{id}")
    Call<COrderResponse> getChefOrderDetails(@Header("Authorization") String auth, @Path("id") int productId);

    @POST("order")
    Call<OrderResponse> placeOrder(@Header("Authorization") String token,
                                   @Body Order order);

    @GET("order")
    Call<OrdersHistoryResponse> getOrders(@Header("Authorization") String auth);


    @GET("pages/terms-and-conditions")
    Call<PageResponse> getTerms();


    @GET("pages/privacy-policy")
    Call<PageResponse> getPrivacy();


    @GET("pages/about")
    Call<PageResponse> getAbout();


    @GET("refresh-user")
    Call<RefreshUserResponse> refreshUser(@Header("Authorization") String token);


    @Multipart
    @POST("chef/apply")
    Call<GenericResponse> registerChef(@Header("Authorization") String auth,
                                       @Part MultipartBody.Part[] cnic,
                                       @Part MultipartBody.Part[] kitchen);

    @FormUrlEncoded
    @POST("logout")
    Call<GenericResponse> logout(@Header("Authorization") String auth,
                                 @Field("device_id") String phone);


    @FormUrlEncoded
    @POST("order/rate")
    Call<GenericResponse> rateOrder(@Header("Authorization") String auth,
                                    @Field("order_id") int order_id,
                                    @Field("rating") String rating,
                                    @Field("review") String review);


    @Multipart
    @POST("user/update")
    Call<RefreshUserResponse> updateUserImage(@Header("Authorization") String auth,
                                              @Part("full_name") String name,
                                              @Part("email") String email,
                                              @Part MultipartBody.Part dp);

    @FormUrlEncoded
    @POST("user/update")
    Call<RefreshUserResponse> updateUser(@Header("Authorization") String auth,
                                         @Field("full_name") String name,
                                         @Field("email") String email,
                                         @Field("old_password") String old_password,
                                         @Field("password") String password,
                                         @Field("password_confirmation") String password_confirmation);

    @GET("products")
    Call<ProductResponse> fetchChefFood();

    @GET("chef/earnings")
    Call<EarningsResponse> fecthEarnings(@Header("Authorization") String auth);

    @GET("chef/orders?orderstatus_id=4")
    Call<OrdersResponse> getCancelledOrders(@Header("Authorization") String auth);

    @GET("chef/orders?orderstatus_id=1")
    Call<OrdersResponse> getActiveOrders(@Header("Authorization") String auth);

    @GET("chef/orders?orderstatus_id=3")
    Call<OrdersResponse> getCompletedOrders(@Header("Authorization") String auth);


    @DELETE("chef/products/{id}")
    Call<GenericResponse> deleteProduct(@Header("Authorization") String auth, @Path("id") int productId);

    @FormUrlEncoded
    @POST("chef/orders/{id}")
    Call<GenericResponse> changeOrderStauts(@Header("Authorization") String auth, @Path("id") int order_id, @Field("orderstatus_id") String order_status);

    @FormUrlEncoded
    @POST("password/email")
    Call<GenericResponse> forgotPass(@Field("email") String email);


    @FormUrlEncoded
    @POST("order/get-process-time")
    Call<PrepareResponse> getPreprationTime(@Header("Authorization") String auth,
                                            @Field("product_id") String product_id);

    @FormUrlEncoded
    @POST("social-login")
    Call<NewLoginResponse> newFbLogin(@Field("email") String email, @Field("fb_id") String fb_id, @Field("full_name") String name, @Field("profile_pic") String pic, @Field("device_token") String token);


    @FormUrlEncoded
    @POST("chat")
    Call<SendMsgResponse> sendMsg(@Header("Authorization") String auth,
                                  @Field("order_id") int o_id,
                                  @Field("receiver_id") String rec_id,
                                  @Field("message") String msg);

    @GET("chat/order")
    Call<AllChatResponse> getChat(@Header("Authorization") String auth,
                                  @Query("order_id") String o_id);


    @GET("chat")
    Call<ChatHistoryResponse> getChats(@Header("Authorization") String auth);


    @DELETE("chef/images/{id}")
    Call<GenericResponse> deleteImage(@Header("Authorization") String auth,
                                      @Path("id") int img_id);
}
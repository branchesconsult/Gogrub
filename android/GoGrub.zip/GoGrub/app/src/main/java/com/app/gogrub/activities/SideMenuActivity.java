package com.app.gogrub.activities;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.gogrub.R;
import com.app.gogrub.adapters.FilterAdapter;
import com.app.gogrub.adapters.FoodAdapter;
import com.app.gogrub.models.FilterModel;
import com.app.gogrub.models.RecyclerModel;
import com.app.gogrub.models.products.Product;

import java.util.ArrayList;

import nl.psdcompany.duonavigationdrawer.views.DuoDrawerLayout;
import nl.psdcompany.duonavigationdrawer.views.DuoMenuView;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

/**
 * Created by farazqureshi on 24/09/2018.
 */

public class SideMenuActivity extends AppCompatActivity {

    RecyclerView recyclerView, dialogRecycler;
    FoodAdapter foodAdapter;
    ImageView iv_menu, iv_cart, iv_filter, iv_cancel;
    ArrayList<FilterModel> filterModels = new ArrayList<>();
    FilterAdapter filterAdapter;
    ArrayList<Product> list = new ArrayList<>();
    private ViewHolder mViewHolder;
    private TextView tv_clear, tv_ok, tv_order, tv_cart, tv_orderfood;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sidemenu_layout);
        mViewHolder = new ViewHolder();
        iv_menu = findViewById(R.id.iv_menu);

        recyclerView = findViewById(R.id.recyclerView);
        iv_menu = findViewById(R.id.iv_menu);
        iv_cart = findViewById(R.id.iv_cart);
        iv_filter = findViewById(R.id.iv_filter);
        tv_cart = findViewById(R.id.tv_cart);
        tv_order = findViewById(R.id.tv_order);
        tv_orderfood = findViewById(R.id.tv_orderfood);

//        list.add(new FoodModel("Mince Biryani", R.drawable.img_1));
//        list.add(new FoodModel("Beef Cheese Burger", R.drawable.img_2));
//        list.add(new FoodModel("Strawberry Vanilla", R.drawable.img_3));
//        list.add(new FoodModel("Oreo Stack", R.drawable.img_4));

        tv_orderfood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mViewHolder.mDuoDrawerLayout.closeDrawer();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        foodAdapter = new FoodAdapter(this, list);
        recyclerView.setAdapter(foodAdapter);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        iv_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mViewHolder.mDuoDrawerLayout.openDrawer();
            }
        });

        iv_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SideMenuActivity.this, CartActivity.class);
                startActivity(i);
            }
        });

        iv_filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(SideMenuActivity.this);
                dialog.setContentView(R.layout.dialog);

                dialogRecycler = dialog.findViewById(R.id.dialogRecycler);
                dialogRecycler.setLayoutManager(new LinearLayoutManager(SideMenuActivity.this, LinearLayoutManager.VERTICAL, false));

                ArrayList<RecyclerModel> items1 = new ArrayList();
                ArrayList<RecyclerModel> items2 = new ArrayList();
                ArrayList<RecyclerModel> items3 = new ArrayList();

                items1.add(new RecyclerModel("Best Match", false));
                items1.add(new RecyclerModel("Alphabetical", false));
                items1.add(new RecyclerModel("Rating", false));
                items1.add(new RecyclerModel("Show On a Map", false));

                items2.add(new RecyclerModel("Show all Venues", false));
                items2.add(new RecyclerModel("Show Only Open Venues", false));

                items3.add(new RecyclerModel("First Order Discount", false));
                items3.add(new RecyclerModel("Minimum Spend Discount", false));
                items3.add(new RecyclerModel("Meal Deals", false));

                filterModels.add(new FilterModel("SORT VENUES", items1));
                filterModels.add(new FilterModel("FILTER BY OPENINGS", items2));
                filterModels.add(new FilterModel("FILTER BY AVAILABLE SPECIALS", items3));

                filterAdapter = new FilterAdapter(SideMenuActivity.this, filterModels);
                dialogRecycler.setAdapter(filterAdapter);

                iv_cancel = dialog.findViewById(R.id.iv_cancel);

                tv_clear = dialog.findViewById(R.id.tv_clear);
                tv_ok = dialog.findViewById(R.id.tv_ok);

                tv_clear.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                iv_cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                tv_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });

        tv_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SideMenuActivity.this, CartActivity.class);
                startActivity(i);
            }
        });

        tv_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SideMenuActivity.this, OrderHistory.class);
                startActivity(i);
            }
        });


    }

    @Override
    public void onBackPressed() {
        if (mViewHolder.mDuoDrawerLayout.isDrawerOpen()) {
            mViewHolder.mDuoDrawerLayout.closeDrawer();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    private class ViewHolder {
        private DuoDrawerLayout mDuoDrawerLayout;
        private DuoMenuView mDuoMenuView;

        ViewHolder() {
            mDuoDrawerLayout = findViewById(R.id.drawer);
            mDuoMenuView = (DuoMenuView) mDuoDrawerLayout.getMenuView();
        }
    }


}

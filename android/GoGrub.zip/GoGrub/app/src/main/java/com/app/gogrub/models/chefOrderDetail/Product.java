
package com.app.gogrub.models.chefOrderDetail;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Product {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("chef_id")
    @Expose
    private Integer chefId;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("slug")
    @Expose
    private String slug;
    @SerializedName("cuisine_id")
    @Expose
    private Integer cuisineId;
    @SerializedName("serving_size")
    @Expose
    private Integer servingSize;
    @SerializedName("total_servings")
    @Expose
    private Integer totalServings;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("price")
    @Expose
    private Integer price;
    @SerializedName("discounted_price")
    @Expose
    private Integer discountedPrice;
    @SerializedName("availability_from")
    @Expose
    private String availabilityFrom;
    @SerializedName("availability_to")
    @Expose
    private String availabilityTo;
    @SerializedName("preparation_time")
    @Expose
    private Integer preparationTime;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("updated_at")
    @Expose
    private String updatedAt;
    @SerializedName("deleted_at")
    @Expose
    private Object deletedAt;
    @SerializedName("remaining_servings")
    @Expose
    private Integer remainingServings;
    @SerializedName("posted_at")
    @Expose
    private String postedAt;
    @SerializedName("price_view")
    @Expose
    private String priceView;
    @SerializedName("availability_time")
    @Expose
    private String availabilityTime;
    @SerializedName("servings_left")
    @Expose
    private Integer servingsLeft;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getChefId() {
        return chefId;
    }

    public void setChefId(Integer chefId) {
        this.chefId = chefId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public Integer getCuisineId() {
        return cuisineId;
    }

    public void setCuisineId(Integer cuisineId) {
        this.cuisineId = cuisineId;
    }

    public Integer getServingSize() {
        return servingSize;
    }

    public void setServingSize(Integer servingSize) {
        this.servingSize = servingSize;
    }

    public Integer getTotalServings() {
        return totalServings;
    }

    public void setTotalServings(Integer totalServings) {
        this.totalServings = totalServings;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getDiscountedPrice() {
        return discountedPrice;
    }

    public void setDiscountedPrice(Integer discountedPrice) {
        this.discountedPrice = discountedPrice;
    }

    public String getAvailabilityFrom() {
        return availabilityFrom;
    }

    public void setAvailabilityFrom(String availabilityFrom) {
        this.availabilityFrom = availabilityFrom;
    }

    public String getAvailabilityTo() {
        return availabilityTo;
    }

    public void setAvailabilityTo(String availabilityTo) {
        this.availabilityTo = availabilityTo;
    }

    public Integer getPreparationTime() {
        return preparationTime;
    }

    public void setPreparationTime(Integer preparationTime) {
        this.preparationTime = preparationTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Object getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Object deletedAt) {
        this.deletedAt = deletedAt;
    }

    public Integer getRemainingServings() {
        return remainingServings;
    }

    public void setRemainingServings(Integer remainingServings) {
        this.remainingServings = remainingServings;
    }

    public String getPostedAt() {
        return postedAt;
    }

    public void setPostedAt(String postedAt) {
        this.postedAt = postedAt;
    }

    public String getPriceView() {
        return priceView;
    }

    public void setPriceView(String priceView) {
        this.priceView = priceView;
    }

    public String getAvailabilityTime() {
        return availabilityTime;
    }

    public void setAvailabilityTime(String availabilityTime) {
        this.availabilityTime = availabilityTime;
    }

    public Integer getServingsLeft() {
        return servingsLeft;
    }

    public void setServingsLeft(Integer servingsLeft) {
        this.servingsLeft = servingsLeft;
    }

}
